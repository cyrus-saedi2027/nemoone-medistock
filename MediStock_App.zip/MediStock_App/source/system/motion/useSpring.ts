/* اتصالِ اسپرینگ به React — دو حالت، عمداً جدا */

import * as React from "react";
import { Spring, type SpringCfg } from "./spring";

/** یک اسپرینگِ پایدار که در طولِ عمرِ کامپوننت عوض نمی‌شود */
export function useSpringRef(initial: number, cfg?: SpringCfg) {
  const ref = React.useRef<Spring | null>(null);
  if (!ref.current) ref.current = new Spring(initial, cfg);
  React.useEffect(() => () => ref.current?.dispose(), []);
  return ref.current;
}

/**
 * مسیرِ داغ: مقدار مستقیم روی DOM نوشته می‌شود — صفر رندر.
 * برای هر چیزی که بالای یک زیردرختِ بزرگ نشسته: گهوارهٔ نوار،
 * سوایپِ برگشت، شیت، بانسِ اسکرول، ردیفِ سوایپی، پروازِ اشتراکی.
 */
export function useSpringBind<T extends HTMLElement | SVGElement>(
  spring: Spring,
  write: (el: T, x: number, v: number) => void
) {
  const el = React.useRef<T | null>(null);
  const w = React.useRef(write);
  w.current = write;

  /* ── چرا اینجا `if (!el.current) return` نیست ────────────
   * قبلاً بود، و هر کامپوننتی را که وقتی بسته است `null` برمی‌گرداند
   * بی‌صدا از حرکت می‌انداخت — یعنی *همهٔ شیت‌ها*.
   *
   * ترتیبش این بود: شیتِ بسته `null` رندر می‌کرد، پس موقعِ اجرای این
   * افکت گرهی وجود نداشت و زود برمی‌گشت. وابستگی هم فقط `[spring]`
   * است و اسپرینگ هرگز عوض نمی‌شود، پس افکت **دیگر هیچ‌وقت اجرا
   * نمی‌شد**. شیت باز می‌شد و پنل هرگز `transform` نمی‌گرفت: بدونِ
   * ذره‌ای حرکت، یکهو سرِ جایش. همان چیزی که «خشک باز و بسته می‌شود»
   * توصیفش بود.
   *
   * حالا همیشه مشترک می‌شویم؛ نویسنده خودش گرهِ نبوده را رد می‌کند.
   * برای کامپوننتی که همیشه هست هیچ فرقی ندارد. */
  React.useEffect(() => {
    return spring.subscribe((x, v) => {
      const node = el.current;
      if (node) w.current(node, x, v);
    });
  }, [spring]);

  return el;
}

/**
 * مسیرِ سرد: مقدار وارد رندر می‌شود.
 * فقط جایی که زیردرخت کوچک است (سگمنت با ۴ دکمه، کارتِ تب‌دار).
 */
export function useSpringState(spring: Spring) {
  const [x, setX] = React.useState(spring.x);
  React.useEffect(
    () => spring.subscribe((v) => setX((p) => (Math.abs(p - v) > 0.0005 ? v : p))),
    [spring]
  );
  return x;
}
