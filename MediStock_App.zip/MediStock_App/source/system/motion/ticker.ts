/* ─────────────────────────────────────────────────────────────
 *  یک حلقهٔ rAF برای همهٔ اسپرینگ‌ها
 *
 *  رفرنس برای هر اسپرینگ یک requestAnimationFrame جدا می‌ساخت.
 *  وقتی هم‌زمان شیت کشیده می‌شود، ردیف سوایپ می‌شود، گهوارهٔ نوار
 *  حرکت می‌کند و اسکرول بانس دارد، چهار حلقه سرِ یک فریم دعوا
 *  می‌کنند. اینجا یک حلقه داریم که وقتی کسی نیست خودش می‌خوابد.
 * ───────────────────────────────────────────────────────────── */

export type Tickable = { step: (dt: number) => boolean };

const live = new Set<Tickable>();
let raf = 0;
let last = 0;

function frame(now: number) {
  // dt را سقف می‌گذاریم تا بعد از یک فریمِ گم‌شده، فنر پرش نکند
  const dt = last ? Math.min((now - last) / 1000, 1 / 30) : 1 / 60;
  last = now;

  // روی کپی حرکت می‌کنیم؛ step ممکن است خودش را از مجموعه بردارد
  for (const t of Array.from(live)) {
    if (!t.step(dt)) live.delete(t);
  }

  if (live.size) raf = requestAnimationFrame(frame);
  else { raf = 0; last = 0; }
}

export function join(t: Tickable) {
  live.add(t);
  if (!raf) raf = requestAnimationFrame(frame);
}

export function leave(t: Tickable) {
  live.delete(t);
  if (!live.size && raf) { cancelAnimationFrame(raf); raf = 0; last = 0; }
}
