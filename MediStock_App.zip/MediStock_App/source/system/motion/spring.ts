/* ─────────────────────────────────────────────────────────────
 *  اسپرینگِ بدونِ React
 *
 *  نکتهٔ کلیدیِ سرعت: رفرنس مقدارِ فنر را با setState به DOM
 *  می‌رساند، یعنی هر فریم کلِ زیردرختِ صاحبِ فنر دوباره رندر
 *  می‌شود (۶۰ بار در ثانیه). اینجا فنر هیچ ربطی به React ندارد؛
 *  مشترک‌ها مستقیم به style گره می‌خورند.
 *
 *  انتگرال‌گیری: اویلرِ نیمه‌ضمنی — همان چیزی که رفرنس دارد،
 *  پس اعدادِ MOTION عیناً همان حس را می‌دهند.
 * ───────────────────────────────────────────────────────────── */

import { join, leave, type Tickable } from "./ticker";

export type SpringCfg = {
  stiffness?: number;
  damping?: number;
  mass?: number;
  precision?: number;
};

type Sub = (x: number, v: number) => void;

export class Spring implements Tickable {
  x: number;
  v = 0;
  target: number;
  private k: number;
  private c: number;
  private m: number;
  private eps: number;
  private subs = new Set<Sub>();
  private onRest: (() => void) | null = null;
  /** وقتی کاربر انگشتش روی المان است، فنر خاموش می‌ماند */
  private held = false;

  constructor(initial: number, cfg: SpringCfg = {}) {
    this.x = initial;
    this.target = initial;
    this.k = cfg.stiffness ?? 300;
    this.c = cfg.damping ?? 30;
    this.m = cfg.mass ?? 1;
    this.eps = cfg.precision ?? 0.01;
  }

  subscribe(fn: Sub) {
    this.subs.add(fn);
    fn(this.x, this.v);            // مقدارِ اولیه را فوراً بنویس
    return () => { this.subs.delete(fn); };
  }

  private emit() { for (const s of this.subs) s(this.x, this.v); }

  /** ست کردنِ سختِ مقدار — همین چیزی است که «قابلِ گرفتن» بودن را می‌سازد */
  set(x: number) {
    this.held = true;
    leave(this);
    this.x = x;
    this.v = 0;
    this.target = x;
    this.emit();
  }

  /** رها کردن با سرعت */
  springTo(target: number, v0 = 0, onRest?: () => void) {
    this.held = false;
    this.target = target;
    this.v = v0;
    this.onRest = onRest ?? null;

    if (REDUCED) {                  // احترام به prefers-reduced-motion
      this.x = target; this.v = 0;
      this.emit();
      const cb = this.onRest; this.onRest = null; cb?.();
      return;
    }
    join(this);
  }

  stop() { leave(this); this.v = 0; this.onRest = null; }

  step(dt: number) {
    if (this.held) return false;
    const a = (-this.k * (this.x - this.target) - this.c * this.v) / this.m;
    this.v += a * dt;
    this.x += this.v * dt;

    if (Math.abs(this.x - this.target) < this.eps && Math.abs(this.v) < this.eps * 4) {
      this.x = this.target;
      this.v = 0;
      this.emit();
      const cb = this.onRest; this.onRest = null; cb?.();
      return false;                 // از حلقه خارج شو
    }
    this.emit();
    return true;
  }

  dispose() { leave(this); this.subs.clear(); }
}

export let REDUCED =
  typeof matchMedia !== "undefined" &&
  matchMedia("(prefers-reduced-motion: reduce)").matches;

if (typeof matchMedia !== "undefined") {
  const mq = matchMedia("(prefers-reduced-motion: reduce)");
  const on = () => { REDUCED = mq.matches; };
  mq.addEventListener?.("change", on);
}
