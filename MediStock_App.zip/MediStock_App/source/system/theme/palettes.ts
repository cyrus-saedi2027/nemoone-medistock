/* ─────────────────────────────────────────────────────────────
 *  پالت‌ها
 *
 *  تمِ پیش‌فرض «دیفالت» است: سیاهِ مطلق، سفیدِ مطلق، و خاکستری‌های
 *  بینشان. رنگ فقط جایی می‌آید که *معنا* دارد — منقضی، هشدار، سالم.
 *  تمِ «شب» دقیقاً همین است، برعکس‌شده.
 *
 *  دو رمپ داریم چون یک رنگ همیشه نمی‌تواند هر دو کار را بکند:
 *     accentSurface  → سطحِ بزرگ، متنِ تیره رویش
 *     accentStrong   → تأکیدِ کوچک (دکمهٔ گهواره)، جفتِ جوهرش جداست
 *  در تمِ استودیو هر دو زردند — زرد آن‌قدر روشن هست که هر دو را بکشد.
 *  در تم‌های آبی نیستند، و دقیقاً به همین دلیل دو رمپ جدا داریم.
 * ───────────────────────────────────────────────────────────── */

export type Palette = {
  canvas: string; canvasWarm: string; surface: string; surfaceAlt: string;
  card: string; cardAlt: string;

  accentSurface: string; accentSurfaceTop: string; accentSurfaceBottom: string;
  accentSurfaceInk: string; accentSurfaceInkSoft: string;

  accentStrong: string; accentStrongTop: string; accentStrongBottom: string;
  accentStrongInk: string;

  deep: string; deepTop: string; deepInk: string; deepInkMuted: string;
  /**
   * سطحِ کارت/ردیفِ تیره — *رنگِ توپُر*، نه سفیدِ نیمه‌شفاف.
   *
   * قبلاً همه‌جا `rgba(255,255,255,.07)` بود. آن حالتِ شیشه‌ای رنگش را
   * از پس‌زمینه می‌گرفت، پس با اسکرول و با عوض‌شدنِ سبکِ پس‌زمینه
   * ناپدید می‌شد. رنگِ توپُر همه‌جا یک‌جور دیده می‌شود.
   */
  cardDark: string; cardDarkAlt: string;

  ink: string; inkMuted: string; inkFaint: string;
  divider: string; ring: string; ringTrack: string;

  /**
   * خطِ موییِ دورِ کارت‌ها و ردیف‌ها.
   *
   * چرا لازم شد: کارتِ سفید روی زمینهٔ تقریباً سفید فقط با سایه دیده
   * می‌شد، و سایهٔ ملایم روی گوشی در نورِ روز عملاً ناپیداست. سایه را
   * سنگین نکردیم چون ۲۳ ردیف هم‌زمان روی صفحه‌اند و بلورِ بزرگ p95 را
   * بالا می‌برد؛ یک خطِ یک‌پیکسلی هزینهٔ رنگ‌آمیزی ندارد.
   */
  hair: string;
  /** دستهٔ کلید — باید هم روی ریلِ روشن هم روی ریلِ تیره دیده شود */
  knob: string;

  /**
   * گرادیانِ سطحِ تأکید و سطحِ تیره. رشتهٔ کاملِ CSS است، نه رنگ.
   * در تم‌هایی که گرادیان نمی‌خواهند همان رنگِ تخت گذاشته شده تا
   * جایگاهِ استفاده لازم نباشد شرط بگذارد.
   */
  accentGrad: string; deepGrad: string;

  ok: string; okWash: string;
  warn: string; warnWash: string;
  crit: string; critWash: string;
  info: string; infoWash: string;
  /** نقطهٔ توجه — نخوانده‌ها، بجِ شمارش */
  attn: string; attnWash: string;

  /* ── پس‌زمینهٔ واحدِ اپ ── */
  bgTop: string; bgMid: string; bgBottom: string;
  /** هالهٔ خیلی محوِ بالای صفحه */
  glow: string;
  /**
   * لایهٔ ملایمِ زیرِ نوارِ پایین — از خطِ بالای قرص تا کفِ قاب.
   * محتوا بریده نمی‌شود، فقط کمی عقب می‌نشیند تا مرز پیدا باشد.
   */
  scrimTop: string; scrimBottom: string;

  /* ── نوارِ قرصیِ شناور ── */
  navEdge: string; navInk: string;
  /** متنِ روی سطحِ تیره (نوار، توست، دکمهٔ تیره) */
  onDark: string;

  /** برای <meta name="theme-color"> */
  bar: string;
};

export type ThemeId =
  | "mono" | "night" | "slab" | "studio" | "clinic" | "sky" | "teal" | "contrast";

export const THEMES: Record<ThemeId, { fa: string; dark: boolean; p: Palette }> = {
  /* ── تمِ دیفالت: سیاهِ مطلق · سفیدِ مطلق · خاکستری ────────
     رنگ فقط جایی می‌آید که معنا دارد. سه نکته که عمداً رعایت شد:

     ۱) هیچ متنی روی هیچ سطحی زیرِ ۴٫۵:۱ نیست. تیره‌ترین خاکستریِ
        متن `#6E6E75` است (۵٫۳:۱ روی سفید) — پایین‌تر از این، متنِ
        ۱۰ پیکسلیِ فارسی روی گوشی خوانده نمی‌شود.
     ۲) رنگ‌های وضعیت تیره‌اند نه روشن. «سفارش» و «منقضی» باید روی
        کارتِ سفید دیده شوند؛ قرمزِ روشن روی سفید همان اشتباهی بود
        که در تمِ قبل باعث ناپیدا شدنِ برچسبِ «سفارش» شد.
     ۳) گرادیان فقط روی سه چیز: پس‌زمینهٔ صفحه، دکمهٔ اصلی، و نوارِ
        پایین. بیشتر از این، اپ کثیف می‌شود. */
  mono: {
    fa: "دیفالت", dark: false,
    p: {
      canvas: "#FFFFFF", canvasWarm: "#FFFFFF", surface: "#FFFFFF", surfaceAlt: "#ECECEF",
      card: "#FFFFFF", cardAlt: "#F6F6F8",

      accentSurface: "#E7E7EB", accentSurfaceTop: "#F1F1F4", accentSurfaceBottom: "#DDDDE2",
      accentSurfaceInk: "#000000", accentSurfaceInkSoft: "#48484F",

      accentStrong: "#000000", accentStrongTop: "#2C2C31", accentStrongBottom: "#000000",
      accentStrongInk: "#FFFFFF",

      deep: "#000000", deepTop: "#26262B", deepInk: "#000000", deepInkMuted: "#5A5A62",
      cardDark: "#FFFFFF", cardDarkAlt: "#EAEAEE",

      ink: "#000000", inkMuted: "#48484F", inkFaint: "#6E6E75",
      divider: "#DEDEE3", ring: "#000000", ringTrack: "#D5D5DB",
      hair: "#E2E2E7", knob: "#FFFFFF",
      accentGrad: "linear-gradient(180deg,#2C2C31 0%,#000000 100%)",
      deepGrad: "linear-gradient(180deg,#26262B 0%,#000000 100%)",

      ok: "#0F5132", okWash: "#E4EEE9",
      warn: "#75440B", warnWash: "#F1EBE1",
      crit: "#8C1414", critWash: "#F3E5E5",
      info: "#000000", infoWash: "#ECECEF",
      attn: "#8C1414", attnWash: "#F3E5E5",

      bar: "#FFFFFF",
      bgTop: "#FFFFFF", bgMid: "#F7F7F9", bgBottom: "#E8E8EC",
      glow: "rgba(0,0,0,.05)",
      scrimTop: "rgba(232,232,236,0)", scrimBottom: "rgba(232,232,236,.62)",
      navEdge: "rgba(255,255,255,.13)", navInk: "rgba(255,255,255,.58)",
      onDark: "#FFFFFF",
    },
  },

  /* ── شب: همان تمِ دیفالت، برعکس ────────────────────────
     سیاه جای سفید، سفید جای سیاه. نوارِ پایین سفید می‌شود و
     آیتمِ فعالش تیره — دقیقاً آینهٔ حالتِ روز. */
  night: {
    fa: "شب", dark: true,
    p: {
      canvas: "#000000", canvasWarm: "#000000", surface: "#0A0A0C", surfaceAlt: "#1C1C21",
      card: "#121216", cardAlt: "#191920",

      accentSurface: "#1E1E24", accentSurfaceTop: "#26262D", accentSurfaceBottom: "#17171C",
      accentSurfaceInk: "#FFFFFF", accentSurfaceInkSoft: "#B2B2BB",

      accentStrong: "#FFFFFF", accentStrongTop: "#FFFFFF", accentStrongBottom: "#DBDBE2",
      accentStrongInk: "#000000",

      deep: "#FFFFFF", deepTop: "#EDEDF1", deepInk: "#FFFFFF", deepInkMuted: "#9C9CA6",
      cardDark: "#121216", cardDarkAlt: "#1E1E25",

      ink: "#FFFFFF", inkMuted: "#B2B2BB", inkFaint: "#8C8C96",
      divider: "#26262D", ring: "#FFFFFF", ringTrack: "#4A4A54",
      hair: "#25252C", knob: "#0A0A0C",
      accentGrad: "linear-gradient(180deg,#FFFFFF 0%,#DBDBE2 100%)",
      deepGrad: "linear-gradient(180deg,#FFFFFF 0%,#E6E6EC 100%)",

      ok: "#5FD08D", okWash: "#12241A",
      warn: "#E7B44C", warnWash: "#2A2113",
      crit: "#F0736B", critWash: "#2C1616",
      info: "#FFFFFF", infoWash: "#1C1C21",
      attn: "#F0736B", attnWash: "#2C1616",

      bar: "#000000",
      bgTop: "#16161A", bgMid: "#0C0C0F", bgBottom: "#000000",
      glow: "rgba(255,255,255,.05)",
      scrimTop: "rgba(0,0,0,0)", scrimBottom: "rgba(0,0,0,.6)",
      navEdge: "rgba(0,0,0,.14)", navInk: "rgba(0,0,0,.5)",
      onDark: "#000000",
    },
  },

  /* ── تمِ سه‌تکه: دقیقاً سه رنگی که محمد داد ───────────────
     #FFFFFF · #EEAC34 · #292929 روی سیاه */
  /* نامش عمداً «سه‌تکه» نیست: آن نامِ *سبکِ پس‌زمینه* است و دو چیزِ
     متفاوت با یک نام، هم کاربر را گیج می‌کند هم تست را. */
  slab: {
    fa: "کهربا", dark: false,
    p: {
      /* `surface` رنگِ خودِ تکهٔ سفید است و `card` رنگِ کارت‌های روی آن.
         عمداً یکی نیستند: اگر هر دو #FFFFFF باشند، کارت روی تکهٔ سفید
         ناپدید می‌شود. اختلافِ ۳٪ در نگاه «سفید» دیده می‌شود ولی مرزِ
         کارت را برمی‌گرداند. */
      canvas: "#000000", canvasWarm: "#000000", surface: "#F7F5F1", surfaceAlt: "#EAE6DE",
      card: "#FFFFFF", cardAlt: "#FAF8F5",

      accentSurface: "#FFC24B", accentSurfaceTop: "#F3B948", accentSurfaceBottom: "#E7A126",
      accentSurfaceInk: "#2B2011", accentSurfaceInkSoft: "#6A5327",

      accentStrong: "#FFC24B", accentStrongTop: "#F3B948", accentStrongBottom: "#E7A126",
      accentStrongInk: "#2B2011",

      deep: "#292929", deepTop: "#343434", deepInk: "#14161A", deepInkMuted: "#6E7681",
      cardDark: "#FFFFFF", cardDarkAlt: "#ECEEF2",

      ink: "#1C1C1C", inkMuted: "#6F6A63", inkFaint: "#918B83",
      divider: "#E4DFD7", ring: "#57524B", ringTrack: "#DFDBD3",
      hair: "#E7E2DA", knob: "#FFFFFF",
      accentGrad: "linear-gradient(180deg,#F3B948 0%,#E7A126 100%)",
      deepGrad: "linear-gradient(180deg,#343434 0%,#1E1E1E 100%)",

      ok: "#3F7A48", okWash: "#E4EEE6",
      warn: "#9C620F", warnWash: "#F8EBD5",
      crit: "#9E3A2F", critWash: "#F6E1DD",
      info: "#57524B", infoWash: "#EFEBE4",
      attn: "#D24A1E", attnWash: "#F9E4DB",
      bar: "#000000",
      bgTop: "#FFFFFF", bgMid: "#F6F7FA", bgBottom: "#E9EBF0",
      glow: "rgba(255,194,75,.14)",
      scrimTop: "rgba(233,235,240,0)", scrimBottom: "rgba(233,235,240,.55)",
      navEdge: "rgba(255,255,255,.07)", navInk: "rgba(255,255,255,.55)",
      onDark: "#F4F6F8",
    },
  },

  /* ── تمِ رفرنس ─────────────────────────────────────────── */
  studio: {
    fa: "استودیو", dark: false,
    p: {
      canvas: "#F0EBE4", canvasWarm: "#F5F1EC", surface: "#F7F4F0", surfaceAlt: "#EAE5DD",
      card: "#FFFFFF", cardAlt: "#F7F4F0",

      accentSurface: "#E9C95A", accentSurfaceTop: "#EFD16A", accentSurfaceBottom: "#E3C04C",
      accentSurfaceInk: "#2B2418", accentSurfaceInkSoft: "#5F5540",

      accentStrong: "#E9C95A", accentStrongTop: "#EFD16A", accentStrongBottom: "#E3C04C",
      accentStrongInk: "#2B2418",

      deep: "#1E1E1E", deepTop: "#262523", deepInk: "#14161A", deepInkMuted: "#6E7681",
      cardDark: "#FFFFFF", cardDarkAlt: "#ECEEF2",

      ink: "#1E1E1E", inkMuted: "#7A746C", inkFaint: "#9B958D",
      divider: "#E5E0D9", ring: "#5B554E", ringTrack: "#E1DCD5",
      hair: "#E8E3DC", knob: "#FFFFFF",
      accentGrad: "linear-gradient(180deg,#EFD16A 0%,#E3C04C 100%)",
      deepGrad: "linear-gradient(180deg,#262523 0%,#141414 100%)",

      ok: "#47764A", okWash: "#E5EDE5",
      warn: "#A16A16", warnWash: "#F7EBD8",
      crit: "#9C4437", critWash: "#F5E3DF",
      info: "#5B554E", infoWash: "#EFEBE4",
      attn: "#D24A1E", attnWash: "#F9E4DB",

      bar: "#F0EBE4",
      bgTop: "#FFFFFF", bgMid: "#F6F7FA", bgBottom: "#E9EBF0",
      glow: "rgba(255,194,75,.14)",
      scrimTop: "rgba(233,235,240,0)", scrimBottom: "rgba(233,235,240,.55)",
      navEdge: "rgba(255,255,255,.07)", navInk: "rgba(255,255,255,.55)",
      onDark: "#F4F6F8",
    },
  },

  clinic: {
    fa: "کلینیک", dark: false,
    p: {
      canvas: "#EEF3F9", canvasWarm: "#F2F6FB", surface: "#F4F8FC", surfaceAlt: "#E2ECF7",
      card: "#FFFFFF", cardAlt: "#F7FAFD",

      accentSurface: "#DCEAFB", accentSurfaceTop: "#E4F0FD", accentSurfaceBottom: "#CFE2F8",
      accentSurfaceInk: "#123055", accentSurfaceInkSoft: "#3F607F",

      accentStrong: "#1D6FE0", accentStrongTop: "#2E80EE", accentStrongBottom: "#155FC7",
      accentStrongInk: "#FFFFFF",

      deep: "#0F2740", deepTop: "#17364F", deepInk: "#14161A", deepInkMuted: "#6E7681",
      cardDark: "#FFFFFF", cardDarkAlt: "#EBEFF4",

      ink: "#0F2036", inkMuted: "#4E657D", inkFaint: "#7C90A5",
      divider: "#D6E2EE", ring: "#1D6FE0", ringTrack: "#D6E2EE",
      hair: "#DCE7F1", knob: "#FFFFFF",
      accentGrad: "linear-gradient(180deg,#2E80EE 0%,#155FC7 100%)",
      deepGrad: "linear-gradient(180deg,#17364F 0%,#0F2740 100%)",

      ok: "#0A7A5A", okWash: "#DEF2EB",
      warn: "#A16207", warnWash: "#FBEFD7",
      crit: "#C02626", critWash: "#FAE4E4",
      info: "#1D6FE0", infoWash: "#E4EFFC",
      attn: "#C2410C", attnWash: "#FBE7DC",

      bar: "#0F2740",
      bgTop: "#FFFFFF", bgMid: "#F6F7FA", bgBottom: "#E9EBF0",
      glow: "rgba(29,111,224,.10)",
      scrimTop: "rgba(233,235,240,0)", scrimBottom: "rgba(233,235,240,.55)",
      navEdge: "rgba(255,255,255,.07)", navInk: "rgba(255,255,255,.55)",
      onDark: "#F4F6F8",
    },
  },

  sky: {
    fa: "آسمانی", dark: false,
    p: {
      canvas: "#F1F7FD", canvasWarm: "#F5F9FE", surface: "#F7FBFE", surfaceAlt: "#E4F0FA",
      card: "#FFFFFF", cardAlt: "#F6FBFE",

      accentSurface: "#E6F2FE", accentSurfaceTop: "#EEF7FF", accentSurfaceBottom: "#D9EBFC",
      accentSurfaceInk: "#0C3553", accentSurfaceInkSoft: "#3C6280",

      accentStrong: "#0E86D4", accentStrongTop: "#1E96E2", accentStrongBottom: "#0873BB",
      accentStrongInk: "#FFFFFF",

      deep: "#12324A", deepTop: "#1B435E", deepInk: "#14161A", deepInkMuted: "#6E7681",
      cardDark: "#FFFFFF", cardDarkAlt: "#EBEFF4",

      ink: "#0C2A40", inkMuted: "#486C81", inkFaint: "#7897AB",
      divider: "#D5E5F1", ring: "#0E86D4", ringTrack: "#D5E5F1",
      hair: "#DBE8F3", knob: "#FFFFFF",
      accentGrad: "linear-gradient(180deg,#1E96E2 0%,#0873BB 100%)",
      deepGrad: "linear-gradient(180deg,#1B435E 0%,#12324A 100%)",

      ok: "#0A7A5A", okWash: "#DEF2EB",
      warn: "#A16207", warnWash: "#FBEFD7",
      crit: "#C02626", critWash: "#FAE4E4",
      info: "#0E86D4", infoWash: "#E2F1FB",
      attn: "#C2410C", attnWash: "#FBE7DC",

      bar: "#12324A",
      bgTop: "#FFFFFF", bgMid: "#F6F7FA", bgBottom: "#E9EBF0",
      glow: "rgba(14,134,212,.10)",
      scrimTop: "rgba(233,235,240,0)", scrimBottom: "rgba(233,235,240,.55)",
      navEdge: "rgba(255,255,255,.07)", navInk: "rgba(255,255,255,.55)",
      onDark: "#F4F6F8",
    },
  },

  teal: {
    fa: "فیروزه‌ای", dark: false,
    p: {
      canvas: "#EDF5F5", canvasWarm: "#F1F8F8", surface: "#F3F9F9", surfaceAlt: "#DFEDEE",
      card: "#FFFFFF", cardAlt: "#F5FAFA",

      accentSurface: "#DDF1F2", accentSurfaceTop: "#E6F6F7", accentSurfaceBottom: "#CDE8EA",
      accentSurfaceInk: "#0A3238", accentSurfaceInkSoft: "#3A6065",

      accentStrong: "#0E8F97", accentStrongTop: "#159FA8", accentStrongBottom: "#0A7C84",
      accentStrongInk: "#FFFFFF",

      deep: "#0C3038", deepTop: "#13424B", deepInk: "#14161A", deepInkMuted: "#6E7681",
      cardDark: "#FFFFFF", cardDarkAlt: "#EBEFF4",

      ink: "#0B2A30", inkMuted: "#446468", inkFaint: "#74959A",
      divider: "#D2E5E6", ring: "#0E8F97", ringTrack: "#D2E5E6",
      hair: "#D8E9EA", knob: "#FFFFFF",
      accentGrad: "linear-gradient(180deg,#159FA8 0%,#0A7C84 100%)",
      deepGrad: "linear-gradient(180deg,#13424B 0%,#0C3038 100%)",

      ok: "#0A7A5A", okWash: "#DEF2EB",
      warn: "#A16207", warnWash: "#FBEFD7",
      crit: "#C02626", critWash: "#FAE4E4",
      info: "#0E8F97", infoWash: "#DEF0F1",
      attn: "#C2410C", attnWash: "#FBE7DC",

      bar: "#0C3038",
      bgTop: "#FFFFFF", bgMid: "#F6F7FA", bgBottom: "#E9EBF0",
      glow: "rgba(14,143,151,.10)",
      scrimTop: "rgba(233,235,240,0)", scrimBottom: "rgba(233,235,240,.55)",
      navEdge: "rgba(255,255,255,.07)", navInk: "rgba(255,255,255,.55)",
      onDark: "#F4F6F8",
    },
  },

  contrast: {
    fa: "پرکنتراست", dark: false,
    p: {
      canvas: "#FFFFFF", canvasWarm: "#FBFCFE", surface: "#FFFFFF", surfaceAlt: "#EBF1F8",
      card: "#FFFFFF", cardAlt: "#F7FAFD",

      accentSurface: "#E8F0FE", accentSurfaceTop: "#F0F6FF", accentSurfaceBottom: "#DCE9FC",
      accentSurfaceInk: "#000A1A", accentSurfaceInkSoft: "#2F4763",

      accentStrong: "#0B4FBF", accentStrongTop: "#1560D4", accentStrongBottom: "#083F9E",
      accentStrongInk: "#FFFFFF",

      deep: "#000A1A", deepTop: "#0A1B33", deepInk: "#000A1A", deepInkMuted: "#3F5670",
      cardDark: "#FFFFFF", cardDarkAlt: "#E7EEF6",

      ink: "#000A1A", inkMuted: "#2C3F57", inkFaint: "#54687E",
      divider: "#C2D3E6", ring: "#0B4FBF", ringTrack: "#CFDDEC",
      hair: "#CFDDEC", knob: "#FFFFFF",
      accentGrad: "linear-gradient(180deg,#1560D4 0%,#083F9E 100%)",
      deepGrad: "linear-gradient(180deg,#0A1B33 0%,#000A1A 100%)",

      ok: "#046148", okWash: "#DCEFE8",
      warn: "#8C4008", warnWash: "#FAEBD4",
      crit: "#A81616", critWash: "#F9E2E2",
      info: "#0B4FBF", infoWash: "#E3EDFC",
      attn: "#A8350A", attnWash: "#F9E4D9",

      bar: "#000A1A",
      bgTop: "#FFFFFF", bgMid: "#F6F7FA", bgBottom: "#E9EBF0",
      glow: "rgba(11,79,191,.10)",
      scrimTop: "rgba(233,235,240,0)", scrimBottom: "rgba(233,235,240,.55)",
      navEdge: "rgba(255,255,255,.07)", navInk: "rgba(255,255,255,.55)",
      onDark: "#F4F6F8",
    },
  },
};

export const DEFAULT_THEME: ThemeId = "mono";

/** ترتیبِ نمایش در انتخابگرِ تم — «دیفالت» و جفتِ شبش اولِ فهرست */
export const THEME_ORDER: ThemeId[] = [
  "mono", "night", "slab", "studio", "clinic", "sky", "teal", "contrast",
];
