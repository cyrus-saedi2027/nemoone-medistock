/* تم به‌صورتِ CSS variable — عوض‌کردنِ تم صفر رندرِ React دارد */

import * as React from "react";
import { THEMES, DEFAULT_THEME, type ThemeId, type Palette } from "./palettes";

const KEY = "ms-theme";
const BG_KEY = "ms-bg";

/**
 * سبکِ پس‌زمینه — فعلاً فقط یکی.
 *
 * قبلاً پنج‌تا بود (ساده، شفق، شب، سه‌تکه، منحنی) ولی با عوض‌شدنِ
 * رنگِ زمینه، خواندنِ محتوا سخت می‌شد. یک زمینهٔ ثابتِ روشن یعنی هر
 * کارت و هر متن همیشه یک‌جور دیده می‌شود. تایپ سرِ جایش مانده تا
 * اگر بعداً سبکی اضافه شد، جای اضافه‌کردنش معلوم باشد.
 */
export type BgStyle = "light";
export const BG_STYLES: { id: BgStyle; fa: string; note: string }[] = [
  { id: "light", fa: "روشن", note: "سفیدِ گرادیان‌دار" },
];
export const DEFAULT_BG: BgStyle = "light";

type Ctx = {
  id: ThemeId; p: Palette; dark: boolean; setTheme: (id: ThemeId) => void;
  bg: BgStyle; setBg: (b: BgStyle) => void;
};
const ThemeCtx = React.createContext<Ctx | null>(null);

/** `v("accentStrong")` → `"var(--c-accentStrong)"` — با تایپِ امن */
export const v = (k: keyof Palette) => `var(--c-${k})`;

function apply(id: ThemeId) {
  const t = THEMES[id];
  const root = document.documentElement;
  for (const [k, val] of Object.entries(t.p)) {
    root.style.setProperty(`--c-${k}`, val as string);
  }
  root.setAttribute("data-theme", id);
  root.style.colorScheme = t.dark ? "dark" : "light";
  document.querySelector('meta[name="theme-color"]')?.setAttribute("content", t.p.bar);
  try { localStorage.setItem(KEY, id); } catch {}
}

/**
 * نسلِ پیش‌فرض. با عوض‌شدنِ تمِ پیش‌فرضِ اپ یکی زیاد می‌شود.
 *
 * چرا لازم است: تمِ انتخاب‌شده در `localStorage` می‌ماند. بدونِ این،
 * گوشی‌هایی که اپ را از قبل باز کرده بودند روی تمِ قدیمی گیر می‌کردند
 * و «پیش‌فرضِ تازه» فقط برای نصبِ تمیز اتفاق می‌افتاد. یک‌بار همه را
 * به پیش‌فرضِ تازه می‌بَرد و بعد از آن انتخابِ کاربر محترم است.
 */
const GEN_KEY = "ms-theme-gen";
const GEN = "2";

/** قبل از اولین رنگ‌آمیزی اجرا می‌شود تا هیچ پرشِ رنگی دیده نشود */
export function bootTheme(): ThemeId {
  let id: ThemeId | null = null;
  try {
    if (localStorage.getItem(GEN_KEY) !== GEN) {
      localStorage.setItem(GEN_KEY, GEN);
      localStorage.removeItem(KEY);
    }
    id = localStorage.getItem(KEY) as ThemeId | null;
  } catch {}
  /* عمداً به prefers-color-scheme گوش نمی‌دهیم — تمِ دیفالت هویتِ اپ است،
     نه یک ترجیحِ سیستمی. کاربر از تنظیمات عوضش می‌کند. */
  if (!id || !THEMES[id]) id = DEFAULT_THEME;
  apply(id);
  return id;
}

export function bootBg(): BgStyle {
  /* فقط یک سبک داریم؛ هر مقدارِ ذخیره‌شده از نسخه‌های قبل نادیده
     گرفته می‌شود تا کسی روی سبکِ حذف‌شده گیر نکند. */
  try { localStorage.removeItem(BG_KEY); } catch {}
  return DEFAULT_BG;
}

export function ThemeProvider({
  initial,
  initialBg,
  children,
}: { initial: ThemeId; initialBg: BgStyle; children: React.ReactNode }) {
  const [id, setId] = React.useState<ThemeId>(initial);
  const [bg, setBgState] = React.useState<BgStyle>(initialBg);

  const setTheme = React.useCallback((next: ThemeId) => {
    apply(next);
    setId(next);
  }, []);

  const setBg = React.useCallback((next: BgStyle) => {
    try { localStorage.setItem(BG_KEY, next); } catch {}
    setBgState(next);
  }, []);

  const value = React.useMemo<Ctx>(
    () => ({ id, p: THEMES[id].p, dark: THEMES[id].dark, setTheme, bg, setBg }),
    [id, setTheme, bg, setBg]
  );

  return <ThemeCtx.Provider value={value}>{children}</ThemeCtx.Provider>;
}

export function useTheme() {
  const c = React.useContext(ThemeCtx);
  if (!c) throw new Error("useTheme خارج از ThemeProvider");
  return c;
}
