/* نرمال‌سازیِ متنِ فارسی برای جست‌وجو
 * لیستِ ۵۰۱۰تایی از نرم‌افزارِ داروخانه آمده و پر از «ي» و «ك» عربی است. */

import { toEn } from "./digits";

export function normalize(s: string): string {
  return toEn(
    s
      .replace(/ي/g, "ی")  // ي → ی
      .replace(/ك/g, "ک")  // ك → ک
      .replace(/ة/g, "ه")  // ة → ه
      .replace(/[ً-ْٰ]/g, "") // اعراب
      .replace(/‌/g, " ")       // نیم‌فاصله → فاصله
      .replace(/\s+/g, " ")
      .trim()
      .toLowerCase()
  );
}
