/* تبدیلِ میلادی ↔ شمسی — بدونِ وابستگی، الگوریتمِ بیرشک */

export type J = { jy: number; jm: number; jd: number };

/* بریدن به سمتِ صفر، نه Math.floor.
   الگوریتمِ بیرشک روی همین حساب می‌کند: `div(3-8, 6)` باید ۰ بدهد نه ‎−۱.
   با floor، هر تاریخِ ماه‌های ابتدای سالِ میلادی یک سال جابه‌جا می‌شد و
   ماهِ شمسی از ۱۲ رد می‌کرد (jm=17). */
const div = (a: number, b: number) => Math.trunc(a / b);

function g2d(gy: number, gm: number, gd: number) {
  let d =
    div((gy + div(gm - 8, 6) + 100100) * 1461, 4) +
    div(153 * ((gm + 9) % 12) + 2, 5) +
    gd - 34840408;
  d = d - div(div(gy + 100100 + div(gm - 8, 6), 100) * 3, 4) + 752;
  return d;
}

function d2g(jdn: number) {
  let j = 4 * jdn + 139361631;
  j = j + div(div(4 * jdn + 183187720, 146097) * 3, 4) * 4 - 3908;
  const i = div((j % 1461), 4) * 5 + 308;
  const gd = div((i % 153), 5) + 1;
  const gm = ((div(i, 153) % 12) + 1);
  const gy = div(j, 1461) - 100100 + div(8 - gm, 6);
  return { gy, gm, gd };
}

function jalCal(jy: number) {
  const breaks = [-61, 9, 38, 199, 426, 686, 756, 818, 1111, 1181, 1210,
    1635, 1701, 1808, 1988, 2122, 2260, 2324, 2394, 2456, 3178];
  let jump = 0, leapJ = -14, jp = breaks[0];
  for (let i = 1; i < breaks.length; i++) {
    const jm = breaks[i];
    jump = jm - jp;
    if (jy < jm) break;
    leapJ = leapJ + div(jump, 33) * 8 + div(jump % 33, 4);
    jp = jm;
  }
  let n = jy - jp;
  leapJ = leapJ + div(n, 33) * 8 + div((n % 33) + 3, 4);
  if (jump % 33 === 4 && jump - n === 4) leapJ += 1;
  const leapG = div(jy + 621, 4) - div(div(jy + 621, 100) + 1, 4) * 3 - 150;
  const march = 20 + leapJ - leapG;
  if (jump - n < 6) n = n - jump + div(jump + 4, 33) * 33;
  let leap = (((n + 1) % 33) - 1) % 4;
  if (leap === -1) leap = 4;
  return { leap, march };
}

export function toJalali(date: Date): J {
  const gy = date.getFullYear(), gm = date.getMonth() + 1, gd = date.getDate();
  const jdn = g2d(gy, gm, gd);
  let jy = gy - 621;
  const r = jalCal(jy);
  const jdn1f = g2d(gy, 3, r.march);
  let k = jdn - jdn1f;
  if (k >= 0) {
    if (k <= 185) return { jy, jm: 1 + div(k, 31), jd: (k % 31) + 1 };
    k -= 186;
  } else {
    /* leap مربوط به سالِ *قبل از* کاهش است — اگر بعد از jy-- دوباره
       حساب شود، سالِ کبیسه اشتباه می‌شود. */
    jy -= 1;
    k += 179;
    if (r.leap === 1) k += 1;
  }
  return { jy, jm: 7 + div(k, 30), jd: (k % 30) + 1 };
}

export function fromJalali(jy: number, jm: number, jd: number): Date {
  const r = jalCal(jy);
  const g = d2g(
    g2d(jy + 621, 3, r.march) + (jm - 1) * 31 - div(jm, 7) * (jm - 7) + jd - 1
  );
  return new Date(g.gy, g.gm - 1, g.gd);
}

export const J_MONTHS = [
  "فروردین", "اردیبهشت", "خرداد", "تیر", "مرداد", "شهریور",
  "مهر", "آبان", "آذر", "دی", "بهمن", "اسفند",
];

export const jDaysInMonth = (jy: number, jm: number) =>
  jm <= 6 ? 31 : jm <= 11 ? 30 : jalCal(jy).leap === 1 ? 30 : 29;

const p2 = (n: number) => String(n).padStart(2, "0");
const fa = (s: string | number) => String(s).replace(/\d/g, (d) => "۰۱۲۳۴۵۶۷۸۹"[+d]);

/** ماهِ امن — اگر تبدیل خراب شد، به‌جای undefined خالی می‌دهد */
const mon = (jm: number) => J_MONTHS[Math.min(11, Math.max(0, jm - 1))] ?? "";

/** «۱۴۰۵/۰۵/۱۲» */
export const fmtJalali = (j: J) => fa(`${j.jy}/${p2(j.jm)}/${p2(j.jd)}`);

/** همان، با رقمِ لاتین — برای نامِ فایل و داده */
export const fmtJalaliRaw = (j: J) => `${j.jy}/${p2(j.jm)}/${p2(j.jd)}`;

export const todayJalali = () => fmtJalali(toJalali(new Date()));
export const todayJalaliRaw = () => fmtJalaliRaw(toJalali(new Date()));

/** «۱۲ مرداد ۱۴۰۵» */
export const longJalali = (j: J) => `${fa(j.jd)} ${mon(j.jm)} ${fa(j.jy)}`;

/** «YYYY-MM» میلادی → «مرداد ۱۴۰۵» برای نمایشِ انقضا */
export function expiryLabel(expiry: string | null): string {
  if (!expiry) return "—";
  const [y, m] = expiry.split(/[-/]/).map(Number);
  if (!y || !m) return "—";
  const j = toJalali(new Date(y, m - 1, 15));
  return `${mon(j.jm)} ${fa(j.jy)}`;
}
