const FA = "۰۱۲۳۴۵۶۷۸۹";

/** عدد → رشتهٔ فارسی با جداکنندهٔ هزار (٬) */
export function toFa(n: number | string, group = true): string {
  const s = String(n);
  const sign = s.startsWith("-") ? "−" : "";
  const body = sign ? s.slice(1) : s;

  const [int, frac] = body.split(".");
  let out = int;
  if (group) {
    let g = "", c = 0;
    for (let i = int.length - 1; i >= 0; i--) {
      g = int[i] + g;
      if (++c % 3 === 0 && i > 0) g = "٬" + g;
    }
    out = g;
  }
  if (frac) out += "٫" + frac;
  return sign + out.replace(/\d/g, (d) => FA[+d]);
}

/** رقمِ فارسی/عربی → لاتین (برای ورودیِ کاربر و جست‌وجو) */
export function toEn(s: string): string {
  return s
    .replace(/[۰-۹]/g, (d) => String("۰۱۲۳۴۵۶۷۸۹".indexOf(d)))
    .replace(/[٠-٩]/g, (d) => String("٠١٢٣٤٥٦٧٨٩".indexOf(d)));
}
