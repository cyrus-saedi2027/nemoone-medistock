/* لرزشِ لمسی — نقطهٔ اتصال برای Capacitor/RN بعداً */

type Kind = "tap" | "select" | "impact" | "success" | "warn";

export const Haptics = {
  enabled: true,
  impl: null as null | ((k: Kind) => void),
  fire(kind: Kind) {
    if (!Haptics.enabled) return;
    if (Haptics.impl) { try { Haptics.impl(kind); } catch {} return; }
    const ms: Record<Kind, number | number[]> = {
      tap: 6, select: 10, impact: [0, 14], success: [0, 12, 60, 22], warn: [0, 24],
    };
    try { navigator.vibrate?.(ms[kind] as number | number[]); } catch {}
  },
};

export const TAP = () => Haptics.fire("tap");
export const SELECT = () => Haptics.fire("select");
export const IMPACT = () => Haptics.fire("impact");
export const SUCCESS = () => Haptics.fire("success");
