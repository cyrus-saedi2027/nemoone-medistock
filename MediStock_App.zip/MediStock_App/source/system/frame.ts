/* ─────────────────────────────────────────────────────────────
 *  اندازهٔ واقعیِ قاب
 *
 *  هندسهٔ پس‌زمینه (منحنی‌ها، گهواره، اسلات‌ها) به عدد نیاز دارد.
 *  رفرنس عددِ ثابتِ ۳۷۵×۸۰۰ داشت؛ روی گوشیِ واقعی از جا در می‌رفت.
 *  اینجا قاب خودش را می‌سنجد و همه از همین‌جا می‌خوانند.
 * ───────────────────────────────────────────────────────────── */

import * as React from "react";

export type FrameSize = { w: number; h: number };

/** مقدارِ اولیه تا اولین اندازه‌گیری — هرگز صفر نمی‌دهیم که NaN نسازد */
export const FRAME_FALLBACK: FrameSize = { w: 390, h: 844 };

export const FrameCtx = React.createContext<FrameSize>(FRAME_FALLBACK);

export const useFrame = () => React.useContext(FrameCtx);

/** ارتفاعِ امنِ محتوا: از بالا تا جایی که نوارِ پایین شروع می‌شود */
export const contentBottom = (h: number) => h - 100;
