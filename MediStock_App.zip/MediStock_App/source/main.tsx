import * as React from "react";
import { createRoot } from "react-dom/client";
import App from "./App";
import { ThemeProvider, bootTheme, bootBg } from "@/system/theme/ThemeProvider";
import { StoreProvider } from "@/store/StoreProvider";

/* تم قبل از اولین رنگ‌آمیزی اعمال می‌شود تا هیچ پرشی دیده نشود */
const initialTheme = bootTheme();
const initialBg = bootBg();

createRoot(document.getElementById("root")!).render(
  <React.StrictMode>
    <ThemeProvider initial={initialTheme} initialBg={initialBg}>
      <StoreProvider>
        <App />
      </StoreProvider>
    </ThemeProvider>
  </React.StrictMode>
);

/* ── اینترو ─────────────────────────────────────────────────
 * به اینترو خبر می‌دهیم که اپ *واقعاً رنگ شده*، نه فقط اینکه
 * `render` صدا زده شده. دو `requestAnimationFrame` پشتِ سرِ هم
 * یعنی «بعد از فریمی که اولین محتوا در آن کشیده شد» — وگرنه
 * اینترو یک فریم زودتر می‌رفت و کاربر پرشِ سفید می‌دید.
 *
 * خودِ اینترو حدِ کمینهٔ زمان را نگه می‌دارد؛ اینجا فقط علامت می‌دهیم.
 * ───────────────────────────────────────────────────────── */
requestAnimationFrame(() =>
  requestAnimationFrame(() => (window as any).msIntroDone?.())
);

/* سرویس‌ورکر — بدونِ این، قطعِ آنتن یعنی اپ اصلاً باز نمی‌شود.
   ثبتش بعد از `load` است تا با بارگذاریِ اولِ صفحه رقابت نکند. */
if ("serviceWorker" in navigator && location.hostname !== "localhost") {
  window.addEventListener("load", () => {
    navigator.serviceWorker.register("/sw.js").catch(() => {
      /* شکستش نباید اپ را بشکند — فقط آفلاین کار نمی‌کند */
    });
  });
}
