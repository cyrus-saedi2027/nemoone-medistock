import * as React from "react";
import { PhoneFrame } from "@/ui/chrome/PhoneFrame";
import { PillNav, type NavItem } from "@/ui/chrome/PillNav";
import { Backdrop, ScreenBackdrop } from "@/ui/chrome/Backdrop";
import { NavScrim } from "@/ui/chrome/NavScrim";
import { OfflineBar } from "@/ui/chrome/OfflineBar";
import {
  ApiCtx, PushLayer, TabLayer, activeTheme, useRouterState,
} from "@/router/Router";
import { IconHome, IconGrid, IconBox, IconBell, IconUser } from "@/ui/icons";
import { HomeScreen } from "@/screens/tabs/Home";
import { CatalogScreen } from "@/screens/tabs/Catalog";
import { WarehousesScreen } from "@/screens/tabs/Warehouses";
import { AlertsScreen } from "@/screens/tabs/Alerts";
import { ProfileScreen } from "@/screens/tabs/Profile";
import { Login } from "@/screens/Login";
import { SCREENS } from "@/screens/routes";
import { ST, effectiveTheme, type ScreenKey } from "@/screens/screenThemes";
import { useUi, useActions } from "@/store/StoreProvider";
import { useTheme } from "@/system/theme/ThemeProvider";
import { ToastHost } from "@/ui/overlays/Sheet";
import { closeTopOverlay } from "@/ui/overlays/overlayStack";

const TABS: NavItem[] = [
  { key: "home",    fa: "خانه",    Icon: IconHome },
  { key: "catalog", fa: "کالاها",  Icon: IconGrid },
  { key: "wh",      fa: "انبارها", Icon: IconBox },
  { key: "alerts",  fa: "هشدارها", Icon: IconBell },
  { key: "profile", fa: "پروفایل", Icon: IconUser },
];

const TAB_KEYS: ScreenKey[] = ["home", "catalog", "warehouse", "alerts", "profile"];

export default function App() {
  const { session, toasts } = useUi();
  const { dropToast } = useActions();
  const { bg } = useTheme();

  /* نوارِ قرصی فنر ندارد؛ خودِ CSS باز شدنِ آیتم را انیمیت می‌کند. */
  const noop = React.useCallback(() => {}, []);
  const { state, api } = useRouterState(TABS.length, noop);

  /* نوارِ پایین فقط تب را عوض می‌کند؛ روتر مالکِ حالت است */
  const selectTab = React.useCallback((i: number) => api.goTab(i), [api]);

  /* با عوض‌شدنِ کاربر، ناوبری از صفرِ خودش شروع شود.
     روی گوشیِ مشترکِ داروخانه، نفرِ بعدی نباید وسطِ صفحه‌ای که نفرِ
     قبلی باز گذاشته بیفتد — چه گیج‌کننده است، چه نشتِ اطلاعات. */
  const uid = session?.id ?? null;
  React.useEffect(() => { api.resetAll(); }, [uid, api]);

  const stack = state.stacks[state.tab];
  /* پس‌زمینهٔ ریشه فقط تمِ *تب* را دنبال می‌کند. صفحه‌های روی پشته
     پس‌زمینهٔ خودشان را می‌آورند، وگرنه حینِ سوایپِ برگشت لایه شفاف
     می‌شود و صفحهٔ زیرین از پشتش دیده می‌شود. */
  const theme = effectiveTheme(session ? ST[TAB_KEYS[state.tab]] : ST.login, bg);

  /* دکمهٔ برگشتِ سخت‌افزاری/مرورگر → pop */
  React.useEffect(() => {
    const onPop = (e: PopStateEvent) => {
      /* اولویت: لایهٔ رویی → بعد پشتهٔ صفحه‌ها */
      if (closeTopOverlay()) { history.pushState(null, ""); return; }
      if (stack.length) { e.preventDefault?.(); api.pop(); history.pushState(null, ""); }
    };
    history.pushState(null, "");
    window.addEventListener("popstate", onPop);
    return () => window.removeEventListener("popstate", onPop);
  }, [stack.length, api]);

  const tabScreens = [
    <HomeScreen key="h" onTab={selectTab} />,
    <CatalogScreen key="c" />,
    <WarehousesScreen key="w" />,
    <AlertsScreen key="a" />,
    <ProfileScreen key="p" />,
  ];

  return (
    <PhoneFrame>
      <Backdrop />
      <OfflineBar />

      {!session ? (
        <Login />
      ) : (
        <ApiCtx.Provider value={api}>
          <TabLayer index={state.tab}>{tabScreens[state.tab]}</TabLayer>

          {stack.map((entry, i) => {
            const Screen = SCREENS[entry.key];
            if (!Screen) return null;
            return (
              <PushLayer key={entry.id} entry={entry} depth={i} onPop={api.pop}>
                <ScreenBackdrop />
                <Screen params={entry.params} onBack={api.pop} />
              </PushLayer>
            );
          })}

          {/* ترتیب مهم است: محو زیرِ قرص می‌نشیند، نه رویش */}
          <NavScrim />
          <PillNav items={TABS} index={state.tab} onSelect={selectTab} />
          <ToastHost items={toasts} onDrop={dropToast} />
        </ApiCtx.Provider>
      )}
    </PhoneFrame>
  );
}
