/* ─────────────────────────────────────────────────────────────
 *  فهرستِ قابلِ مدیریت — یک الگو برای همهٔ فهرست‌های سادهٔ مدیر
 *
 *  تأمین‌کننده‌ها، دسته‌ها، و هر فهرستِ نام‌محورِ دیگری از همین
 *  استفاده می‌کنند تا رفتار همه‌جا یکی باشد: افزودن، تغییرِ نام، حذف.
 *
 *  قانونِ حذف: چیزی که *استفاده شده* حذف نمی‌شود. اگر پارتی به یک
 *  تأمین‌کننده گره خورده باشد، حذفش یعنی ردیف‌هایی که به جایی اشاره
 *  می‌کنند که وجود ندارد. به‌جای پنهان‌کردنِ خطا، دلیلش را می‌گوییم.
 * ───────────────────────────────────────────────────────────── */

import * as React from "react";
import { v } from "@/system/theme/ThemeProvider";
import { SHADOW } from "@/system/tokens";
import { ScreenScroll } from "@/ui/chrome/ScreenScroll";
import { Header } from "@/ui/chrome/Header";
import { Gap, Pad, Button, Field, DarkRow, LightRow, IconSquare, Empty } from "@/ui/kit";
import { Num } from "@/ui/text/Text";
import { Reveal } from "@/ui/primitives/Motion";
import { Pressable } from "@/ui/primitives/Pressable";
import { IconPlus, IconEdit, IconTrash } from "@/ui/icons";
import { Sheet } from "@/ui/overlays/Sheet";
import type { ScreenTheme } from "@/screens/screenThemes";

export type ManageItem = { id: string | number; name: string; meta?: React.ReactNode; used: number };

export function ManageList({
  theme, sub, title, icon, items, canEdit, usedWord,
  onAdd, onRename, onRemove, onBack, addLabel, placeholder,
}: {
  theme: ScreenTheme;
  sub: string; title: string; icon: React.ComponentType<any>;
  items: ManageItem[];
  canEdit: boolean;
  /** واحدِ شمارش در پیامِ «حذف نشد» — مثلاً «پارت» یا «کالا» */
  usedWord: string;
  onAdd: (name: string) => void;
  onRename: (id: any, name: string) => void;
  onRemove: (id: any) => boolean;
  onBack: () => void;
  addLabel: string;
  placeholder: string;
}) {
  const dark = theme.low === "dark";
  const Row = dark ? DarkRow : LightRow;
  const [adding, setAdding] = React.useState(false);
  const [editing, setEditing] = React.useState<ManageItem | null>(null);
  const [name, setName] = React.useState("");
  const [err, setErr] = React.useState("");

  const openAdd = () => { setName(""); setErr(""); setAdding(true); };
  const openEdit = (it: ManageItem) => { setEditing(it); setName(it.name); setErr(""); };

  return (
    <>
      <ScreenScroll>
        <Header theme={theme} sub={sub} title={title} onBack={onBack} />

        <Pad style={{ marginTop: 16 }}>
          {items.length === 0 ? (
            <Empty icon={icon} tone={dark ? "dark" : "light"} title="هنوز چیزی ثبت نشده"
                   note={canEdit ? "با دکمهٔ پایین اولین مورد را اضافه کن." : undefined} />
          ) : (
            <div style={{ display: "grid", gap: 8 }}>
              {items.map((it, i) => (
                <Reveal key={it.id} i={Math.min(i, 10)} step={32}>
                  <Row height={60} style={dark ? { boxShadow: SHADOW.rowDark } : undefined}>
                    <IconSquare icon={icon} size={32} radius={10} iconSize={14}
                                tone={dark ? "dark" : "light"} />
                    <div style={{ flex: 1, minWidth: 0, marginInlineStart: 12 }}>
                      <div style={{ fontSize: 13, fontWeight: 700,
                                    color: dark ? v("deepInk") : v("ink"),
                                    whiteSpace: "nowrap", overflow: "hidden",
                                    textOverflow: "ellipsis" }}>{it.name}</div>
                      <div style={{ marginTop: 2, fontSize: 10.5,
                                    color: dark ? v("deepInkMuted") : v("inkFaint") }}>
                        {it.meta ?? <><Num value={it.used} /> {usedWord}</>}
                      </div>
                    </div>
                    {canEdit && (
                      <Pressable onPress={() => openEdit(it)} scale={0.88} ariaLabel={`ویرایشِ ${it.name}`}
                        style={{ width: 38, height: 38, borderRadius: 12, flex: "none",
                                 display: "grid", placeItems: "center",
                                 background: dark ? v("cardDarkAlt") : v("surfaceAlt"),
                                 color: dark ? v("deepInkMuted") : v("inkMuted") }}>
                        <IconEdit size={15} />
                      </Pressable>
                    )}
                  </Row>
                </Reveal>
              ))}
            </div>
          )}
        </Pad>

        {canEdit && (
          <Pad style={{ marginTop: 16 }}>
            <Button tone={dark ? "ghostDark" : "ghost"} icon={IconPlus} onPress={openAdd}>
              {addLabel}
            </Button>
          </Pad>
        )}
      </ScreenScroll>

      {/* افزودن */}
      <Sheet open={adding} onClose={() => setAdding(false)} title={addLabel}
        footer={
          <Button onPress={() => {
            const n = name.trim();
            if (n.length < 2) { setErr("نام خیلی کوتاه است"); return; }
            if (items.some((x) => x.name === n)) { setErr("همین نام از قبل هست"); return; }
            onAdd(n); setAdding(false);
          }}>ثبت</Button>
        }>
        <div style={{ paddingBlock: 8 }}>
          <Field label="نام" value={name} onChange={(s) => { setName(s); setErr(""); }}
                 placeholder={placeholder} autoFocus />
          <div style={{ minHeight: 18, marginTop: 6, fontSize: 11, fontWeight: 700,
                        color: v("crit"), textAlign: "center" }}>{err}</div>
        </div>
      </Sheet>

      {/* ویرایش / حذف */}
      <Sheet open={editing != null} onClose={() => setEditing(null)} title={editing?.name}
        footer={
          <div style={{ display: "grid", gap: 8 }}>
            <Button onPress={() => {
              const n = name.trim();
              if (n.length < 2) { setErr("نام خیلی کوتاه است"); return; }
              onRename(editing!.id, n); setEditing(null);
            }}>ذخیرهٔ نام</Button>
            <Button tone="danger" icon={IconTrash} onPress={() => {
              if (onRemove(editing!.id)) setEditing(null);
              else setErr(`اول باید ${usedWord}‌های وابسته را جابه‌جا کنی`);
            }}>حذف</Button>
          </div>
        }>
        <div style={{ paddingBlock: 8 }}>
          <Field label="نام" value={name} onChange={(s) => { setName(s); setErr(""); }} />
          <div style={{ minHeight: 18, marginTop: 6, fontSize: 11, fontWeight: 700,
                        color: v("crit"), textAlign: "center" }}>{err}</div>
          {editing && editing.used > 0 && (
            <div style={{ marginTop: 4, fontSize: 11, lineHeight: 1.9, textAlign: "center",
                          color: v("inkFaint") }}>
              الان <Num value={editing.used} /> {usedWord} به این وصل است.
            </div>
          )}
        </div>
      </Sheet>
    </>
  );
}
