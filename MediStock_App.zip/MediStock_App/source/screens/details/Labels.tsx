/* ─────────────────────────────────────────────────────────────
 *  برچسب‌های QR — ساخت و چاپ
 *
 *  خروجی PDFِ A4 است تا بشود مستقیم داد چاپخانه. هر برچسب: QR،
 *  نامِ لاتین، نامِ فارسی، و کدِ چهاررقمی.
 *
 *  سه دامنهٔ انتخاب چون هر سه واقعاً پیش می‌آید:
 *   • همه — یک‌بار در ابتدای راه‌اندازی
 *   • یک بازه — وقتی کاغذ تمام شد و از جایی که مانده ادامه می‌دهند
 *   • فقط تازه‌ها — کالاهایی که بعداً اضافه شده‌اند
 * ───────────────────────────────────────────────────────────── */

import * as React from "react";
import { v } from "@/system/theme/ThemeProvider";
import { R } from "@/system/tokens";
import { useData, useUi, useActions } from "@/store/StoreProvider";
import { ScreenScroll } from "@/ui/chrome/ScreenScroll";
import { Header } from "@/ui/chrome/Header";
import { Gap, Pad, Card, Button, Field, SectionLabel, Chip, Empty } from "@/ui/kit";
import { Num, Lat, Code } from "@/ui/text/Text";
import { IconQr, IconPrint, IconDownload } from "@/ui/icons";
import { useScreenTheme } from "@/screens/useScreenTheme";
import { can } from "@/domain/derive";
import { qrSvg } from "@/system/qr";
import { toEn, toFa } from "@/system/i18n/digits";
import { todayJalaliRaw } from "@/system/i18n/jalali";
import { KV } from "@/screens/details/Product";
import { LOCAL_ID_BASE } from "@/store/persist";

type Scope = "all" | "range" | "new";

/** چیدمان‌های ممکن روی A4 — درشت‌تر یعنی از فاصلهٔ دورتر خوانده می‌شود */
const LAYOUTS = [
  { key: "s", fa: "ریز · ۴۵ در برگه", cols: 5, rows: 9 },
  { key: "m", fa: "متوسط · ۳۲ در برگه", cols: 4, rows: 8 },
  { key: "l", fa: "درشت · ۱۸ در برگه", cols: 3, rows: 6 },
] as const;

export function LabelsScreen({ onBack }: { onBack: () => void }) {
  const { catalog } = useData();
  const { session } = useUi();
  const { toast } = useActions();
  const t = useScreenTheme("labels");

  const [scope, setScope] = React.useState<Scope>("all");
  const [from, setFrom] = React.useState("1");
  const [to, setTo] = React.useState("100");
  const [layout, setLayout] = React.useState<(typeof LAYOUTS)[number]["key"]>("m");
  const [busy, setBusy] = React.useState<{ done: number; total: number } | null>(null);

  const may = session ? can(session.role, "excel") : false;

  const chosen = React.useMemo(() => {
    /* ── «تازه» یعنی چه ────────────────────────────────────
       قبلاً `i >= LOCAL_ID_BASE` بود، یعنی «ساختِ همین گوشی و هنوز
       نرفته». ولی به‌محضِ اولین همگام‌سازی، سرور شناسهٔ واقعیِ کوچک
       می‌دهد و آن شرط دیگر هیچ‌کس را نمی‌گرفت — این گزینه همیشه
       خالی بود. کدِ کالا پشتِ سرِ هم بالا می‌رود، پس «تازه» یعنی
       دویست کدِ آخر؛ همان چیزی که آدم از این دکمه انتظار دارد. */
    if (scope === "new") {
      const codes = catalog
        .map((c) => Number(c.d))
        .filter((x) => Number.isFinite(x))
        .sort((a, b) => b - a);
      const cut = codes[Math.min(199, codes.length - 1)] ?? 0;
      return catalog.filter((c) => c.i >= LOCAL_ID_BASE || Number(c.d) >= cut);
    }
    if (scope === "range") {
      const a = Number(toEn(from).replace(/\D/g, "")) || 1;
      const b = Number(toEn(to).replace(/\D/g, "")) || a;
      const lo = Math.min(a, b), hi = Math.max(a, b);
      return catalog.filter((c) => {
        const n = Number(c.d);
        return Number.isFinite(n) && n >= lo && n <= hi;
      });
    }
    return catalog;
  }, [catalog, scope, from, to]);

  const lay = LAYOUTS.find((l) => l.key === layout)!;
  const perPage = lay.cols * lay.rows;
  const pages = Math.ceil(chosen.length / perPage) || 0;

  const sample = chosen[0] ?? catalog[0];

  if (!may) {
    return (
      <ScreenScroll>
        <Header theme={t} title="برچسب‌ها" onBack={onBack} />
        <Empty icon={IconQr} title="دسترسی نداری" />
      </ScreenScroll>
    );
  }

  const build = async () => {
    if (busy || !chosen.length) return;
    setBusy({ done: 0, total: pages });
    try {
      const { buildLabelPdf } = await import("@/system/labels");
      const { download } = await import("@/system/xlsx");
      const blob = await buildLabelPdf(
        chosen.map((c) => ({ code: c.d, nameFa: c.n, nameLat: c.l })),
        {
          cols: lay.cols, rows: lay.rows,
          onProgress: (done, total) => setBusy({ done, total }),
        },
      );
      download(blob, `medistock-labels-${todayJalaliRaw().replace(/\//g, "-")}.pdf`);
      toast("فایلِ برچسب ساخته شد", { tone: "ok" });
    } catch {
      toast("ساختِ برچسب نشد", { tone: "crit" });
    } finally {
      setBusy(null);
    }
  };

  return (
    <ScreenScroll>
      <Header theme={t} sub="برای چاپ و چسباندن" title="برچسب‌های بارکد" onBack={onBack} />

      {/* پیش‌نمایشِ یک برچسبِ واقعی — همان چیزی که چاپ می‌شود */}
      {sample && (
        <Pad style={{ marginTop: 16 }}>
          <Card>
            <SectionLabel>نمونهٔ برچسب</SectionLabel>
            <Gap h={12} />
            <div style={{ display: "grid", placeItems: "center" }}>
              <div style={{
                width: 168, padding: "12px 10px 10px", borderRadius: 12,
                border: `1.5px dashed ${v("divider")}`, background: "#fff",
                display: "grid", justifyItems: "center", gap: 6,
              }}>
                <div
                  aria-hidden
                  style={{ width: 92, height: 92 }}
                  dangerouslySetInnerHTML={{ __html: qrSvg(`MS-${sample.d}`, { size: 92, ecc: "Q" }) }}
                />
                {sample.l && (
                  <Lat style={{ fontSize: 9, color: "#333", textAlign: "center",
                                lineHeight: 1.3, maxWidth: 148,
                                overflow: "hidden", display: "block",
                                whiteSpace: "nowrap", textOverflow: "ellipsis" }}>
                    {sample.l}
                  </Lat>
                )}
                <div style={{ fontSize: 9.5, fontWeight: 700, color: "#111", textAlign: "center",
                              lineHeight: 1.5, maxWidth: 148, whiteSpace: "nowrap",
                              overflow: "hidden", textOverflow: "ellipsis" }}>
                  {sample.n}
                </div>
                <Code code={sample.d} style={{ fontSize: 13, color: "#000",
                                               letterSpacing: "0.08em" }} />
              </div>
            </div>
          </Card>
        </Pad>
      )}

      <Gap h={20} />

      <Pad>
        <SectionLabel>کدام کالاها</SectionLabel>
        <Gap h={10} />
        <div style={{ display: "flex", gap: 7, flexWrap: "wrap" }}>
          <Chip on={scope === "all"} onPress={() => setScope("all")}>همه</Chip>
          <Chip on={scope === "range"} onPress={() => setScope("range")}>بازهٔ کد</Chip>
          <Chip on={scope === "new"} onPress={() => setScope("new")}>فقط تازه‌ها</Chip>
        </div>

        {scope === "range" && (
          <>
            <Gap h={12} />
            <div style={{ display: "flex", gap: 10 }}>
              <div style={{ flex: 1 }}>
                <Field label="از کد" value={from} onChange={setFrom} ltr inputMode="numeric" />
              </div>
              <div style={{ flex: 1 }}>
                <Field label="تا کد" value={to} onChange={setTo} ltr inputMode="numeric" />
              </div>
            </div>
          </>
        )}
      </Pad>

      <Gap h={20} />

      <Pad>
        <SectionLabel>اندازهٔ برچسب</SectionLabel>
        <Gap h={10} />
        <div style={{ display: "flex", gap: 7, flexWrap: "wrap" }}>
          {LAYOUTS.map((l) => (
            <Chip key={l.key} on={layout === l.key} onPress={() => setLayout(l.key)}>{l.fa}</Chip>
          ))}
        </div>
      </Pad>

      <Gap h={20} />

      <Pad>
        <Card tone="dark">
          <div style={{ display: "grid", gap: 11 }}>
            <KV label="تعدادِ برچسب" value={<Num value={chosen.length} />} />
            <KV label="برگهٔ A4" value={<Num value={pages} />} />
            <KV label="در هر برگه" value={<Num value={perPage} />} />
          </div>

          <Gap h={16} />
          <Button icon={IconPrint} disabled={!chosen.length || !!busy} onPress={build}>
            {busy
              ? `در حالِ ساخت… برگهٔ ${toFa(busy.done)} از ${toFa(busy.total)}`
              : "ساخت و دانلودِ PDF"}
          </Button>

          {busy && (
            <>
              <Gap h={10} />
              <div style={{ height: 6, borderRadius: 99, background: v("cardDarkAlt"),
                            overflow: "hidden" }}>
                <i style={{
                  display: "block", height: "100%", borderRadius: 99,
                  width: `${Math.round((busy.done / Math.max(1, busy.total)) * 100)}%`,
                  background: v("accentStrong"), transition: "width 220ms linear",
                }} />
              </div>
            </>
          )}
        </Card>
      </Pad>

      <Pad style={{ marginTop: 14 }}>
        <div style={{ padding: "13px 15px", borderRadius: R.row, background: v("surfaceAlt"),
                      fontSize: 11, color: v("inkMuted"), lineHeight: 2 }}>
          برچسب‌ها را چاپ کنید و روی قفسه یا خودِ کالا بچسبانید. بعد از آن،
          با دکمهٔ بارکد در صفحهٔ کالاها می‌شود هر قلم را در یک لحظه پیدا کرد.
        </div>
      </Pad>

      <Pad style={{ marginTop: 10 }}>
        <div style={{ padding: "13px 15px", borderRadius: R.row, background: v("surfaceAlt"),
                      fontSize: 11, color: v("inkFaint"), lineHeight: 2,
                      display: "flex", gap: 8, alignItems: "flex-start" }}>
          <IconDownload size={15} style={{ marginTop: 3, flex: "none" }} />
          <span>
            ساختِ همهٔ برچسب‌ها روی گوشی کمی طول می‌کشد. اگر عجله دارید،
            بازهٔ کد را کوچک‌تر بگیرید.
          </span>
        </div>
      </Pad>
    </ScreenScroll>
  );
}
