/* بکاپ · تأمین‌کننده‌ها · داروخانه · اعلان‌ها · کاربران · تنظیمات */

import * as React from "react";
import { v, useTheme } from "@/system/theme/ThemeProvider";
import { R, SHADOW, EASE } from "@/system/tokens";
import { useData, useUi, useActions } from "@/store/StoreProvider";
import { ScreenScroll } from "@/ui/chrome/ScreenScroll";
import { Header, inkOf, inkSoftOf } from "@/ui/chrome/Header";
import {
  Gap, Pad, Card, Button, Field, SectionLabel, Empty, LightRow, DarkRow, IconSquare,
  StatBlock, Switch, ChoiceRow, PickerRow, Stepper,
} from "@/ui/kit";
import { Num, Lat } from "@/ui/text/Text";
import { Reveal } from "@/ui/primitives/Motion";
import {
  IconCloud, IconTruck, IconBell, IconUsers, IconGear, IconPlus,
  IconCheck, IconShield, IconSend, IconForward, IconInfo, IconQr,
  IconDownload, IconHistory, IconTag, IconTrash, IconUpload, IconRefresh, IconOut,
  IconFile as IconFileLike, IconClock as IconClockLike,
} from "@/ui/icons";
import type { Role } from "@/domain/types";
import { useScreenTheme } from "@/screens/useScreenTheme";
import { useNav } from "@/router/Router";
import { Sheet } from "@/ui/overlays/Sheet";
import { Pressable } from "@/ui/primitives/Pressable";
import { can } from "@/domain/derive";
import { ManageList } from "@/screens/details/ManageList";
import { THEMES, THEME_ORDER, type ThemeId } from "@/system/theme/palettes";
import { BG_STYLES, type BgStyle } from "@/system/theme/ThemeProvider";
import { todayJalali, todayJalaliRaw } from "@/system/i18n/jalali";
import { Haptics } from "@/system/haptics";
import { KV } from "@/screens/details/Product";
import { allSheets } from "@/domain/report";
import { APP_VERSION, BUILD_DATE, WHATS_NEW } from "@/system/version";

const ROLE_FA: Record<string, string> = {
  MANAGER: "مدیر", FOUNDER: "مؤسس", KEEPER: "انباردار", TECHNICIAN: "تکنسین",
};

/* ── پشتیبان‌گیری ─────────────────────────────────────────
 *
 * قبلاً این صفحه فقط *وعده* می‌داد: دکمه‌اش یک توست می‌داد و می‌گفت
 * «روی سرور ساخته می‌شود». یعنی تا راه‌اندازیِ سرور هیچ بکاپی وجود
 * نداشت — بدترین حالت برای دیتایی که کارفرما دارد وارد می‌کند.
 *
 * حالا بکاپِ کامل *همین‌جا روی گوشی* ساخته می‌شود، با اثرِ انگشتِ
 * SHA-256، و همان فایل دوباره قابلِ بازگرداندن است. بکاپی که
 * بازگرداندنش تست نشده باشد بکاپ نیست، پس دکمهٔ بازیابی هم هست.
 * ────────────────────────────────────────────────────────── */

/** اثرِ انگشتِ متن — برای تشخیصِ فایلِ دستکاری‌شده یا نصفه‌دانلود */
async function sha256(text: string) {
  const buf = await crypto.subtle.digest("SHA-256", new TextEncoder().encode(text));
  return Array.from(new Uint8Array(buf)).map((b) => b.toString(16).padStart(2, "0")).join("");
}

const kb = (n: number) =>
  n < 1024 ? `${n} بایت` : n < 1024 * 1024 ? `${(n / 1024).toFixed(0)} کیلوبایت`
  : `${(n / 1024 / 1024).toFixed(1)} مگابایت`;

type Restore =
  | { k: "idle" }
  | { k: "check"; payload: any; name: string; size: number; hash: string }
  | { k: "bad"; why: string };

export function BackupScreen({ onBack }: { onBack: () => void }) {
  const { catalog, batches, movements, warehouses, suppliers, users, cats, notifs } = useData();
  const { session } = useUi();
  const { snapshot, restoreSnapshot, toast } = useActions();
  const t = useScreenTheme("backup");
  const [busy, setBusy] = React.useState(false);
  const [last, setLast] = React.useState<{ at: string; hash: string; size: number } | null>(null);
  const [restore, setRestore] = React.useState<Restore>({ k: "idle" });
  const pick = React.useRef<HTMLInputElement>(null);

  const isAdmin = session ? can(session.role, "users") : false;

  const counts = [
    { fa: "کالاها", n: catalog.length },
    { fa: "پارت‌ها", n: batches.length },
    { fa: "حرکت‌ها", n: movements.length },
    { fa: "انبارها", n: warehouses.length },
    { fa: "تأمین‌کننده‌ها", n: suppliers.length },
    { fa: "دسته‌ها", n: cats.length },
    { fa: "کاربران", n: users.length },
    { fa: "اعلان‌ها", n: notifs.length },
  ];
  const totalRows = counts.reduce((s, c) => s + c.n, 0);

  /** بستهٔ JSON — کاملِ کامل، با اثرِ انگشت */
  const makeJson = async () => {
    if (busy) return;
    setBusy(true);
    try {
      const { download } = await import("@/system/xlsx");
      const payload = snapshot(session?.fullName ?? session?.username ?? null);
      const text = JSON.stringify(payload);
      const hash = await sha256(text);
      const blob = new Blob([JSON.stringify({ ...payload, sha256: hash }, null, 1)],
                            { type: "application/json" });
      const stamp = todayJalaliRaw().replace(/\//g, "-");
      download(blob, `medistock-backup-${stamp}.json`);
      setLast({ at: todayJalali(), hash, size: blob.size });
      toast("بکاپِ کامل ساخته شد", { tone: "ok" });
    } catch {
      toast("ساختِ بکاپ نشد", { tone: "crit" });
    } finally {
      setBusy(false);
    }
  };

  /** همان داده، ولی به‌شکلِ اکسلِ چندبرگه — برای بازرسیِ انسانی */
  const makeXlsx = async () => {
    if (busy) return;
    setBusy(true);
    try {
      const { buildXlsx, download } = await import("@/system/xlsx");
      const blob = await buildXlsx(allSheets({
        catalog, batches, movements, warehouses, suppliers, users, cats,
      }));
      download(blob, `medistock-backup-${todayJalaliRaw().replace(/\//g, "-")}.xlsx`);
      toast("نسخهٔ خواندنی ساخته شد", { tone: "ok" });
    } catch {
      toast("ساختِ فایل نشد", { tone: "crit" });
    } finally {
      setBusy(false);
    }
  };

  const onFile = async (f: File | undefined) => {
    if (!f) return;
    try {
      const text = await f.text();
      const obj = JSON.parse(text);
      const claimed = obj.sha256;
      delete obj.sha256;
      const hash = await sha256(JSON.stringify(obj));
      if (claimed && claimed !== hash) {
        setRestore({ k: "bad", why: "اثرِ انگشتِ فایل نمی‌خواند — فایل ناقص یا دستکاری شده" });
        return;
      }
      setRestore({ k: "check", payload: obj, name: f.name, size: f.size, hash });
    } catch {
      setRestore({ k: "bad", why: "فایل خوانده نشد — JSONِ معتبر نیست" });
    }
  };

  return (
    <>
      <ScreenScroll>
        <Header theme={t} sub="نگهداریِ داده" title="پشتیبان‌گیری" onBack={onBack} />

        <input ref={pick} type="file" accept=".json,application/json" style={{ display: "none" }}
               onChange={(e) => { onFile(e.target.files?.[0]); e.target.value = ""; }} />

        <Pad style={{ marginTop: 14 }}>
          <div style={{ display: "flex", gap: 8 }}>
            <StatBlock tone="dark" label="کلِ رکورد" value={<Num value={totalRows} />} />
            <StatBlock tone="dark" label="آخرین بکاپ" value={last?.at ?? "—"} />
            <StatBlock tone="dark" label="حجم" value={last ? kb(last.size) : "—"} />
          </div>
        </Pad>

        <Gap h={24} />

        <Pad>
          <SectionLabel>بکاپ روی همین گوشی</SectionLabel>
          <Gap h={10} />
          <Card>
            <div style={{ display: "flex", alignItems: "center", gap: 12 }}>
              <IconSquare icon={IconShield} size={44} radius={14} iconSize={20} tone="accent" />
              <div style={{ flex: 1, minWidth: 0 }}>
                <div style={{ fontSize: 14, fontWeight: 800, color: v("ink") }}>بستهٔ کاملِ داده</div>
                <div style={{ marginTop: 3, fontSize: 11, color: v("inkFaint"), lineHeight: 1.8 }}>
                  همه‌چیز در یک فایل — با همین می‌شود اپِ خالی را کامل برگرداند
                </div>
              </div>
            </div>

            <Gap h={16} />
            <div style={{ display: "grid", gap: 11 }}>
              {counts.map((c) => <KV key={c.fa} label={c.fa} value={<Num value={c.n} />} />)}
            </div>

            {last && (
              <>
                <Gap h={12} />
                <div style={{ padding: "10px 12px", borderRadius: R.row, background: v("okWash") }}>
                  <div style={{ fontSize: 10.5, fontWeight: 800, color: v("ok") }}>SHA-256</div>
                  <Lat style={{ fontSize: 10, color: v("ok"), wordBreak: "break-all",
                                lineHeight: 1.7 }}>{last.hash}</Lat>
                </div>
              </>
            )}

            <Gap h={16} />
            <Button icon={IconDownload} disabled={busy} onPress={makeJson}>
              {busy ? "در حالِ ساخت…" : "ساخت و دانلودِ بکاپ"}
            </Button>
            <Gap h={8} />
            <Button tone="ghost" icon={IconFileLike} disabled={busy} onPress={makeXlsx}>
              نسخهٔ خواندنی (اکسلِ ۸ برگه)
            </Button>
          </Card>
        </Pad>

        {isAdmin && (
          <>
            <Gap h={22} />
            <Pad>
              <SectionLabel>بازگرداندن</SectionLabel>
              <Gap h={10} />
              <Card>
                <div style={{ fontSize: 11.5, color: v("inkMuted"), lineHeight: 2 }}>
                  فایلِ بکاپ را بده تا اثرِ انگشت و تعدادِ ردیف‌هایش چک شود.
                  بعد از تأیید، <b style={{ color: v("ink") }}>همهٔ دادهٔ فعلی جایگزین می‌شود</b>.
                </div>
                <Gap h={14} />
                <Button tone="ghost" icon={IconUpload} onPress={() => pick.current?.click()}>
                  انتخابِ فایلِ بکاپ
                </Button>
              </Card>
            </Pad>
          </>
        )}

        <Gap h={22} />

        <Pad>
          <SectionLabel>بکاپِ خودکار روی سرور</SectionLabel>
          <Gap h={10} />
          <div style={{ display: "grid", gap: 8 }}>
            <InfoRow icon={IconClockLike} title="هر ۲ ساعت، به‌وقتِ تهران"
                     note="۱۲ نوبت در شبانه‌روز؛ آخرین ۱۴ روز نگه داشته می‌شود" />
            <InfoRow icon={IconDownload} title="dump.pgcustom"
                     note="نسخهٔ کاملِ دیتابیس — بازیابیِ بیت‌به‌بیت" />
            <InfoRow icon={IconInfo} title="data.jsonl"
                     note="هر جدول خط‌به‌خط، خوانا و قابلِ بازرسی" />
            <InfoRow icon={IconDownload} title="sheets/*.xlsx"
                     note="همین ۸ برگه — بدونِ هیچ ابزاری باز می‌شود" />
            <InfoRow icon={IconShield} title="manifest.json"
                     note="تعدادِ ردیفِ هر جدول + SHA-256 هر فایل و کلِ بسته" />
            <InfoRow icon={IconSend} title="ارسال به گروهِ بله"
                     note="بستهٔ بزرگ خودکار چندتکه می‌شود" />
          </div>
        </Pad>

        <Pad style={{ marginTop: 16 }}>
          <div style={{ padding: "13px 15px", borderRadius: R.row, background: v("surfaceAlt"),
                        fontSize: 11, color: v("inkMuted"), lineHeight: 2 }}>
            پشتیبانِ خودکار پس از راه‌اندازیِ سرور فعال می‌شود.
            پشتیبانِ دستیِ بالا همین حالا کار می‌کند و همان دادهٔ کامل را می‌دهد.
          </div>
        </Pad>
      </ScreenScroll>

      <Sheet
        open={restore.k !== "idle"}
        onClose={() => setRestore({ k: "idle" })}
        title={restore.k === "bad" ? "فایل قبول نشد" : "بازگرداندنِ بکاپ"}
        footer={
          restore.k === "check" ? (
            <div style={{ display: "grid", gap: 8 }}>
              <Button tone="danger" icon={IconRefresh} onPress={() => {
                const r = restoreSnapshot(restore.payload);
                if (r.ok) {
                  setRestore({ k: "idle" });
                  toast("بازگردانده شد", { tone: "ok" });
                } else {
                  setRestore({ k: "bad", why: r.why });
                }
              }}>بله، همه‌چیز را جایگزین کن</Button>
              <Button tone="ghost" onPress={() => setRestore({ k: "idle" })}>انصراف</Button>
            </div>
          ) : (
            <Button tone="ghost" onPress={() => setRestore({ k: "idle" })}>بستن</Button>
          )
        }
      >
        <div style={{ paddingBlock: 8 }}>
          {restore.k === "bad" && (
            <div style={{ fontSize: 12, lineHeight: 2, color: v("crit"), fontWeight: 700 }}>
              {restore.why}
            </div>
          )}
          {restore.k === "check" && (
            <>
              <div style={{ fontSize: 12.5, fontWeight: 800, color: v("ink"),
                            wordBreak: "break-all", marginBottom: 12 }}>
                {restore.name}
              </div>
              <div style={{ display: "grid", gap: 10 }}>
                <KV label="اثرِ انگشت" value="درست ✓" tint={v("ok")} />
                <KV label="حجم" value={kb(restore.size)} />
                <KV label="ساختِ" value={String(restore.payload?.createdAt ?? "—").slice(0, 10)} />
                {Object.entries(restore.payload?.counts ?? {}).map(([k, n]) => (
                  <KV key={k} label={k} value={<Num value={Number(n)} />} />
                ))}
              </div>
              <div style={{ marginTop: 14, padding: "11px 13px", borderRadius: R.row,
                            background: v("critWash"), fontSize: 11, fontWeight: 700,
                            color: v("crit"), lineHeight: 1.9 }}>
                دادهٔ فعلی (<Num value={totalRows} /> رکورد) پاک می‌شود و جایش
                این بسته می‌نشیند. اگر مطمئن نیستی، اول از وضعیتِ فعلی بکاپ بگیر.
              </div>
            </>
          )}
        </div>
      </Sheet>
    </>
  );
}

function InfoRow({ icon, title, note }: { icon: any; title: string; note: string }) {
  return (
    <LightRow height={62}>
      <IconSquare icon={icon} size={32} radius={10} iconSize={14} />
      <div style={{ flex: 1, minWidth: 0, marginInlineStart: 12 }}>
        <Lat style={{ fontSize: 11.5, fontWeight: 800, color: v("ink") }}>{title}</Lat>
        <div style={{ marginTop: 2, fontSize: 10.5, color: v("inkFaint") }}>{note}</div>
      </div>
    </LightRow>
  );
}

/* ── تأمین‌کننده‌ها ───────────────────────────────────── */
export function SuppliersScreen({ onBack }: { onBack: () => void }) {
  const { suppliers, batches } = useData();
  const { session } = useUi();
  const { addSupplier, renameSupplier, removeSupplier, toast } = useActions();
  const t = useScreenTheme("suppliers");
  const may = session ? can(session.role, "editProduct") : false;

  const items = React.useMemo(() => suppliers.map((s) => ({
    id: s.id, name: s.name,
    used: batches.reduce((n, b) => (b.supplierId === s.id ? n + 1 : n), 0),
  })), [suppliers, batches]);

  return (
    <ManageList
      theme={t} sub="شرکت‌های پخش" title="تأمین‌کننده‌ها" icon={IconTruck}
      items={items} canEdit={may} usedWord="پارت"
      addLabel="افزودنِ تأمین‌کننده" placeholder="مثلاً: پخش هجرت"
      onAdd={(n) => { addSupplier(n); toast("تأمین‌کننده اضافه شد", { tone: "ok" }); }}
      onRename={(id, n) => { renameSupplier(id, n); toast("نام عوض شد", { tone: "ok" }); }}
      onRemove={(id) => {
        const ok = removeSupplier(id);
        toast(ok ? "حذف شد" : "پارت‌های وابسته دارد", { tone: ok ? "ok" : "warn" });
        return ok;
      }}
      onBack={onBack}
    />
  );
}

/* ── دسته‌ها ──────────────────────────────────────────── */
export function CategoriesScreen({ onBack }: { onBack: () => void }) {
  const { cats, catalog } = useData();
  const { session } = useUi();
  const { addCategory, renameCategory, removeCategory, toast } = useActions();
  const t = useScreenTheme("categories");
  const may = session ? can(session.role, "editProduct") : false;

  const items = React.useMemo(() => cats.filter(Boolean).map((c) => ({
    id: c, name: c,
    used: catalog.reduce((n, x) => (x.c === c ? n + 1 : n), 0),
  })), [cats, catalog]);

  return (
    <ManageList
      theme={t} sub="گروه‌بندیِ کالاها" title="دسته‌ها" icon={IconTag}
      items={items} canEdit={may} usedWord="کالا"
      addLabel="افزودنِ دسته" placeholder="مثلاً: مکمل"
      onAdd={(n) => { addCategory(n); toast("دسته اضافه شد", { tone: "ok" }); }}
      onRename={(id, n) => {
        const ok = renameCategory(String(id), n);
        toast(ok ? "نام عوض شد — کالاهایش هم به‌روز شدند" : "این نام از قبل هست",
              { tone: ok ? "ok" : "warn" });
      }}
      onRemove={(id) => {
        const ok = removeCategory(String(id));
        toast(ok ? "حذف شد" : "کالای وابسته دارد", { tone: ok ? "ok" : "warn" });
        return ok;
      }}
      onBack={onBack}
    />
  );
}

/* ── علت‌های خروج ─────────────────────────────────────── */
export function OutReasonsScreen({ onBack }: { onBack: () => void }) {
  const { outReasons, movements } = useData();
  const { session } = useUi();
  const { addOutReason, renameOutReason, removeOutReason, toast } = useActions();
  const t = useScreenTheme("outReasons");
  const may = session ? can(session.role, "editProduct") : false;

  const items = React.useMemo(() => outReasons.map((r) => ({
    id: r, name: r,
    used: movements.reduce((n, m) => (m.reason === r ? n + 1 : n), 0),
  })), [outReasons, movements]);

  return (
    <ManageList
      theme={t} sub="وقتی کالا از انبار خارج می‌شود" title="علت‌های خروج" icon={IconOut}
      items={items} canEdit={may} usedWord="ثبت"
      addLabel="افزودنِ علت" placeholder="مثلاً: تبادل با داروخانهٔ دیگر"
      onAdd={(n) => {
        const ok = addOutReason(n);
        toast(ok ? "علت اضافه شد" : "همین علت از قبل هست", { tone: ok ? "ok" : "warn" });
      }}
      onRename={(id, n) => {
        const ok = renameOutReason(String(id), n);
        toast(ok ? "نام عوض شد — ثبت‌های قبلی هم به‌روز شدند" : "این نام از قبل هست",
              { tone: ok ? "ok" : "warn" });
      }}
      onRemove={(id) => {
        const ok = removeOutReason(String(id));
        toast(ok ? "حذف شد" : "در تاریخچه استفاده شده", { tone: ok ? "ok" : "warn" });
        return ok;
      }}
      onBack={onBack}
    />
  );
}

/* ── مشخصاتِ داروخانه ─────────────────────────────────── */
export function CompanyScreen({ onBack }: { onBack: () => void }) {
  const { toast } = useActions();
  const t = useScreenTheme("company");
  const [name, setName] = React.useState("داروخانهٔ دکتر سودی");
  const [owner, setOwner] = React.useState("دکتر امید سودی");
  const [phone, setPhone] = React.useState("");
  const [addr, setAddr] = React.useState("");

  return (
    <ScreenScroll>
      <Header theme={t} sub="اطلاعاتِ پایه" title="داروخانه" onBack={onBack} />
      <Pad style={{ marginTop: 16 }}>
        <Card tone="dark">
          <div style={{ display: "grid", gap: 12 }}>
            <Field tone="dark" label="نامِ داروخانه" value={name} onChange={setName} />
            <Field tone="dark" label="مسئولِ فنی" value={owner} onChange={setOwner} />
            <Field tone="dark" label="تلفن" value={phone} onChange={setPhone} ltr inputMode="numeric"
                   placeholder="0xx-xxxxxxx" />
            <Field tone="dark" label="نشانی" value={addr} onChange={setAddr} placeholder="خیابان…" />
          </div>
        </Card>
      </Pad>
      <Pad style={{ marginTop: 16 }}>
        <Button onPress={() => toast("ذخیره شد", { tone: "ok" })}>ذخیره</Button>
      </Pad>
    </ScreenScroll>
  );
}

/* ── اعلان‌ها ─────────────────────────────────────────── */
export function NotificationsScreen({ onBack }: { onBack: () => void }) {
  const { notifs } = useData();
  const { markNotifsRead } = useActions();
  const t = useScreenTheme("notifications");
  const unread = notifs.filter((n) => n.unread).length;

  React.useEffect(() => {
    const id = window.setTimeout(markNotifsRead, 1200);
    return () => window.clearTimeout(id);
  }, [markNotifsRead]);

  return (
    <ScreenScroll>
      <Header theme={t} sub={unread ? `${unread} نخوانده` : "همه خوانده شد"}
              title="اعلان‌ها" onBack={onBack} />
      <Pad style={{ marginTop: 18 }}>
        {notifs.length === 0 ? (
          <Card pad={0}><Empty icon={IconBell} title="اعلانی نیست" /></Card>
        ) : (
          <div style={{ display: "grid", gap: 8 }}>
            {notifs.map((n, i) => (
              <Reveal key={n.id} i={i} step={34}>
                <LightRow height={64}>
                  <IconSquare
                    icon={n.kind === "expiry" ? IconHistory : n.kind === "stock" ? IconCloud : IconBell}
                    size={32} radius={10} iconSize={14}
                    color={n.kind === "stock" ? v("crit") : v("warn")} />
                  <div style={{ flex: 1, minWidth: 0, marginInlineStart: 12 }}>
                    <div style={{ fontSize: 12.5, fontWeight: n.unread ? 800 : 600,
                                  color: n.unread ? v("ink") : v("inkMuted"),
                                  whiteSpace: "nowrap", overflow: "hidden",
                                  textOverflow: "ellipsis" }}>{n.title}</div>
                    <div style={{ marginTop: 2, fontSize: 10.5, color: v("inkFaint") }}>{n.meta}</div>
                  </div>
                  <div style={{ display: "grid", gap: 5, justifyItems: "end", flex: "none" }}>
                    <span style={{ fontSize: 9.5, fontWeight: 700, color: v("inkFaint") }}>{n.time}</span>
                    {n.unread && <i style={{ width: 6, height: 6, borderRadius: 99, background: v("attn") }} />}
                  </div>
                </LightRow>
              </Reveal>
            ))}
          </div>
        )}
      </Pad>
    </ScreenScroll>
  );
}

/* ── کاربران ──────────────────────────────────────────── */
export function UsersScreen({ onBack }: { onBack: () => void }) {
  const { users, movements } = useData();
  const { session } = useUi();
  const nav = useNav();
  const t = useScreenTheme("users");
  const may = session ? can(session.role, "users") : false;

  if (!may) {
    return (
      <ScreenScroll>
        <Header theme={t} title="کاربران" onBack={onBack} />
        <Empty icon={IconUsers} title="دسترسی نداری" note="فقط مدیر می‌تواند کاربران را ببیند." />
      </ScreenScroll>
    );
  }

  return (
    <ScreenScroll>
      <Header theme={t} sub={`${users.length} حساب`} title="کاربران" onBack={onBack} />

      <Pad style={{ marginTop: 16 }}>
        <Button icon={IconPlus} onPress={() => nav.push("userNew")}>کاربرِ جدید</Button>
      </Pad>

      <Pad style={{ marginTop: 14 }}>
        <div style={{ display: "grid", gap: 8 }}>
          {users.map((u, i) => (
            <Reveal key={u.id} i={i} step={36}>
              <DarkRow height={66} onPress={() => nav.push("userOne", { id: u.id })}
                       style={{ background: v("card"), boxShadow: SHADOW.soft }}>
                <div style={{ width: 38, height: 38, borderRadius: 13, flex: "none",
                              display: "grid", placeItems: "center",
                              background: v("accentSurface"), color: v("accentSurfaceInk"),
                              fontSize: 12.5, fontWeight: 800 }}>{u.initials}</div>
                <div style={{ flex: 1, minWidth: 0, marginInlineStart: 12 }}>
                  <div style={{ fontSize: 13, fontWeight: 700, color: v("deepInk") }}>
                    {u.fullName ?? u.username}
                  </div>
                  <div style={{ marginTop: 2, fontSize: 10.5, color: v("deepInkMuted") }}>
                    {ROLE_FA[u.role]} · <Num value={movements.filter((m) => m.userId === u.id).length} /> ثبت
                  </div>
                </div>
                {!u.isActive && (
                  <span style={{ fontSize: 9.5, fontWeight: 800, color: v("crit"),
                                 background: v("cardDarkAlt"), padding: "3px 8px",
                                 borderRadius: 999, flex: "none" }}>غیرفعال</span>
                )}
                <IconForward size={15} stroke={2} color={v("deepInkMuted")}
                             style={{ marginInlineStart: 8 }} />
              </DarkRow>
            </Reveal>
          ))}
        </div>
      </Pad>
    </ScreenScroll>
  );
}

/* ── نقش‌ها، با توضیحِ کاری که می‌کنند ───────────────── */
const ROLES: { id: Role; fa: string; note: string }[] = [
  { id: "MANAGER",    fa: "مدیر",     note: "همه‌چیز: کاربران، بکاپ، مشخصاتِ داروخانه" },
  { id: "FOUNDER",    fa: "مؤسس",     note: "همه‌چیز، مثلِ مدیر — صاحبِ داروخانه" },
  { id: "KEEPER",     fa: "انباردار", note: "ورود و خروج و انبارگردانی؛ بدونِ کاربران و بکاپ" },
  { id: "TECHNICIAN", fa: "تکنسین",   note: "فقط دیدن و گزارش؛ بدونِ اکسل" },
];

/* ── کاربرِ جدید ──────────────────────────────────────── */
export function UserNewScreen({ onBack }: { onBack: () => void }) {
  const { session } = useUi();
  const { addUser, toast } = useActions();
  const t = useScreenTheme("userNew");
  const [username, setUsername] = React.useState("");
  const [fullName, setFullName] = React.useState("");
  const [role, setRole] = React.useState<Role>("KEEPER");
  const [p1, setP1] = React.useState("");
  const [err, setErr] = React.useState("");

  const may = session ? can(session.role, "users") : false;
  if (!may) {
    return (
      <ScreenScroll>
        <Header theme={t} title="کاربرِ جدید" onBack={onBack} />
        <Empty icon={IconUsers} title="دسترسی نداری" note="فقط مدیر می‌تواند کاربر بسازد." />
      </ScreenScroll>
    );
  }

  /* نامِ کاربری لاتینِ کوچک: انباردار روی صفحه‌کلیدِ فارسی تایپ می‌کند و
     «ali» با «علی» یکی نیست — این محدودیت جلوی کلیِ درگیری را می‌گیرد. */
  const uname = username.trim().toLowerCase();
  const okName = /^[a-z][a-z0-9._-]{2,19}$/.test(uname);
  const ok = okName && p1.length >= 4 && fullName.trim().length >= 2;

  return (
    <ScreenScroll>
      <Header theme={t} sub="ساختِ حساب" title="کاربرِ جدید" onBack={onBack} />

      <Pad style={{ marginTop: 16 }}>
        <Card>
          <div style={{ display: "grid", gap: 12 }}>
            <Field label="نام و نام خانوادگی" value={fullName} autoFocus
                   onChange={(s) => { setFullName(s); setErr(""); }}
                   placeholder="مثلاً: رضا کریمی" />
            <Field label="نام کاربری (لاتین)" value={username} ltr
                   onChange={(s) => { setUsername(s); setErr(""); }}
                   placeholder="reza" suffix={<IconUsers size={16} color={v("inkFaint")} />} />
            <Field label="رمز عبور" value={p1} type="password" ltr
                   onChange={(s) => { setP1(s); setErr(""); }} />
          </div>
          <div style={{ minHeight: 18, marginTop: 8, fontSize: 11, fontWeight: 700,
                        color: v("crit"), textAlign: "center", lineHeight: 1.8 }}>
            {err ||
             (username && !okName ? "نام کاربری: ۳ تا ۲۰ نویسهٔ لاتین، با حرف شروع شود" :
              p1 && p1.length < 4 ? "رمز حداقل ۴ نویسه" : "")}
          </div>
        </Card>
      </Pad>

      <Gap h={20} />

      <Pad>
        <SectionLabel>نقش</SectionLabel>
        <Gap h={10} />
        <div style={{ display: "grid", gap: 8 }}>
          {ROLES.map((r) => (
            <ChoiceRow key={r.id} label={r.fa} meta={r.note} on={r.id === role}
                       onPress={() => setRole(r.id)} />
          ))}
        </div>
      </Pad>

      <Pad style={{ marginTop: 20 }}>
        <Button disabled={!ok} onPress={() => {
          if (!ok) return;
          if (!addUser({ username: uname, fullName, role, password: p1 })) {
            setErr("این نام کاربری از قبل هست");
            return;
          }
          toast("کاربر ساخته شد", { tone: "ok" });
          onBack();
        }}>ساختِ حساب</Button>
      </Pad>
    </ScreenScroll>
  );
}

/* ── کاربرِ تکی: ویرایش · رمز · فعال/غیرفعال · حذف ───── */
export function UserOneScreen({
  params, onBack,
}: { params: { id: number; self?: boolean }; onBack: () => void }) {
  const { users, movements } = useData();
  const { session } = useUi();
  const { setUserActive, updateUser, setPassword, removeUser, toast } = useActions();
  const t = useScreenTheme("userOne");
  const u = users.find((x) => x.id === params.id);
  const [p1, setP1] = React.useState("");
  const [p2, setP2] = React.useState("");
  const [name, setName] = React.useState(u?.fullName ?? "");
  const [role, setRole] = React.useState<Role>(u?.role ?? "KEEPER");
  const [pickRole, setPickRole] = React.useState(false);
  const [confirmDel, setConfirmDel] = React.useState(false);
  const isAdmin = session ? can(session.role, "users") : false;
  const isSelf = session?.id === params.id;

  if (!u) {
    return (
      <ScreenScroll>
        <Header theme={t} title="کاربر" onBack={onBack} />
        <Empty icon={IconUsers} title="این کاربر پیدا نشد" />
      </ScreenScroll>
    );
  }

  const nMoves = movements.filter((m) => m.userId === u.id).length;
  const nManagers = users.filter((x) => x.role === "MANAGER").length;
  const lastManager = u.role === "MANAGER" && nManagers <= 1;
  const okPass = p1.length >= 4 && p1 === p2;
  const dirty = name.trim() !== (u.fullName ?? "") || role !== u.role;

  return (
    <>
      <ScreenScroll>
        <Header theme={t} sub={ROLE_FA[u.role]} title={u.fullName ?? u.username} onBack={onBack} />

        <Pad style={{ marginTop: 14 }}>
          <div style={{ display: "flex", gap: 8 }}>
            <StatBlock tone="dark" label="نام کاربری" value={<span dir="ltr">{u.username}</span>} />
            <StatBlock tone="dark" label="ثبت‌ها" value={<Num value={nMoves} />} />
            <StatBlock tone="dark" label="وضعیت" value={u.isActive ? "فعال" : "غیرفعال"}
                       tint={u.isActive ? undefined : v("crit")} />
          </div>
        </Pad>

        <Gap h={24} />

        {isAdmin && (
          <Pad>
            <SectionLabel>مشخصات</SectionLabel>
            <Gap h={10} />
            <Card>
              <Field label="نام و نام خانوادگی" value={name} onChange={setName} />
            </Card>
            <Gap h={8} />
            {/* نامِ کاربری عوض نمی‌شود: کلیدِ ورود است و اگر تغییر کند،
                کسی که رمزش را دارد دیگر نمی‌تواند وارد شود. */}
            <PickerRow icon={IconShield} label="نقش" value={ROLE_FA[role]}
                       onPress={() => setPickRole(true)} />
            {lastManager && role !== "MANAGER" && (
              <div style={{ marginTop: 8, padding: "11px 13px", borderRadius: R.row,
                            background: v("warnWash"), fontSize: 11, fontWeight: 700,
                            color: v("warn"), lineHeight: 1.9 }}>
                این تنها مدیرِ سیستم است. اگر نقشش را عوض کنی، دیگر هیچ‌کس
                نمی‌تواند کاربر بسازد.
              </div>
            )}
            <Gap h={12} />
            <Button disabled={!dirty || (lastManager && role !== "MANAGER")} onPress={() => {
              updateUser(u.id, { fullName: name, role });
              toast("مشخصات به‌روز شد", { tone: "ok" });
            }}>ذخیرهٔ مشخصات</Button>
          </Pad>
        )}

        <Gap h={22} />

        {(isSelf || isAdmin) && (
          <Pad>
            <SectionLabel>تغییرِ رمز</SectionLabel>
            <Gap h={10} />
            <Card>
              <div style={{ display: "grid", gap: 12 }}>
                <Field label="رمزِ جدید" value={p1} onChange={setP1} type="password" ltr />
                <Field label="تکرارِ رمز" value={p2} onChange={setP2} type="password" ltr />
              </div>
              <div style={{ minHeight: 16, marginTop: 8, fontSize: 11, fontWeight: 700,
                            color: v("crit"), textAlign: "center" }}>
                {p1 && p1.length < 4 ? "رمز حداقل ۴ نویسه" : p2 && p1 !== p2 ? "تکرار یکی نیست" : ""}
              </div>
              <Button disabled={!okPass} onPress={() => {
                setPassword(u.id, p1);
                setP1(""); setP2("");
                toast("رمز عوض شد", { tone: "ok" });
              }}>ذخیرهٔ رمز</Button>
            </Card>
          </Pad>
        )}

        {isAdmin && !isSelf && (
          <>
            <Pad style={{ marginTop: 18 }}>
              <LightRow height={58}>
                <IconSquare icon={IconShield} size={32} radius={10} iconSize={14} />
                <div style={{ flex: 1, minWidth: 0, marginInlineStart: 12 }}>
                  <div style={{ fontSize: 12.5, fontWeight: 700, color: v("ink") }}>حسابِ فعال</div>
                  <div style={{ fontSize: 10.5, color: v("inkFaint") }}>غیرفعال یعنی نمی‌تواند وارد شود</div>
                </div>
                <Switch on={u.isActive} onChange={(on) => {
                  setUserActive(u.id, on);
                  toast(on ? "حساب فعال شد" : "حساب غیرفعال شد", { tone: on ? "ok" : "warn" });
                }} />
              </LightRow>
            </Pad>

            <Pad style={{ marginTop: 10 }}>
              <Button tone="danger" icon={IconTrash} onPress={() => setConfirmDel(true)}>
                حذفِ حساب
              </Button>
            </Pad>
          </>
        )}
      </ScreenScroll>

      <Sheet open={pickRole} onClose={() => setPickRole(false)} title="نقش">
        <div style={{ display: "grid", gap: 8, paddingBlock: 6 }}>
          {ROLES.map((r) => (
            <ChoiceRow key={r.id} label={r.fa} meta={r.note} on={r.id === role}
                       onPress={() => { setRole(r.id); setPickRole(false); }} />
          ))}
        </div>
      </Sheet>

      <Sheet open={confirmDel} onClose={() => setConfirmDel(false)} title="حذفِ حساب"
        footer={
          <div style={{ display: "grid", gap: 8 }}>
            <Button tone="danger" icon={IconTrash} disabled={nMoves > 0 || lastManager}
              onPress={() => {
                const r = removeUser(u.id);
                if (r === true) {
                  setConfirmDel(false);
                  toast("حساب حذف شد", { tone: "ok" });
                  onBack();
                } else {
                  toast(r === "used" ? "این کاربر ثبت دارد" : "آخرین مدیر است", { tone: "warn" });
                }
              }}>
              {nMoves > 0 || lastManager ? "نمی‌شود حذف کرد" : "بله، حذف کن"}
            </Button>
            <Button tone="ghost" onPress={() => setConfirmDel(false)}>انصراف</Button>
          </div>
        }>
        <div style={{ paddingBlock: 10, fontSize: 12, lineHeight: 2, color: v("inkMuted") }}>
          {nMoves > 0 ? (
            <>
              این کاربر <b style={{ color: v("ink") }}><Num value={nMoves} /></b> ثبت در
              تاریخچه دارد. اگر حذف شود، آن ردیف‌ها به کاربرِ ناموجود اشاره
              می‌کنند. به‌جایش <b style={{ color: v("ink") }}>غیرفعالش کن</b> —
              دیگر نمی‌تواند وارد شود ولی تاریخچه سالم می‌ماند.
            </>
          ) : lastManager ? (
            <>تنها مدیرِ سیستم است. اگر حذف شود هیچ‌کس نمی‌تواند کاربر بسازد.</>
          ) : (
            <>حسابِ «{u.fullName ?? u.username}» پاک می‌شود. این کار برگشت ندارد.</>
          )}
        </div>
      </Sheet>
    </>
  );
}

/* ── تنظیمات + انتخابگرِ تم ──────────────────────────── */
export function SettingsScreen({ onBack }: { onBack: () => void }) {
  const { id, setTheme } = useTheme();
  const { policy, pending } = useData();
  const { session } = useUi();
  const { setPolicy, toast } = useActions();
  const t = useScreenTheme("settings");
  const [haptic, setHaptic] = React.useState(Haptics.enabled);
  const isAdmin = session ? can(session.role, "users") : false;

  return (
    <>
      <ScreenScroll>
        <Header theme={t} sub="ظاهر و رفتار" title="تنظیمات" onBack={onBack} />

        {/* انتخابگرِ پس‌زمینه حذف شد: حالا فقط یک سبک داریم و
            گزینه‌ای که فقط یک انتخاب دارد، گزینه نیست. */}
        <Pad style={{ marginTop: 16 }}>
          <SectionLabel>تمِ رنگی</SectionLabel>
          <Gap h={10} />
          <div style={{ display: "grid", gridTemplateColumns: "repeat(3,1fr)", gap: 8 }}>
            {THEME_ORDER.map((k) => (
              <ThemeSwatch key={k} id={k} on={k === id} onPress={() => { setTheme(k); }} />
            ))}
          </div>
        </Pad>

        <Gap h={24} />

        <Pad>
          <SectionLabel>رفتار</SectionLabel>
          <Gap h={10} />
          <div style={{ display: "grid", gap: 8 }}>
            <LightRow height={58}>
              <IconSquare icon={IconGear} size={32} radius={10} iconSize={14} />
              <div style={{ flex: 1, minWidth: 0, marginInlineStart: 12 }}>
                <div style={{ fontSize: 12.5, fontWeight: 700, color: v("ink") }}>لرزشِ لمسی</div>
                <div style={{ fontSize: 10.5, color: v("inkFaint") }}>بازخوردِ کوتاه هنگامِ زدنِ دکمه</div>
              </div>
              <Switch on={haptic} onChange={(on) => { Haptics.enabled = on; setHaptic(on); }} />
            </LightRow>

            {/* ── بارکد و QR ─────────────────────────────────
                پیش‌فرض خاموش. تا وقتی داروخانه برچسب نچسبانده، دکمهٔ
                اسکن و صفحهٔ چاپِ برچسب فقط سردرگمی‌اند. فقط مدیر
                می‌تواند عوضش کند چون روی همه اثر دارد. */}
            {isAdmin && (
              <LightRow height={68}>
                <IconSquare icon={IconQr} size={32} radius={10} iconSize={14} />
                <div style={{ flex: 1, minWidth: 0, marginInlineStart: 12 }}>
                  <div style={{ fontSize: 12.5, fontWeight: 700, color: v("ink") }}>
                    بارکد و QR
                  </div>
                  <div style={{ fontSize: 10.5, color: v("inkFaint"), lineHeight: 1.7 }}>
                    چاپِ برچسب و اسکن با دوربین · پیش‌فرض خاموش
                  </div>
                </div>
                <Switch on={policy.qrEnabled} label="بارکد و QR"
                        onChange={(on) => {
                          setPolicy({ qrEnabled: on });
                          toast(on ? "بارکد روشن شد — دکمهٔ اسکن در «کالاها» آمد"
                                   : "بارکد خاموش شد", { tone: "ok" });
                        }} />
              </LightRow>
            )}
          </div>
        </Pad>

        {/* ── تأییدِ اختلافِ انبارگردانی ─────────────────────
            پیش‌فرض خاموش است و عمداً هم خاموش می‌ماند: قابلیتی که کسی
            نخواسته و بی‌صدا روشن باشد، اولین باری که جلوی کار را
            بگیرد باگ به نظر می‌رسد. ────────────────────────── */}
        {isAdmin && (
          <>
            <Gap h={22} />
            <Pad>
              <SectionLabel>انبارگردانی</SectionLabel>
              <Gap h={10} />
              <div style={{ display: "grid", gap: 8 }}>
                <LightRow height={64}>
                  <IconSquare icon={IconShield} size={32} radius={10} iconSize={14} />
                  <div style={{ flex: 1, minWidth: 0, marginInlineStart: 12 }}>
                    <div style={{ fontSize: 12.5, fontWeight: 700, color: v("ink") }}>
                      تأییدِ اختلافِ بزرگ
                    </div>
                    <div style={{ fontSize: 10.5, color: v("inkFaint"), lineHeight: 1.7 }}>
                      اختلافِ بیشتر از حد، تا تأییدِ تو اعمال نمی‌شود
                    </div>
                  </div>
                  <Switch on={policy.stocktakeApproval} label="تأییدِ اختلافِ بزرگ"
                          onChange={(on) => {
                            setPolicy({ stocktakeApproval: on });
                            toast(on ? "از این به بعد تأیید لازم است" : "تأیید لازم نیست",
                                  { tone: on ? "warn" : "ok" });
                          }} />
                </LightRow>

                {policy.stocktakeApproval && (
                  <Card>
                    <div style={{ fontSize: 11.5, fontWeight: 700, color: v("ink") }}>
                      آستانه: بیشتر از <Num value={policy.stocktakeThreshold} /> عدد
                    </div>
                    <div style={{ marginTop: 4, fontSize: 10.5, color: v("inkFaint"),
                                  lineHeight: 1.8 }}>
                      اختلافِ کمتر یا برابرِ این عدد همان‌جا اعمال می‌شود.
                      خودِ مدیر هیچ‌وقت معطلِ تأیید نمی‌ماند.
                    </div>
                    <Gap h={12} />
                    <Stepper value={policy.stocktakeThreshold} min={1} max={999}
                             onChange={(n) => setPolicy({ stocktakeThreshold: n })} />
                  </Card>
                )}

                {pending.length > 0 && (
                  <div style={{ padding: "12px 14px", borderRadius: R.row,
                                background: v("warnWash"), fontSize: 11, fontWeight: 700,
                                color: v("warn"), lineHeight: 1.9 }}>
                    <Num value={pending.length} /> اختلاف منتظرِ توست — در صفحهٔ
                    «انبارگردانی» رسیدگی کن.
                  </div>
                )}
              </div>
            </Pad>
          </>
        )}

        <Gap h={22} />

        <Pad>
          <SectionLabel>دربارهٔ برنامه</SectionLabel>
          <Gap h={10} />
          <Card>
            <div style={{ display: "grid", gap: 11 }}>
              <KV label="نسخه" value={<Lat style={{ fontSize: 12, color: v("ink") }}>{APP_VERSION}</Lat>} />
              <KV label="تاریخِ این نسخه" value={BUILD_DATE} />
              <KV label="دامنه" value={<Lat style={{ fontSize: 12, color: v("ink") }}>medistock.ir</Lat>} />
              <KV label="تاریخِ امروز" value={todayJalali()} />
              <KV label="حالتِ آفلاین" value="فعال" tint={v("ok")} />
            </div>
          </Card>
        </Pad>

        {/* ── تازه‌ها ─────────────────────────────────────────
            چرا داخلِ خودِ اپ و نه یک فایلِ کنار: کسی که گوشی دستش
            است هیچ‌وقت پوشهٔ پروژه را باز نمی‌کند. اگر نداند چه چیزی
            عوض شده، هر تغییرِ رفتار به نظرش خرابی می‌آید. */}
        <Gap h={22} />
        <Pad>
          <SectionLabel>تازه‌ها</SectionLabel>
          <Gap h={10} />
          <div style={{ display: "grid", gap: 8 }}>
            {WHATS_NEW.slice(0, 3).map((rel, i) => (
              <Card key={rel.v}>
                <div style={{ display: "flex", alignItems: "center", gap: 8 }}>
                  <Lat style={{ fontSize: 12, fontWeight: 800, color: v("ink") }}>{rel.v}</Lat>
                  {i === 0 && (
                    <span style={{ fontSize: 9.5, fontWeight: 800, padding: "2px 7px",
                                   borderRadius: 99, background: v("okWash"), color: v("ok") }}>
                      همین نسخه
                    </span>
                  )}
                  <span style={{ marginInlineStart: "auto", fontSize: 10.5, color: v("inkFaint") }}>
                    {rel.date}
                  </span>
                </div>
                <div style={{ marginTop: 8, display: "grid", gap: 5 }}>
                  {rel.items.map((it) => (
                    <div key={it} style={{ display: "flex", gap: 7, fontSize: 11,
                                           color: v("inkMuted"), lineHeight: 1.9 }}>
                      <span style={{ color: v("inkFaint") }}>·</span>
                      <span style={{ flex: 1 }}>{it}</span>
                    </div>
                  ))}
                </div>
              </Card>
            ))}
          </div>
        </Pad>

        <Pad style={{ marginTop: 14 }}>
          <div style={{ padding: "13px 15px", borderRadius: R.row, background: v("surfaceAlt"),
                        fontSize: 11, color: v("inkMuted"), lineHeight: 2 }}>
            این برنامه هیچ درخواستی به بیرون از ایران نمی‌فرستد.
            در قطعیِ اینترنتِ بین‌الملل کاملاً کار می‌کند.
          </div>
        </Pad>
      </ScreenScroll>
    </>
  );
}

/** پیش‌نمایشِ کوچکِ سبکِ پس‌زمینه — همان هندسه، در ابعادِ ریز */

function ThemeSwatch({ id, on, onPress }: { id: ThemeId; on: boolean; onPress: () => void }) {
  const th = THEMES[id];
  return (
    <Pressable onPress={onPress} scale={0.95}
      style={{
        width: "100%", padding: 10, borderRadius: R.row,
        background: v("card"), boxShadow: SHADOW.soft,
        border: `1.5px solid ${on ? v("accentStrong") : "transparent"}`,
        transition: `border-color 200ms ${EASE.out}`,
      }}>
      <div style={{ display: "flex", gap: 4, height: 30, borderRadius: 9, overflow: "hidden" }}>
        <i style={{ flex: 2, background: th.p.accentSurface }} />
        <i style={{ flex: 1, background: th.p.deep }} />
        <i style={{ flex: 1, background: th.p.canvas, border: `1px solid ${th.p.divider}` }} />
      </div>
      <div style={{ marginTop: 8, display: "flex", alignItems: "center", gap: 5 }}>
        <span style={{ fontSize: 11, fontWeight: 800, color: v("ink") }}>{th.fa}</span>
        {on && <IconCheck size={12} stroke={3} color={v("accentStrong")} />}
      </div>
    </Pressable>
  );
}
