/* ورود / خروج / انتقال — یک جریان، سه حالت */

import * as React from "react";
import { v } from "@/system/theme/ThemeProvider";
import { R, SHADOW } from "@/system/tokens";
import { useData, useUi, useActions } from "@/store/StoreProvider";
import { ScreenScroll } from "@/ui/chrome/ScreenScroll";
import { Header } from "@/ui/chrome/Header";
import {
  Gap, Pad, Card, Button, Stepper, PickerRow, ChoiceRow, Field, SectionLabel, Empty,
  LightRow, Switch,
} from "@/ui/kit";
import { Num, Lat, Code } from "@/ui/text/Text";
import {
  IconPill, IconBox, IconTruck, IconCal, IconTag, IconSearch, IconIn, IconPlus, IconFilter, IconCheck,
} from "@/ui/icons";
import {
  FilterPanel, EMPTY_FILTERS, countActive, passes, type Filters,
} from "@/ui/list/SearchFilters";
import { ST } from "@/screens/screenThemes";
import { useNav } from "@/router/Router";
import { Sheet } from "@/ui/overlays/Sheet";
import { expiryLabel, toJalali, J_MONTHS } from "@/system/i18n/jalali";
import { parseQuery, matches, type Query } from "@/domain/search";
import { VirtualList } from "@/ui/list/VirtualList";
import { Pressable } from "@/ui/primitives/Pressable";
import type { MoveType } from "@/domain/types";
import { can, expiryText, defaultWarehouseId } from "@/domain/derive";
import { serverIdOf } from "@/store/sync";
import { LOCAL_ID_BASE } from "@/store/persist";

type Params = { productId?: number; batchId?: number };

const TITLE: Record<MoveType, string> = { IN: "ورود کالا", OUT: "خروج کالا", TRANSFER: "انتقال" };
const THEME: Record<MoveType, any> = { IN: ST.moveIn, OUT: ST.moveOut, TRANSFER: ST.transfer };

export function MoveScreen({
  type, params, onBack,
}: { type: MoveType; params: Params; onBack: () => void }) {
  const { catalog, batches, warehouses, suppliers, outReasons } = useData();
  const { session } = useUi();
  const { commitMove, addBatch, toast } = useActions();
  const nav = useNav();
  const t = THEME[type];

  const initialBatch = params.batchId ?? null;
  const initialProduct =
    params.productId ?? (initialBatch ? batches.find((b) => b.id === initialBatch)?.productId ?? null : null);

  const [productId, setProductId] = React.useState<number | null>(initialProduct);
  const [batchId, setBatchId] = React.useState<number | null>(initialBatch);
  const [qty, setQty] = React.useState(1);
  const [reason, setReason] = React.useState(outReasons[0] ?? "");
  const [toWh, setToWh] = React.useState<number | null>(null);
  const [note, setNote] = React.useState("");
  const [sheet, setSheet] = React.useState<null | "product" | "batch" | "reason" | "wh" | "newBatch">(null);

  /* پارتِ تازه — فقط در حالتِ ورود */
  const [nbWh, setNbWh] = React.useState<number>(defaultWarehouseId(warehouses));
  const [nbSup, setNbSup] = React.useState<number | null>(suppliers[0]?.id ?? null);
  const [nbYear, setNbYear] = React.useState(new Date().getFullYear() + 2);
  const [nbMonth, setNbMonth] = React.useState(new Date().getMonth() + 1);
  /* «این کالا اصلاً انقضا ندارد» — شانه، قیف، تجهیزات. بدونِ این
     گزینه، انباردار مجبور بود یک تاریخِ الکی بگذارد و بعد همان
     تاریخِ الکی هشدارِ انقضا می‌داد. */
  const [nbNoExp, setNbNoExp] = React.useState(false);

  const product = productId != null ? catalog.find((c) => c.i === productId) ?? null : null;
  const myBatches = React.useMemo(
    () => (productId == null ? [] : batches.filter((b) => b.productId === productId)),
    [batches, productId]
  );
  const batch = batchId != null ? batches.find((b) => b.id === batchId) ?? null : null;

  React.useEffect(() => {
    if (batch && batch.productId !== productId) setBatchId(null);
  }, [productId, batch]);

  /* ── دنبال کردنِ پارتِ تازه بعد از همگام‌سازی ─────────────
   * پارتی که همین الان ساخته شد شناسهٔ محلی دارد. یک لحظه بعد صف
   * می‌رود، سرور شناسهٔ واقعی را می‌دهد و ردیفِ محلی برداشته می‌شود.
   * تا دیروز `batchId` روی همان شناسهٔ محلی می‌ماند، پس انتخاب بی‌صدا
   * می‌پرید و انباردار باید دوباره «پارت» را می‌زد و همان پارت را
   * انتخاب می‌کرد — دقیقاً همان چیزی که در «ورود کالا» آزاردهنده بود.
   *
   * `learnIds` قبل از `applyState` اجرا می‌شود، پس همان لحظه‌ای که
   * ردیف از فهرست می‌رود، نگاشت جواب را دارد. */
  React.useEffect(() => {
    if (batchId == null || batchId < LOCAL_ID_BASE) return;
    if (batches.some((b) => b.id === batchId)) return;
    const mapped = serverIdOf(batchId);
    if (mapped != null) setBatchId(mapped);
  }, [batches, batchId]);

  const mayMove = session ? can(session.role, "move") : false;

  const max = type === "IN" ? 99999 : batch?.qty ?? 0;
  const ready =
    mayMove && !!product && !!batch && qty > 0 && qty <= max &&
    (type !== "TRANSFER" || (toWh != null && toWh !== batch?.warehouseId));

  const submit = () => {
    if (!ready || !batch || !session) return;
    const id = commitMove(
      { type, batchId: batch.id, qty, reason: type === "OUT" ? reason : null,
        toWarehouseId: type === "TRANSFER" ? toWh : null, note: note || null },
      session.id
    );
    nav.push("receipt", { movementId: id, type, qty, productName: product?.n, lot: batch.lotCode });
  };

  if (!mayMove) {
    return (
      <ScreenScroll>
        <Header theme={t} title={TITLE[type]} onBack={onBack} />
        <Empty icon={IconBox} title="دسترسیِ ثبت نداری"
               note="نقشِ تو فقط‌خواندنی است. برای ثبتِ حرکت از مدیر دسترسی بگیر." />
      </ScreenScroll>
    );
  }

  return (
    <>
      <ScreenScroll>
        <Header theme={t} sub="ثبتِ حرکت" title={TITLE[type]} onBack={onBack} />

        <Pad style={{ marginTop: 16 }}>
          <div style={{ display: "grid", gap: 8 }}>
            <PickerRow icon={IconPill} label="کالا" value={product?.n} onPress={() => setSheet("product")} />
            <PickerRow icon={IconBox} label="پارت"
              value={batch ? <Lat style={{ fontSize: 13, color: v("ink"), fontWeight: 700 }}>{batch.lotCode}</Lat> : undefined}
              onPress={() => productId == null ? setSheet("product") : setSheet("batch")} />
          </div>
        </Pad>

        {batch && (
          <Pad style={{ marginTop: 10 }}>
            <div style={{
              display: "flex", alignItems: "center", gap: 8, padding: "10px 13px",
              borderRadius: R.row, background: v("surfaceAlt"), fontSize: 11, color: v("inkMuted"),
            }}>
              <span>موجودیِ فعلی: <b style={{ color: v("ink") }}><Num value={batch.qty} /></b></span>
              <i style={{ flex: 1 }} />
              <span>انقضا {expiryText(batch, expiryLabel)}</span>
            </div>
          </Pad>
        )}

        <Gap h={20} />

        {/* از اینجا به بعد زیرِ منحنی است و ورقه سیاه — پس همه‌چیز تیره */}
        <Pad>
          <SectionLabel tone="dark">تعداد</SectionLabel>
          <Gap h={10} />
          <Card tone="dark">
            <Stepper value={qty} onChange={setQty} min={1} max={Math.max(1, max)} tone="dark" />
            {type !== "IN" && batch && qty > batch.qty && (
              <div style={{ marginTop: 10, fontSize: 11.5, fontWeight: 700, color: v("crit"),
                            textAlign: "center" }}>
                بیشتر از موجودی است (<Num value={batch.qty} /> عدد)
              </div>
            )}
            <div style={{ display: "flex", gap: 6, marginTop: 12 }}>
              {[5, 10, 20, 50].map((n) => (
                <Pressable key={n} onPress={() => setQty((q) => Math.min(Math.max(1, max), q + n))}
                  scale={0.93}
                  style={{ flex: 1, height: 38, borderRadius: 999, display: "flex",
                           alignItems: "center", justifyContent: "center", whiteSpace: "nowrap",
                           background: v("cardDarkAlt"), fontSize: 11.5,
                           fontWeight: 800, color: v("deepInk") }}>
                  +<Num value={n} />
                </Pressable>
              ))}
            </div>
          </Card>
        </Pad>

        <Gap h={20} />

        <Pad>
          <div style={{ display: "grid", gap: 8 }}>
            {type === "OUT" && (
              <PickerRow icon={IconTag} label="علتِ خروج" value={reason} tone="dark"
                         onPress={() => setSheet("reason")} />
            )}
            {type === "TRANSFER" && (
              <PickerRow icon={IconBox} label="انبارِ مقصد" tone="dark"
                value={toWh != null ? warehouses.find((w) => w.id === toWh)?.name : undefined}
                onPress={() => setSheet("wh")} />
            )}
            <Card pad={13} tone="dark">
              <Field label="توضیح (اختیاری)" value={note} onChange={setNote} tone="dark"
                     placeholder="مثلاً: تحویل به بخشِ نسخه‌پیچی" />
            </Card>
          </div>
        </Pad>

        <Gap h={22} />

        <Pad>
          <Button onPress={submit} disabled={!ready}>
            ثبتِ {TITLE[type]}
          </Button>
          {!ready && (
            <div style={{ marginTop: 8, fontSize: 11, color: v("deepInkMuted"), textAlign: "center" }}>
              {!product ? "اول کالا را انتخاب کن"
                : !batch ? "پارت را انتخاب کن"
                : type === "TRANSFER" && toWh == null ? "انبارِ مقصد را انتخاب کن"
                : type === "TRANSFER" && toWh === batch.warehouseId ? "مقصد با مبدأ یکی است"
                : "تعداد بیشتر از موجودی است"}
            </div>
          )}
        </Pad>
      </ScreenScroll>

      {/* شیتِ انتخابِ کالا — مجازی، روی ۵۰۱۰ ردیف */}
      <ProductSheet
        open={sheet === "product"}
        onClose={() => setSheet(null)}
        onPick={(id) => { setProductId(id); setBatchId(null); setSheet("batch"); }}
      />

      {/* شیتِ انتخابِ پارت */}
      <Sheet open={sheet === "batch"} onClose={() => setSheet(null)} title="انتخابِ پارت">
        <div style={{ display: "grid", gap: 8, paddingBlock: 6 }}>
          {myBatches.length === 0 && type !== "IN" && (
            <Empty icon={IconBox} title="پارتی موجود نیست" note="اول با «ورود کالا» یک پارت بساز." />
          )}
          {myBatches.map((b) => (
            <ChoiceRow key={b.id} on={b.id === batchId}
              label={<Lat style={{ fontSize: 12.5, fontWeight: 800, color: v("ink") }}>{b.lotCode}</Lat>}
              meta={<>{warehouses.find((w) => w.id === b.warehouseId)?.name} · انقضا {expiryText(b, expiryLabel)} · موجودی <Num value={b.qty} /></>}
              onPress={() => { setBatchId(b.id); setQty(1); setSheet(null); }} />
          ))}
          {type === "IN" && (
            <Button tone="ghost" onPress={() => setSheet("newBatch")} icon={IconPlus}>
              پارتِ جدید بساز
            </Button>
          )}
        </div>
      </Sheet>

      {/* شیتِ پارتِ جدید */}
      <Sheet
        open={sheet === "newBatch"}
        onClose={() => setSheet(null)}
        title="پارتِ جدید"
        footer={
          <Button
            disabled={productId == null}
            onPress={() => {
              if (productId == null) return;
              const id = addBatch({
                productId, supplierId: nbSup, warehouseId: nbWh, qty: 0,
                expiry: nbNoExp ? null : `${nbYear}-${String(nbMonth).padStart(2, "0")}`,
                noExpiry: nbNoExp, entryDate: null,
              } as any);
              setBatchId(id);
              setQty(1);
              setSheet(null);
              toast("پارت ساخته شد", { tone: "ok" });
            }}>بساز</Button>
        }
      >
        <div style={{ display: "grid", gap: 8, paddingBlock: 6 }}>
          <SectionLabel>محلِ نگهداری</SectionLabel>
          {warehouses.map((w) => (
            <ChoiceRow key={w.id} label={w.name} on={w.id === nbWh} onPress={() => setNbWh(w.id)} />
          ))}
          <Gap h={6} />
          <SectionLabel>تأمین‌کننده</SectionLabel>
          {suppliers.length === 0 ? (
            <div style={{ fontSize: 11, color: v("inkFaint"), lineHeight: 1.9, paddingBlock: 4 }}>
              هنوز تأمین‌کننده‌ای ثبت نشده. می‌توانی بعداً از «انبارها ← تأمین‌کننده‌ها»
              اضافه کنی؛ ساختنِ پارت بدونِ آن هم ممکن است.
            </div>
          ) : suppliers.map((s) => (
            <ChoiceRow key={s.id} label={s.name} on={s.id === nbSup} onPress={() => setNbSup(s.id)} />
          ))}
          <Gap h={6} />
          <SectionLabel>تاریخِ انقضا (میلادی)</SectionLabel>
          <LightRow height={58}>
            <div style={{ flex: 1, minWidth: 0 }}>
              <div style={{ fontSize: 12.5, fontWeight: 700, color: v("ink") }}>
                تاریخِ انقضا ندارد
              </div>
              <div style={{ fontSize: 10.5, color: v("inkFaint") }}>
                مثلِ شانه و قیف و تجهیزات
              </div>
            </div>
            <Switch on={nbNoExp} label="تاریخِ انقضا ندارد" onChange={setNbNoExp} />
          </LightRow>
          {!nbNoExp && (
            <>
              <div style={{ display: "flex", gap: 8 }}>
                <div style={{ flex: 1 }}>
                  <Field label="سال" value={String(nbYear)} ltr inputMode="numeric"
                         onChange={(s) => setNbYear(Number(s.replace(/\D/g, "")) || nbYear)} />
                </div>
                <div style={{ flex: 1 }}>
                  <Field label="ماه" value={String(nbMonth)} ltr inputMode="numeric"
                         onChange={(s) => {
                           const n = Number(s.replace(/\D/g, ""));
                           if (n >= 1 && n <= 12) setNbMonth(n);
                         }} />
                </div>
              </div>
              <div style={{ fontSize: 11, color: v("inkFaint") }}>
                یعنی «{expiryLabel(`${nbYear}-${String(nbMonth).padStart(2, "0")}`)}» شمسی
              </div>
            </>
          )}
        </div>
      </Sheet>

      {/* شیتِ علت */}
      <Sheet open={sheet === "reason"} onClose={() => setSheet(null)} title="علتِ خروج">
        <div style={{ display: "grid", gap: 8, paddingBlock: 6 }}>
          {outReasons.map((r) => (
            <ChoiceRow key={r} label={r} on={r === reason}
                       onPress={() => { setReason(r); setSheet(null); }} />
          ))}
        </div>
      </Sheet>

      {/* شیتِ انبارِ مقصد */}
      <Sheet open={sheet === "wh"} onClose={() => setSheet(null)} title="انبارِ مقصد">
        <div style={{ display: "grid", gap: 8, paddingBlock: 6 }}>
          {warehouses.filter((w) => w.id !== batch?.warehouseId).map((w) => (
            <ChoiceRow key={w.id} label={w.name} on={w.id === toWh}
                       onPress={() => { setToWh(w.id); setSheet(null); }} />
          ))}
        </div>
      </Sheet>
    </>
  );
}

/* ── شیتِ انتخابِ کالا: مجازی، وگرنه ۵۰۱۰ ردیف شیت را می‌کشد ──
 *
 * `onPick` عمداً `onClose` را صدا نمی‌زند: والد ممکن است بخواهد بلافاصله
 * شیتِ بعدی (انتخابِ پارت) را باز کند، و بستنِ ما بعد از آن اجرا می‌شد و
 * همان لحظه شیتِ تازه را می‌بست. بستن با خودِ والد است.
 */
/**
 * انتخابگرِ کالا — تکی یا چندتایی.
 *
 * در حالتِ چندتایی (`multi`) شیت با هر انتخاب بسته نمی‌شود؛ تیک
 * می‌خورد و کاربر ادامه می‌دهد. انباردار که ۱۵ قلم را با هم می‌آورد،
 * نباید ۱۵ بار شیت را باز کند.
 */
export function ProductSheet({
  open, onClose, onPick, multi, selected, onDone,
}: {
  open: boolean; onClose: () => void; onPick: (id: number) => void;
  multi?: boolean;
  selected?: Set<number>;
  onDone?: () => void;
}) {
  const { catalog, cats, batches, warehouses, suppliers } = useData();
  const [q, setQ] = React.useState("");
  const [dq, setDq] = React.useState<Query>({ mode: "none" });
  const [showFilters, setShowFilters] = React.useState(false);
  const [filters, setFilters] = React.useState<Filters>(EMPTY_FILTERS);
  const box = React.useRef<HTMLDivElement>(null);

  React.useEffect(() => {
    const id = setTimeout(() => setDq(parseQuery(q)), 90);
    return () => clearTimeout(id);
  }, [q]);

  const batchesOf = React.useMemo(() => {
    const m = new Map<number, typeof batches>();
    for (const b of batches) {
      const a = m.get(b.productId);
      if (a) a.push(b); else m.set(b.productId, [b]);
    }
    return (id: number) => m.get(id) ?? [];
  }, [batches]);

  const nFilters = countActive(filters);

  /* بدونِ سقف — همان دلیلِ کاتالوگ: شیت هم فهرستِ مجازی دارد، پس
     بریدنِ نتیجه فقط کاربر را از کالای خودش محروم می‌کرد. کسی که
     دنبالِ قلمِ ۳۰۱اُم بود، آن را «نداریم» می‌دید. */
  const items = React.useMemo(() => {
    if (dq.mode === "none" && !nFilters) return catalog;
    const out = [];
    for (const r of catalog) {
      if (!matches(r, dq)) continue;
      if (nFilters && !passes(r, filters, batchesOf)) continue;
      out.push(r);
    }
    return out;
  }, [catalog, dq, filters, nFilters, batchesOf]);

  const nSel = selected?.size ?? 0;

  return (
    <Sheet open={open} onClose={onClose}
           title={multi ? "انتخابِ کالاها" : "انتخابِ کالا"}
           footer={multi ? (
             <Button disabled={nSel === 0} onPress={() => { onDone?.(); onClose(); }}>
               {nSel ? <>افزودنِ <Num value={nSel} /> کالا</> : "چیزی انتخاب نشده"}
             </Button>
           ) : undefined}>
      <div style={{ paddingBlock: 6 }}>
        <div style={{ display: "flex", gap: 8 }}>
          <div style={{
            flex: 1, minWidth: 0,
            display: "flex", alignItems: "center", gap: 9, height: 46,
            borderRadius: 999, paddingInline: 14, background: v("card"),
            border: `1.5px solid ${v("divider")}`,
          }}>
            <IconSearch size={16} color={v("inkFaint")} />
            <input value={q} onChange={(e) => setQ(e.target.value)} placeholder="نام دارو، یا ‎#کد"
              style={{ flex: 1, minWidth: 0, border: 0, outline: 0, background: "none",
                       fontSize: 13, fontWeight: 600, fontFamily: "inherit", color: v("ink") }} />
          </div>
          <Pressable onPress={() => setShowFilters((x) => !x)} scale={0.92}
            ariaLabel={showFilters ? "بستنِ فیلترها" : "بازکردنِ فیلترها"}
            style={{
              width: 46, height: 46, flex: "none", borderRadius: 15, position: "relative",
              display: "grid", placeItems: "center",
              background: showFilters || nFilters ? v("accentStrong") : v("surfaceAlt"),
              color: showFilters || nFilters ? v("accentStrongInk") : v("ink"),
            }}>
            <IconFilter size={19} stroke={2.4} />
            {nFilters > 0 && !showFilters && (
              <span style={{
                position: "absolute", top: -4, insetInlineEnd: -4,
                minWidth: 18, height: 18, paddingInline: 4, borderRadius: 999,
                background: v("crit"), color: "#fff",
                fontSize: 10, fontWeight: 800, display: "grid", placeItems: "center",
              }}><Num value={nFilters} /></span>
            )}
          </Pressable>
        </div>

        <FilterPanel open={showFilters} filters={filters} set={setFilters}
                     cats={cats.filter((c) => c && c !== "دستمزد ساخت")}
                     warehouses={warehouses} suppliers={suppliers} />

        <div ref={box} style={{ height: 340, overflowY: "auto", marginTop: 10, overscrollBehavior: "contain" }}>
          {items.length === 0 ? (
            <Empty icon={IconSearch} title="چیزی پیدا نشد" />
          ) : (
            <VirtualList items={items} rowHeight={58} scrollRef={box}>
              {(r: any) => {
                const on = !!selected?.has(r.i);
                return (
                  <Pressable onPress={() => onPick(r.i)} haptic={false} scale={0.99}
                    style={{ display: "block", width: "100%", height: 50 }}>
                    <div style={{ height: "100%", display: "flex", alignItems: "center", gap: 10,
                                  background: v("card"), borderRadius: R.field, paddingInline: 12,
                                  boxShadow: SHADOW.soft,
                                  border: on ? `1.5px solid ${v("accentStrong")}` : "1.5px solid transparent" }}>
                      {multi && (
                        <span style={{
                          width: 20, height: 20, borderRadius: 7, flex: "none",
                          display: "grid", placeItems: "center",
                          background: on ? v("accentStrong") : "transparent",
                          border: on ? "none" : `1.5px solid ${v("divider")}`,
                        }}>
                          {on && <IconCheck size={12} stroke={3} color={v("accentStrongInk")} />}
                        </span>
                      )}
                      <div style={{ flex: 1, minWidth: 0 }}>
                        <div style={{ fontSize: 12.5, fontWeight: 700, color: v("ink"),
                                      whiteSpace: "nowrap", overflow: "hidden",
                                      textOverflow: "ellipsis" }}>{r.n}</div>
                      </div>
                      <Code code={r.d} style={{ fontSize: 10, flex: "none" }} />
                      <div style={{ fontSize: 11.5, fontWeight: 700, color: v("inkFaint"), flex: "none" }}>
                        <Num value={r.q} />
                      </div>
                    </div>
                  </Pressable>
                );
              }}
            </VirtualList>
          )}
        </div>
      </div>
    </Sheet>
  );
}
