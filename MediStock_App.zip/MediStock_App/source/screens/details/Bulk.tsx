/* ─────────────────────────────────────────────────────────────
 *  ثبتِ گروهی — ورود · خروج · انتقال، چند کالا با هم
 *
 *  تا قبل از این فقط تک‌کالا جابه‌جا می‌شد و همین صفحه هم فقط ورود و
 *  خروج داشت و کالاها را یکی‌یکی می‌گرفت. انبارداری که با محمولهٔ
 *  ۲۰ قلمی برمی‌گردد، بیست بار همان مسیر را می‌رفت.
 *
 *  حالا: یک‌بار انتخابِ چندتایی، بعد برای هر ردیف تعداد. پارت خودکار
 *  انتخاب می‌شود (نزدیک‌ترین انقضا — قانونِ FEFO) و اگر لازم شد دستی
 *  عوض می‌شود. علت و انبارِ مقصد یک‌بار برای همهٔ ردیف‌ها تعیین می‌شود.
 *
 *  ── چرا «ورود» خودش پارت می‌سازد ──
 *  اپ خالی تحویل می‌شود؛ هیچ کالایی پارت ندارد. اگر ورودِ گروهی فقط
 *  روی پارت‌های موجود کار کند، دقیقاً در روزِ اول — همان روزی که یک
 *  محمولهٔ بیست‌قلمی می‌رسد — بی‌فایده است. پس در حالتِ ورود، خطی که
 *  پارت ندارد پارتِ تازه‌اش را همان‌جا می‌سازد: انبار و تأمین‌کننده
 *  یک‌بار برای کلِ محموله، انقضا برای هر قلم جدا.
 * ───────────────────────────────────────────────────────────── */

import * as React from "react";
import { v } from "@/system/theme/ThemeProvider";
import { R } from "@/system/tokens";
import { useData, useUi, useActions } from "@/store/StoreProvider";
import { ScreenScroll } from "@/ui/chrome/ScreenScroll";
import { Header } from "@/ui/chrome/Header";
import {
  Gap, Pad, Card, Button, Chip, ChoiceRow, PickerRow, SectionLabel, Empty, Stepper, Field, Switch,
} from "@/ui/kit";
import { Num, Lat, Code } from "@/ui/text/Text";
import {
  IconIn, IconOut, IconSwap, IconList, IconPlus, IconTrash, IconBox, IconTag, IconForward,
  IconTruck,
} from "@/ui/icons";
import { useScreenTheme } from "@/screens/useScreenTheme";
import { useNav } from "@/router/Router";
import { Sheet } from "@/ui/overlays/Sheet";
import { ProductSheet } from "@/screens/details/Move";
import { Pressable } from "@/ui/primitives/Pressable";
import { can, expiryText, defaultWarehouseId } from "@/domain/derive";
import { expiryLabel } from "@/system/i18n/jalali";
import { toFa, toEn } from "@/system/i18n/digits";

type BulkLine = {
  key: number;
  productId: number;
  /** `null` یعنی «پارتِ تازه بساز» — فقط در حالتِ ورود معنا دارد */
  batchId: number | null;
  qty: number;
  /** «YYYY-MM» یا خالی — فقط وقتی پارتِ تازه ساخته می‌شود */
  expY: string;
  expM: string;
  /** «این قلم انقضا ندارد» — وقتی تیک بخورد، دو فیلدِ بالا پنهان می‌شوند */
  expNone: boolean;
};

const KINDS = [
  { k: "IN" as const, fa: "ورود", icon: IconIn },
  { k: "OUT" as const, fa: "خروج", icon: IconOut },
  { k: "TRANSFER" as const, fa: "انتقال", icon: IconSwap },
];

export function BulkScreen({ onBack }: { onBack: () => void }) {
  const { catalog, batches, warehouses, suppliers, outReasons } = useData();
  const { session } = useUi();
  const { commitMove, addBatch, toast } = useActions();
  const nav = useNav();
  const t = useScreenTheme("bulk");

  const [type, setType] = React.useState<"IN" | "OUT" | "TRANSFER">("IN");
  const [lines, setLines] = React.useState<BulkLine[]>([]);
  const [picking, setPicking] = React.useState(false);
  const [draft, setDraft] = React.useState<Set<number>>(new Set());
  const [reason, setReason] = React.useState(outReasons[0] ?? "");
  const [toWh, setToWh] = React.useState<number | null>(null);
  const [supId, setSupId] = React.useState<number | null>(null);
  const [sheet, setSheet] = React.useState<null | "reason" | "wh" | "sup" | number>(null);
  const seq = React.useRef(1);

  const may = session ? can(session.role, "move") : false;

  /** پارتِ پیش‌فرض: نزدیک‌ترین انقضا که موجودی دارد */
  const pickBatch = React.useCallback((productId: number) => {
    const mine = batches.filter((b) => b.productId === productId);
    const pool = type === "IN" ? mine : mine.filter((b) => b.qty > 0);
    if (!pool.length) return null;
    return [...pool].sort(
      (a, b) => (a.expiry ?? "9999").localeCompare(b.expiry ?? "9999")
    )[0].id;
  }, [batches, type]);

  const addChosen = () => {
    setLines((ls) => {
      const have = new Set(ls.map((l) => l.productId));
      const add: BulkLine[] = [];
      for (const id of draft) {
        if (have.has(id)) continue;
        add.push({ key: seq.current++, productId: id, batchId: pickBatch(id),
                   qty: 1, expY: "", expM: "", expNone: false });
      }
      return [...ls, ...add];
    });
    setDraft(new Set());
  };

  const patch = (key: number, p: Partial<BulkLine>) =>
    setLines((ls) => ls.map((l) => (l.key === key ? { ...l, ...p } : l)));

  /* در حالتِ ورود، انبارِ مقصد لازم است — چه پارت تازه ساخته شود چه نه.
     پیش‌فرضش را خودمان می‌گذاریم تا کاربر برای کارِ معمول معطل نشود. */
  React.useEffect(() => {
    if (toWh == null && warehouses.length) setToWh(defaultWarehouseId(warehouses));
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [warehouses.length]);

  const valid = lines.filter((l) => {
    if (l.qty <= 0) return false;
    if (l.batchId == null) {
      /* پارتِ تازه فقط در ورود، و فقط وقتی مقصد معلوم است */
      return type === "IN" && toWh != null;
    }
    const b = batches.find((x) => x.id === l.batchId);
    if (!b) return false;
    if (type !== "IN" && l.qty > b.qty) return false;
    if (type === "TRANSFER" && (toWh == null || toWh === b.warehouseId)) return false;
    return true;
  });
  const totalQty = valid.reduce((n, l) => n + l.qty, 0);
  const nNew = valid.filter((l) => l.batchId == null).length;

  if (!may) {
    return (
      <ScreenScroll>
        <Header theme={t} title="ثبتِ گروهی" onBack={onBack} />
        <Empty icon={IconList} title="دسترسیِ ثبت نداری" />
      </ScreenScroll>
    );
  }

  const submit = () => {
    if (!session || !valid.length) return;
    for (const l of valid) {
      let bid = l.batchId;
      if (bid == null) {
        const y = toEn(l.expY).replace(/\D/g, "");
        const m = toEn(l.expM).replace(/\D/g, "");
        const expiry = l.expNone || y.length !== 4 || !m
          ? null : `${y}-${m.padStart(2, "0")}`;
        bid = addBatch({
          productId: l.productId, supplierId: supId, warehouseId: toWh!,
          qty: 0, expiry, noExpiry: l.expNone, entryDate: null,
        } as any);
      }
      commitMove({
        type, batchId: bid, qty: l.qty,
        reason: type === "OUT" ? reason : null,
        toWarehouseId: type === "TRANSFER" ? toWh : null,
      }, session.id);
    }
    toast(`${toFa(valid.length)} ردیف · ${toFa(totalQty)} عدد ثبت شد`, { tone: "ok" });
    setLines([]);
    nav.push("history");
  };

  const activeLine = typeof sheet === "number" ? lines.find((l) => l.key === sheet) : null;

  return (
    <>
      <ScreenScroll>
        <Header theme={t} sub="چند کالا با هم" title="ثبتِ گروهی" onBack={onBack} />

        <Pad style={{ marginTop: 16 }}>
          <div style={{ display: "flex", gap: 7 }}>
            {KINDS.map((x) => (
              <Chip key={x.k} on={type === x.k} onPress={() => setType(x.k)}>
                <x.icon size={14} stroke={2.1} />{x.fa}
              </Chip>
            ))}
          </div>
        </Pad>

        {type === "OUT" && (
          <Pad style={{ marginTop: 12 }}>
            <PickerRow icon={IconTag} label="علتِ خروج — برای همهٔ ردیف‌ها"
                       value={reason} onPress={() => setSheet("reason")} />
          </Pad>
        )}

        {(type === "TRANSFER" || type === "IN") && (
          <Pad style={{ marginTop: 12 }}>
            <PickerRow icon={IconBox}
                       label={type === "IN" ? "انبارِ مقصد — برای همهٔ ردیف‌ها"
                                            : "انبارِ مقصد — برای همهٔ ردیف‌ها"}
                       value={toWh != null ? warehouses.find((w) => w.id === toWh)?.name : undefined}
                       onPress={() => setSheet("wh")} />
          </Pad>
        )}

        {/* تأمین‌کننده فقط در ورود و فقط وقتی پارتِ تازه ساخته می‌شود
            به‌کار می‌آید — پس تا آن موقع جا اشغال نمی‌کند. */}
        {type === "IN" && nNew > 0 && suppliers.length > 0 && (
          <Pad style={{ marginTop: 10 }}>
            <PickerRow icon={IconTruck} label="تأمین‌کنندهٔ محموله (اختیاری)"
                       value={supId != null ? suppliers.find((s) => s.id === supId)?.name : "—"}
                       onPress={() => setSheet("sup")} />
          </Pad>
        )}

        <Pad style={{ marginTop: 12 }}>
          <Button icon={IconPlus} onPress={() => { setDraft(new Set()); setPicking(true); }}>
            انتخابِ کالاها
          </Button>
        </Pad>

        <Gap h={18} />

        <Pad>
          {lines.length === 0 ? (
            <Card pad={0}>
              <Empty icon={IconList} title="هنوز کالایی انتخاب نشده"
                     note="با دکمهٔ بالا چند کالا را با هم انتخاب کن، بعد برای هرکدام تعداد بزن." />
            </Card>
          ) : (
            <>
              <SectionLabel count={lines.length}>ردیف‌ها</SectionLabel>
              <Gap h={10} />
              <div style={{ display: "grid", gap: 8 }}>
                {lines.map((l) => {
                  const p = catalog.find((c) => c.i === l.productId);
                  const b = l.batchId != null ? batches.find((x) => x.id === l.batchId) : null;
                  const mine = batches.filter((x) => x.productId === l.productId);
                  const over = type !== "IN" && b && l.qty > b.qty;
                  return (
                    <Card key={l.key} pad={13}>
                      <div style={{ display: "flex", alignItems: "center", gap: 8 }}>
                        <div style={{ flex: 1, minWidth: 0 }}>
                          <div style={{ fontSize: 12.5, fontWeight: 700, color: v("ink"),
                                        whiteSpace: "nowrap", overflow: "hidden",
                                        textOverflow: "ellipsis" }}>{p?.n ?? "—"}</div>
                          <div style={{ marginTop: 2, fontSize: 10, color: v("inkFaint") }}>
                            {p && <Code code={p.d} style={{ fontSize: 10 }} />}
                            {b && <> · <Lat style={{ fontSize: 10 }}>{b.lotCode}</Lat> · موجودی <Num value={b.qty} /></>}
                          </div>
                        </div>
                        <Pressable onPress={() => setLines((ls) => ls.filter((x) => x.key !== l.key))}
                          scale={0.88} ariaLabel="حذفِ ردیف"
                          style={{ width: 30, height: 30, borderRadius: 10, flex: "none",
                                   display: "grid", placeItems: "center",
                                   background: v("critWash"), color: v("crit") }}>
                          <IconTrash size={14} />
                        </Pressable>
                      </div>

                      {(mine.length > 0 || type === "IN") && (
                        <div style={{ marginTop: 9 }}>
                          <Pressable onPress={() => setSheet(l.key)} scale={0.98}
                            style={{ width: "100%", minHeight: 36, paddingInline: 11,
                                     borderRadius: R.field, display: "flex", alignItems: "center",
                                     gap: 7, background: v("surfaceAlt"), fontSize: 11,
                                     fontWeight: 700, color: v("inkMuted") }}>
                            <IconBox size={13} />
                            <span>پارت:</span>
                            {b ? <Lat style={{ fontSize: 11, color: v("ink") }}>{b.lotCode}</Lat>
                               : <span style={{ color: v("ink") }}>پارتِ تازه</span>}
                            <i style={{ flex: 1 }} />
                            <IconForward size={13} stroke={2} />
                          </Pressable>
                        </div>
                      )}

                      {/* انقضای پارتِ تازه — برای هر قلم جدا، چون در یک
                          محموله هر دارو تاریخِ خودش را دارد. */}
                      {type === "IN" && l.batchId == null && (
                        <>
                          <div style={{ display: "flex", alignItems: "center", gap: 10,
                                        marginTop: 9 }}>
                            <div style={{ flex: 1, minWidth: 0, fontSize: 11.5,
                                          fontWeight: 700, color: v("ink") }}>
                              تاریخِ انقضا ندارد
                            </div>
                            <Switch on={l.expNone} label="تاریخِ انقضا ندارد"
                                    onChange={(on) => patch(l.key, { expNone: on })} />
                          </div>
                          {!l.expNone && (
                            <div style={{ display: "flex", gap: 8, marginTop: 9 }}>
                              <div style={{ flex: 1 }}>
                                <Field label="سالِ انقضا" value={l.expY} ltr inputMode="numeric"
                                       placeholder="2027"
                                       onChange={(s) => patch(l.key, { expY: s })} />
                              </div>
                              <div style={{ flex: 1 }}>
                                <Field label="ماه" value={l.expM} ltr inputMode="numeric"
                                       placeholder="05"
                                       onChange={(s) => patch(l.key, { expM: s })} />
                              </div>
                            </div>
                          )}
                        </>
                      )}

                      <div style={{ marginTop: 11 }}>
                        <Stepper value={l.qty} min={1}
                          max={type === "IN" ? 99999 : Math.max(1, b?.qty ?? 1)}
                          onChange={(n) => patch(l.key, { qty: n })} />
                      </div>

                      {(over || (l.batchId == null && type !== "IN")) && (
                        <div style={{ marginTop: 8, fontSize: 10.5, fontWeight: 700,
                                      color: v("crit"), textAlign: "center" }}>
                          {l.batchId == null ? "این کالا پارتی ندارد — اول با «ورود» بسازش"
                                             : "بیشتر از موجودیِ پارت است"}
                        </div>
                      )}
                    </Card>
                  );
                })}
              </div>
            </>
          )}
        </Pad>

        {lines.length > 0 && (
          <Pad style={{ marginTop: 18 }}>
            <Button disabled={valid.length === 0} onPress={submit}>
              ثبتِ <Num value={valid.length} /> ردیف · <Num value={totalQty} /> عدد
            </Button>
            {valid.length < lines.length && (
              <div style={{ marginTop: 8, fontSize: 10.5, color: v("warn"),
                            fontWeight: 700, textAlign: "center" }}>
                <Num value={lines.length - valid.length} /> ردیف هنوز کامل نیست
              </div>
            )}
          </Pad>
        )}
      </ScreenScroll>

      <ProductSheet
        open={picking}
        multi
        selected={draft}
        onClose={() => setPicking(false)}
        onPick={(id) => setDraft((s) => {
          const next = new Set(s);
          if (next.has(id)) next.delete(id); else next.add(id);
          return next;
        })}
        onDone={addChosen}
      />

      <Sheet open={sheet === "reason"} onClose={() => setSheet(null)} title="علتِ خروج">
        <div style={{ display: "grid", gap: 8, paddingBlock: 6 }}>
          {outReasons.map((r) => (
            <ChoiceRow key={r} label={r} on={r === reason}
                       onPress={() => { setReason(r); setSheet(null); }} />
          ))}
        </div>
      </Sheet>

      <Sheet open={sheet === "wh"} onClose={() => setSheet(null)} title="انبارِ مقصد">
        <div style={{ display: "grid", gap: 8, paddingBlock: 6 }}>
          {warehouses.map((w) => (
            <ChoiceRow key={w.id} label={w.name} on={w.id === toWh}
                       onPress={() => { setToWh(w.id); setSheet(null); }} />
          ))}
        </div>
      </Sheet>

      <Sheet open={sheet === "sup"} onClose={() => setSheet(null)} title="تأمین‌کننده">
        <div style={{ display: "grid", gap: 8, paddingBlock: 6 }}>
          <ChoiceRow label="—" meta="بدونِ تأمین‌کننده" on={supId == null}
                     onPress={() => { setSupId(null); setSheet(null); }} />
          {suppliers.map((s) => (
            <ChoiceRow key={s.id} label={s.name} on={s.id === supId}
                       onPress={() => { setSupId(s.id); setSheet(null); }} />
          ))}
        </div>
      </Sheet>

      <Sheet open={activeLine != null} onClose={() => setSheet(null)} title="انتخابِ پارت">
        <div style={{ display: "grid", gap: 8, paddingBlock: 6 }}>
          {activeLine && type === "IN" && (
            <ChoiceRow label="پارتِ تازه" meta="یک پارتِ نو در انبارِ مقصد ساخته می‌شود"
                       on={activeLine.batchId == null}
                       onPress={() => { patch(activeLine.key, { batchId: null }); setSheet(null); }} />
          )}
          {activeLine && batches.filter((b) => b.productId === activeLine.productId).map((b) => (
            <ChoiceRow key={b.id}
              label={<Lat style={{ fontSize: 12.5, fontWeight: 800, color: v("ink") }}>{b.lotCode}</Lat>}
              meta={<>{warehouses.find((w) => w.id === b.warehouseId)?.name} · انقضا {expiryText(b, expiryLabel)} · <Num value={b.qty} /> عدد</>}
              on={b.id === activeLine.batchId}
              onPress={() => { patch(activeLine.key, { batchId: b.id, qty: 1 }); setSheet(null); }} />
          ))}
        </div>
      </Sheet>
    </>
  );
}
