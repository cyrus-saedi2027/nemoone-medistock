/* ─────────────────────────────────────────────────────────────
 *  دفترِ تغییرات — «چه کسی این را عوض کرد؟»
 *
 *  تاریخچه فقط حرکتِ کالا را نشان می‌دهد: ورود، خروج، انتقال. اما
 *  کارهایی که کالا را جابه‌جا نمی‌کنند — حذفِ یک کالا، بالابردنِ نقشِ
 *  یک کاربر، عوض‌کردنِ نامِ یک انبار، بازگرداندنِ بکاپ — هیچ ردی
 *  نمی‌گذاشتند. در داروخانه‌ای با چهار حساب، این سؤال یک روز پرسیده
 *  می‌شود و آن روز باید جواب داشته باشد.
 *
 *  دسترسی: فقط مدیر. دفتری که همه بتوانند ببینند، اولین چیزی است که
 *  کسی که کارِ اشتباه کرده سراغش می‌رود.
 * ───────────────────────────────────────────────────────────── */

import * as React from "react";
import { v } from "@/system/theme/ThemeProvider";
import { R, SHADOW } from "@/system/tokens";
import { useData, useUi } from "@/store/StoreProvider";
import { ScreenScroll } from "@/ui/chrome/ScreenScroll";
import { Pressable } from "@/ui/primitives/Pressable";
import { Header } from "@/ui/chrome/Header";
import { Gap, Pad, SectionLabel, StatBlock, LightRow, IconSquare, Empty, Chip } from "@/ui/kit";
import { Num, Lat } from "@/ui/text/Text";
import { Reveal } from "@/ui/primitives/Motion";
import {
  IconHistory, IconPill, IconBox, IconUsers, IconGear, IconTruck, IconTag,
  IconOut, IconRefresh, IconUpload, IconTrash, IconEdit, IconPlus, IconCloud,
} from "@/ui/icons";
import { useScreenTheme } from "@/screens/useScreenTheme";
import { can } from "@/domain/derive";
import { toJalali, fmtJalali } from "@/system/i18n/jalali";
import { toFa } from "@/system/i18n/digits";
import type { AuditKind } from "@/domain/types";

/** برچسبِ فارسیِ هر نوع — متنِ کوتاه، چون کنارِ «چه چیزی» می‌نشیند */
const KIND_FA: Record<AuditKind, string> = {
  "product.add": "کالای تازه",
  "product.edit": "ویرایشِ کالا",
  "product.remove": "حذفِ کالا",
  "batch.remove": "حذفِ پارت",
  "batch.setQty": "اصلاحِ موجودی",
  "batch.setExpiry": "اصلاحِ تاریخِ انقضا",
  "warehouse.add": "انبارِ تازه",
  "warehouse.edit": "ویرایشِ انبار",
  "warehouse.remove": "حذفِ انبار",
  "supplier.add": "تأمین‌کنندهٔ تازه",
  "supplier.edit": "ویرایشِ تأمین‌کننده",
  "supplier.remove": "حذفِ تأمین‌کننده",
  "category.add": "دستهٔ تازه",
  "category.edit": "ویرایشِ دسته",
  "category.remove": "حذفِ دسته",
  "reason.add": "علتِ تازه",
  "reason.edit": "ویرایشِ علت",
  "reason.remove": "حذفِ علت",
  "user.add": "کاربرِ تازه",
  "user.edit": "ویرایشِ کاربر",
  "user.remove": "حذفِ کاربر",
  "user.active": "فعال/غیرفعال",
  "user.password": "تغییرِ رمز",
  "import": "ورودِ گروهی",
  "restore": "بازگرداندنِ بکاپ",
  "settings": "تنظیمات",
  "archive": "آرشیوِ ماه",
};

/** خانوادهٔ هر نوع — همان چیزی که تراشه‌های فیلتر رویش کار می‌کنند */
type Family = "product" | "place" | "user" | "system";

function familyOf(k: AuditKind): Family {
  if (k.startsWith("product.") || k.startsWith("batch.")) return "product";
  if (k.startsWith("warehouse.") || k.startsWith("supplier.") ||
      k.startsWith("category.") || k.startsWith("reason.")) return "place";
  if (k.startsWith("user.")) return "user";
  return "system";
}

const FILTERS: { id: Family | "all"; fa: string }[] = [
  { id: "all", fa: "همه" },
  { id: "product", fa: "کالا و پارت" },
  { id: "place", fa: "انبار و فهرست‌ها" },
  { id: "user", fa: "کاربران" },
  { id: "system", fa: "سیستم" },
];

function iconOf(k: AuditKind) {
  if (k === "restore") return IconRefresh;
  if (k === "import") return IconUpload;
  if (k === "settings") return IconGear;
  if (k === "archive") return IconCloud;
  if (k.startsWith("user.")) return IconUsers;
  if (k.startsWith("supplier.")) return IconTruck;
  if (k.startsWith("category.")) return IconTag;
  if (k.startsWith("reason.")) return IconOut;
  if (k.startsWith("warehouse.")) return IconBox;
  if (k.startsWith("batch.")) return IconBox;
  if (k.endsWith(".remove")) return IconTrash;
  if (k.endsWith(".add")) return IconPlus;
  if (k.endsWith(".edit")) return IconEdit;
  return IconPill;
}

/** حذف قرمز، ساخت سبز، بقیه خنثی — رنگ باید یک چیز بگوید، نه تزئین باشد */
function toneOf(k: AuditKind): string | undefined {
  if (k === "restore") return "crit";
  if (k.endsWith(".remove")) return "crit";
  if (k.endsWith(".add")) return "ok";
  return undefined;
}

/** «۱۴۰۵/۰۵/۱۸ · ۱۴:۳۰» */
function stamp(iso: string) {
  const d = new Date(iso);
  if (Number.isNaN(d.getTime())) return "—";
  const hh = String(d.getHours()).padStart(2, "0");
  const mm = String(d.getMinutes()).padStart(2, "0");
  return `${fmtJalali(toJalali(d))} · ${toFa(`${hh}:${mm}`)}`;
}

export function AuditScreen({ onBack }: { onBack: () => void }) {
  const { audit, users } = useData();
  const { session } = useUi();
  const t = useScreenTheme("audit");
  const [f, setF] = React.useState<Family | "all">("all");

  const may = session ? can(session.role, "users") : false;

  /* بدونِ `slice(0, 200)`: عددِ کنارِ «رویدادها» از همین می‌آمد، پس
     با ۵۰۰ رویداد هم «۲۰۰» می‌گفت — در حالی که کارتِ بالای صفحه
     عددِ درست را نشان می‌داد. دو عددِ متفاوت روی یک صفحه. */
  const rows = React.useMemo(() => {
    const byId = new Map(users.map((u) => [u.id, u]));
    return audit
      .filter((e) => f === "all" || familyOf(e.kind) === f)
      .map((e) => ({ e, u: byId.get(e.userId) }));
  }, [audit, users, f]);

  const PAGE = 200;
  const [shown, setShown] = React.useState(PAGE);
  React.useEffect(() => { setShown(PAGE); }, [f]);

  /* چند نفر و چند روز — دو عددی که اول از همه پرسیده می‌شوند */
  const stats = React.useMemo(() => {
    const people = new Set(audit.map((e) => e.userId));
    const days = new Set(audit.map((e) => e.createdAt.slice(0, 10)));
    return { n: audit.length, people: people.size, days: days.size };
  }, [audit]);

  if (!may) {
    return (
      <ScreenScroll>
        <Header theme={t} title="دفترِ تغییرات" onBack={onBack} />
        <Empty icon={IconHistory} title="دسترسی نداری"
               note="فقط مدیر می‌تواند دفترِ تغییرات را ببیند." />
      </ScreenScroll>
    );
  }

  return (
    <ScreenScroll>
      <Header theme={t} sub="چه کسی چه چیزی را عوض کرد" title="دفترِ تغییرات" onBack={onBack} />

      <Pad style={{ marginTop: 14 }}>
        <div style={{ display: "flex", gap: 8 }}>
          <StatBlock label="کلِ ثبت" value={<Num value={stats.n} />} />
          <StatBlock label="کاربر" value={<Num value={stats.people} />} />
          <StatBlock label="روز" value={<Num value={stats.days} />} />
        </div>
      </Pad>

      <Gap h={18} />

      <Pad>
        <div style={{ display: "flex", gap: 7, flexWrap: "wrap" }}>
          {FILTERS.map((x) => (
            <Chip key={x.id} on={f === x.id} onPress={() => setF(x.id)}>{x.fa}</Chip>
          ))}
        </div>
      </Pad>

      <Gap h={14} />

      <Pad>
        <SectionLabel count={rows.length}>رویدادها</SectionLabel>
        <Gap h={10} />
        {rows.length === 0 ? (
          <Empty icon={IconHistory}
                 title={audit.length === 0 ? "هنوز چیزی ثبت نشده" : "در این دسته چیزی نیست"}
                 note={audit.length === 0
                   ? "هر ویرایش، حذف یا تغییرِ دسترسی از این به بعد اینجا می‌ماند."
                   : undefined} />
        ) : (
          <div style={{ display: "grid", gap: 8 }}>
            {rows.slice(0, shown).map(({ e, u }, i) => {
              const tone = toneOf(e.kind);
              return (
                <Reveal key={e.id} i={Math.min(i, 10)} step={30}>
                  {/* ارتفاع آزاد است: «جزئیات» گاهی یک خط است و گاهی سه
                      خطِ «الف → ب»؛ ردیفِ ثابت یا خالی می‌ماند یا می‌برد. */}
                  <LightRow height={0} style={{ alignItems: "flex-start", paddingBlock: 12 }}>
                    <IconSquare icon={iconOf(e.kind)} size={32} radius={10} iconSize={14}
                                color={tone ? v(tone as any) : undefined} />
                    <div style={{ flex: 1, minWidth: 0, marginInlineStart: 12 }}>
                      <div style={{ display: "flex", alignItems: "baseline", gap: 6 }}>
                        <span style={{ fontSize: 10, fontWeight: 800, flex: "none",
                                       color: tone ? v(tone as any) : v("inkMuted") }}>
                          {KIND_FA[e.kind] ?? e.kind}
                        </span>
                        <span style={{ fontSize: 12.5, fontWeight: 700, color: v("ink"),
                                       flex: 1, minWidth: 0, whiteSpace: "nowrap",
                                       overflow: "hidden", textOverflow: "ellipsis" }}>
                          {e.target}
                        </span>
                      </div>
                      {e.detail && (
                        <div style={{ marginTop: 4, fontSize: 11, color: v("inkMuted"),
                                      lineHeight: 1.8, wordBreak: "break-word" }}>
                          {e.detail}
                        </div>
                      )}
                      <div style={{ marginTop: 5, fontSize: 9.5, color: v("inkFaint") }}>
                        {u?.fullName ?? u?.username ?? "کاربرِ حذف‌شده"} · <Lat style={{ fontSize: 9.5 }}>{stamp(e.createdAt)}</Lat>
                      </div>
                    </div>
                  </LightRow>
                </Reveal>
              );
            })}
            {rows.length > shown && (
              <Pressable onPress={() => setShown((n) => n + PAGE)}
                ariaLabel="نمایشِ بیشتر"
                style={{
                  height: 46, borderRadius: R.row, display: "grid", placeItems: "center",
                  background: v("card"), boxShadow: SHADOW.soft, marginTop: 2,
                }}>
                <span style={{ fontSize: 12, fontWeight: 800, color: v("ink") }}>
                  نمایشِ <Num value={Math.min(PAGE, rows.length - shown)} /> تای بعدی
                  {" · "}
                  <span style={{ color: v("inkFaint"), fontWeight: 700 }}>
                    <Num value={rows.length - shown} /> مانده
                  </span>
                </span>
              </Pressable>
            )}
          </div>
        )}
      </Pad>

      <Pad style={{ marginTop: 14 }}>
        <div style={{ padding: "13px 15px", borderRadius: R.row, background: v("surfaceAlt"),
                      fontSize: 11, color: v("inkMuted"), lineHeight: 2 }}>
          آخرین <Num value={1000} /> رویداد نگه داشته می‌شود و در بکاپ هم می‌آید.
          ورود و خروج و انتقالِ کالا اینجا نیست — آن‌ها در «تاریخچه» هستند.
        </div>
      </Pad>
    </ScreenScroll>
  );
}
