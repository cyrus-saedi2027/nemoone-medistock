/* رسید — با حلقهٔ لغوِ ۸ ثانیه‌ای */

import * as React from "react";
import { v } from "@/system/theme/ThemeProvider";
import { R, SHADOW, EASE } from "@/system/tokens";
import { useActions } from "@/store/StoreProvider";
import { ScreenScroll } from "@/ui/chrome/ScreenScroll";
import { Header } from "@/ui/chrome/Header";
import { Gap, Pad, Card, Button, Ring } from "@/ui/kit";
import { Num, Lat } from "@/ui/text/Text";
import { KV } from "@/screens/details/Product";
import { IconCheck, IconRefresh } from "@/ui/icons";
import { useScreenTheme } from "@/screens/useScreenTheme";
import { useNav } from "@/router/Router";
import { longJalali, toJalali } from "@/system/i18n/jalali";
import type { MoveType } from "@/domain/types";
import { SUCCESS } from "@/system/haptics";

const UNDO_MS = 8000;

export function ReceiptScreen({
  params, onBack,
}: {
  params: { movementId: number; type: MoveType; qty: number; productName?: string; lot?: string };
  onBack: () => void;
}) {
  const { undoMove, toast } = useActions();
  const nav = useNav();
  const t = useScreenTheme("receipt");
  const [left, setLeft] = React.useState(UNDO_MS);
  const [undone, setUndone] = React.useState(false);

  React.useEffect(() => { SUCCESS(); }, []);

  React.useEffect(() => {
    if (undone) return;
    const t0 = performance.now();
    let raf = 0;
    const tick = () => {
      const rem = Math.max(0, UNDO_MS - (performance.now() - t0));
      setLeft(rem);
      if (rem > 0) raf = requestAnimationFrame(tick);
    };
    raf = requestAnimationFrame(tick);
    return () => cancelAnimationFrame(raf);
  }, [undone]);

  const label = params.type === "IN" ? "ورود" : params.type === "OUT" ? "خروج" : "انتقال";
  const canUndo = !undone && left > 0;

  return (
    <ScreenScroll>
      <Header theme={t} sub="ثبت شد" title="رسیدِ حرکت" onBack={onBack} />

      <Pad style={{ marginTop: 20 }}>
        <Card style={{ textAlign: "center" }} pad={22}>
          <div style={{
            width: 62, height: 62, borderRadius: 999, margin: "0 auto",
            display: "grid", placeItems: "center",
            background: undone ? v("surfaceAlt") : v("okWash"),
            animation: `pop 420ms ${EASE.out} both`,
          }}>
            {undone
              ? <IconRefresh size={26} stroke={2} color={v("inkMuted")} />
              : <IconCheck size={28} stroke={3} color={v("ok")} />}
          </div>
          <div style={{ marginTop: 14, fontSize: 18, fontWeight: 800, color: v("ink") }}>
            {undone ? "لغو شد" : `${label} ثبت شد`}
          </div>
          <div style={{ marginTop: 4, fontSize: 12, color: v("inkMuted") }}>
            {undone ? "همه‌چیز به حالتِ قبل برگشت." : longJalali(toJalali(new Date()))}
          </div>

          <div style={{ marginTop: 20, display: "grid", gap: 12, textAlign: "start" }}>
            <KV label="کالا" value={params.productName ?? "—"} />
            <KV label="پارت" value={params.lot ? <Lat style={{ fontSize: 12.5, color: v("ink") }}>{params.lot}</Lat> : "—"} />
            <KV label="تعداد" value={<><Num value={params.qty} /> عدد</>} strong />
            <KV label="نوع" value={label} />
          </div>
        </Card>
      </Pad>

      {canUndo && (
        <Pad style={{ marginTop: 14 }}>
          <div style={{
            display: "flex", alignItems: "center", gap: 12,
            padding: "12px 14px", borderRadius: R.row, background: v("card"),
            boxShadow: SHADOW.soft,
          }}>
            <Ring pct={left / UNDO_MS} size={38} />
            <div style={{ flex: 1, minWidth: 0 }}>
              <div style={{ fontSize: 12.5, fontWeight: 700, color: v("ink") }}>اشتباه شد؟</div>
              <div style={{ fontSize: 10.5, color: v("inkFaint") }}>
                تا <Num value={Math.ceil(left / 1000)} /> ثانیه می‌توانی برگردانی
              </div>
            </div>
            <Button tone="ghost" style={{ width: "auto", minHeight: 36, paddingInline: 16 }}
              onPress={() => {
                undoMove(params.movementId);
                setUndone(true);
                toast("حرکت لغو شد", { tone: "warn" });
              }}>لغو</Button>
          </div>
        </Pad>
      )}

      <Pad style={{ marginTop: 16 }}>
        <div style={{ display: "grid", gap: 8 }}>
          <Button onPress={onBack}>ثبتِ حرکتِ بعدی</Button>
          <Button tone="ghost" onPress={() => nav.reset()}>بازگشت به خانه</Button>
        </div>
      </Pad>

      <style>{`@keyframes pop{
        from{ transform:scale(.6); opacity:0 }
        to  { transform:none; opacity:1 }
      }`}</style>
    </ScreenScroll>
  );
}
