/* کالا + پارت‌ها — صفحهٔ امضا */

import * as React from "react";
import { v } from "@/system/theme/ThemeProvider";
import { R, SHADOW } from "@/system/tokens";
import { useData, useUi, useActions } from "@/store/StoreProvider";
import { ScreenScroll } from "@/ui/chrome/ScreenScroll";
import { Header, inkOf, inkSoftOf } from "@/ui/chrome/Header";
import {
  Gap, Pad, SectionLabel, StatBlock, LightRow, DarkRow, IconSquare, Empty, Button, Card,
  Field, Switch,
} from "@/ui/kit";
import { Num, Lat, Code } from "@/ui/text/Text";
import { Reveal } from "@/ui/primitives/Motion";
import {
  IconIn, IconOut, IconSwap, IconEdit, IconBox, IconForward, IconClock, IconPill, IconWarn, IconTrash,
  IconHistory,
} from "@/ui/icons";
import { useScreenTheme } from "@/screens/useScreenTheme";
import { useNav } from "@/router/Router";
import { expiryLabel, fmtJalali, toJalali } from "@/system/i18n/jalali";
import { Sheet } from "@/ui/overlays/Sheet";
import { monthsUntil, can, expiryText, expiryKind } from "@/domain/derive";
import { Pressable } from "@/ui/primitives/Pressable";

/** ISO → «۱۴۰۵/۰۵/۱۸». تاریخِ خام ISO برای انباردار معنایی ندارد. */
const jalaliOf = (iso: string | null | undefined) => {
  if (!iso) return "—";
  const d = new Date(iso);
  return Number.isNaN(d.getTime()) ? "—" : fmtJalali(toJalali(d));
};

export function ProductScreen({ params, onBack }: { params: { id: number }; onBack: () => void }) {
  const { catalog, batches, warehouses, movements } = useData();
  const { session } = useUi();
  const nav = useNav();
  const t = useScreenTheme("product");

  const p = catalog.find((c) => c.i === params.id);
  const mine = React.useMemo(
    () => batches.filter((b) => b.productId === params.id)
                 .sort((a, z) => (a.expiry ?? "").localeCompare(z.expiry ?? "")),
    [batches, params.id]
  );
  const recent = React.useMemo(() => {
    const ids = new Set(mine.map((b) => b.id));
    return movements.filter((m) => ids.has(m.batchId)).slice(0, 5);
  }, [movements, mine]);

  if (!p) {
    return (
      <ScreenScroll>
        <Header theme={t} title="کالا" onBack={onBack} />
        <Empty icon={IconPill} title="این کالا پیدا نشد" />
      </ScreenScroll>
    );
  }

  const whName = (id: number) => warehouses.find((w) => w.id === id)?.name ?? "—";
  const mayMove = session ? can(session.role, "move") : false;
  const mayEdit = session ? can(session.role, "editProduct") : false;

  return (
    <ScreenScroll>
      <Header
        theme={t}
        sub={p.c || "بدون دسته"}
        title={p.n}
        fullTitle
        onBack={onBack}
        right={mayEdit ? (
          <Pressable onPress={() => nav.push("productEdit", { id: p.i })} scale={0.9}
            ariaLabel="ویرایشِ کالا"
            style={{ width: 38, height: 38, borderRadius: 13, flex: "none", display: "grid",
                     placeItems: "center", background: v("cardDarkAlt"), color: inkOf(t) }}>
            <IconEdit size={16} stroke={1.9} />
          </Pressable>
        ) : undefined}
      />

      {p.l && (
        <Pad style={{ marginTop: 4 }}>
          <Lat style={{ fontSize: 12, color: inkSoftOf(t), display: "block",
                        lineHeight: 1.7, wordBreak: "break-word" }}>{p.l}</Lat>
        </Pad>
      )}

      {/* کدِ کالا — همان چیزی که روی برچسبِ QR چاپ شده */}
      <Pad style={{ marginTop: 8 }}>
        <span style={{
          display: "inline-flex", alignItems: "center", gap: 6,
          padding: "4px 10px", borderRadius: 999,
          background: v("surfaceAlt"), color: v("inkMuted"),
          fontSize: 10.5, fontWeight: 700,
        }}>
          کدِ کالا
          <Code code={p.d} style={{ fontSize: 12.5, color: v("ink") }} />
        </span>
      </Pad>

      <Pad style={{ marginTop: 14 }}>
        <div style={{ display: "flex", gap: 8 }}>
          <StatBlock tone="dark" label="موجودیِ کل" value={<Num value={p.q} />} />
          <StatBlock tone="dark" label="پارت‌ها" value={<Num value={mine.length} />} />
          <StatBlock tone="dark" label="وضعیت"
                     value={p.q === 0 ? "ناموجود" : p.s === "crit" ? "بحرانی" : p.s === "warn" ? "نزدیک" : "سالم"}
                     tint={p.s === "ok" ? undefined : v(p.s)} />
        </div>
      </Pad>

      {/* حداقلِ موجودی را کارفرما دستی می‌زند؛ اگر جایی دیده نشود،
          فیلدی است که فقط نوشته می‌شود و هیچ‌وقت خوانده نمی‌شود. */}
      {p.m != null && (
        <Pad style={{ marginTop: 10 }}>
          <div style={{
            display: "flex", alignItems: "center", gap: 9,
            padding: "11px 14px", borderRadius: R.row,
            background: p.q <= p.m ? v("warnWash") : v("surfaceAlt"),
            fontSize: 11.5, fontWeight: 700, lineHeight: 1.8,
            color: p.q <= p.m ? v("warn") : v("inkMuted"),
          }}>
            <IconWarn size={15} stroke={2} />
            <span>
              حداقلِ موجودی <Num value={p.m} /> عدد
              {p.q <= p.m ? " — الان زیرِ حداقل است" : ""}
            </span>
          </div>
        </Pad>
      )}

      {p.n2 && (
        <Pad style={{ marginTop: 10 }}>
          <div style={{ padding: "11px 14px", borderRadius: R.row, background: v("surfaceAlt"),
                        fontSize: 11.5, color: v("inkMuted"), lineHeight: 1.9 }}>
            {p.n2}
          </div>
        </Pad>
      )}

      <Gap h={24} />

      {mayMove && (
        <Pad>
          <div style={{ display: "grid", gridTemplateColumns: "repeat(3,1fr)", gap: 8 }}>
            <ActionTile icon={IconIn} label="ورود" onPress={() => nav.push("moveIn", { productId: p.i })} />
            <ActionTile icon={IconOut} label="خروج" onPress={() => nav.push("moveOut", { productId: p.i })} />
            <ActionTile icon={IconSwap} label="انتقال" onPress={() => nav.push("transfer", { productId: p.i })} />
          </div>
          <Gap h={22} />
        </Pad>
      )}

      <Pad>
        <SectionLabel count={mine.length}>پارت‌ها</SectionLabel>
        <Gap h={10} />
        {mine.length === 0 ? (
          <Card pad={0}><Empty icon={IconBox} title="پارتی ثبت نشده" note="با «ورود» اولین پارت را بساز." /></Card>
        ) : (
          <div style={{ display: "grid", gap: 8 }}>
            {mine.map((b, i) => {
              const m = monthsUntil(b.expiry);
              const tone = m == null ? "inkFaint" : m < 0 || m < 3 ? "crit" : m < 6 ? "warn" : "ok";
              return (
                <Reveal key={b.id} i={i} step={38}>
                  <LightRow onPress={() => nav.push("batch", { id: b.id })} height={70}>
                    <i style={{ width: 3, height: 34, borderRadius: 99, flex: "none",
                                background: v(tone as any) }} />
                    <div style={{ flex: 1, minWidth: 0, marginInlineStart: 12 }}>
                      <div style={{ display: "flex", alignItems: "center", gap: 7 }}>
                        <Lat style={{ fontSize: 12, fontWeight: 800, color: v("ink") }}>{b.lotCode}</Lat>
                        {b.qty === 0 && (
                          <span style={{ fontSize: 9.5, fontWeight: 800, color: v("inkFaint"),
                                         background: v("surfaceAlt"), padding: "2px 7px",
                                         borderRadius: 999 }}>خالی</span>
                        )}
                      </div>
                      <div style={{ marginTop: 3, fontSize: 10.5, color: v("inkFaint") }}>
                        {whName(b.warehouseId)} · انقضا {expiryText(b, expiryLabel)}
                      </div>
                    </div>
                    <div style={{ textAlign: "end", flex: "none" }}>
                      <Num value={b.qty} style={{ fontSize: 16, color: b.qty === 0 ? v("inkFaint") : v("ink") }} />
                      <div style={{ fontSize: 9, fontWeight: 700, color: v("inkFaint") }}>عدد</div>
                    </div>
                  </LightRow>
                </Reveal>
              );
            })}
          </div>
        )}
      </Pad>

      <Gap h={22} />

      <Pad>
        <SectionLabel action={recent.length ? "تاریخچه" : undefined}
                      onAction={() => nav.push("history", { productId: p.i })}>
          آخرین حرکت‌ها
        </SectionLabel>
        <Gap h={10} />
        {recent.length === 0 ? (
          <Card pad={0}><Empty icon={IconClock} title="حرکتی ثبت نشده" /></Card>
        ) : (
          <div style={{ display: "grid", gap: 8 }}>
            {recent.map((m) => (
              <LightRow key={m.id} height={54}>
                <IconSquare
                  icon={m.type === "IN" ? IconIn : m.type === "OUT" ? IconOut : IconSwap}
                  size={30} radius={10} iconSize={13}
                  color={m.type === "IN" ? v("ok") : m.type === "OUT" ? v("crit") : v("inkMuted")} />
                <div style={{ flex: 1, minWidth: 0, marginInlineStart: 11 }}>
                  <div style={{ fontSize: 12.5, fontWeight: 700, color: v("ink") }}>
                    {m.type === "IN" ? "ورود" : m.type === "OUT" ? "خروج" : "انتقال"}
                    {m.reason ? ` · ${m.reason}` : ""}
                  </div>
                </div>
                <div style={{ fontSize: 13, fontWeight: 800,
                              color: m.type === "IN" ? v("ok") : v("crit") }}>
                  <Num value={m.qty} />
                </div>
              </LightRow>
            ))}
          </div>
        )}
      </Pad>
    </ScreenScroll>
  );
}

function ActionTile({ icon: Icon, label, onPress }: { icon: any; label: string; onPress: () => void }) {
  return (
    /* `ariaLabel` هم برای صفحه‌خوان لازم است هم برای آزمون: بدونِ آن
       تنها راهِ اشاره به این کاشی، متنِ داخلش است — و همان متن در
       ردیف‌های تاریخچه هم هست، پس آزمون اشتباهی جای دیگری را می‌زند. */
    <Pressable onPress={onPress} scale={0.94} ariaLabel={label}
      style={{
        width: "100%", display: "grid", justifyItems: "center", gap: 6,
        padding: "13px 4px", borderRadius: R.row,
        background: v("card"), boxShadow: SHADOW.soft,
      }}>
      <div style={{ width: 34, height: 34, borderRadius: 12, display: "grid", placeItems: "center",
                    background: v("accentSurface"), color: v("accentSurfaceInk") }}>
        <Icon size={16} stroke={2} />
      </div>
      <span style={{ fontSize: 11, fontWeight: 700, color: v("ink") }}>{label}</span>
    </Pressable>
  );
}

/* ── جزئیاتِ پارت ─────────────────────────────────────── */
export function BatchScreen({ params, onBack }: { params: { id: number }; onBack: () => void }) {
  const { batches, catalog, warehouses, suppliers, movements } = useData();
  const { session } = useUi();
  const { removeBatch, setBatchExpiry, toast } = useActions();
  const nav = useNav();
  const t = useScreenTheme("batch");
  const [confirmDel, setConfirmDel] = React.useState(false);
  /* ویرایشِ انقضا — تا امروز اصلاً راهی نبود: یا موقعِ ساخت درست
     وارد می‌شد یا هیچ‌وقت. */
  const [editExp, setEditExp] = React.useState(false);
  const [exYear, setExYear] = React.useState("");
  const [exMonth, setExMonth] = React.useState("");
  const [exNone, setExNone] = React.useState(false);

  const b = batches.find((x) => x.id === params.id);
  if (!b) {
    return (
      <ScreenScroll>
        <Header theme={t} title="پارت" onBack={onBack} />
        <Empty icon={IconBox} title="این پارت پیدا نشد" />
      </ScreenScroll>
    );
  }
  const p = catalog.find((c) => c.i === b.productId);
  const wh = warehouses.find((w) => w.id === b.warehouseId);
  const sp = suppliers.find((s) => s.id === b.supplierId);
  const m = monthsUntil(b.expiry);
  const tone = m == null ? "inkFaint" : m < 3 ? "crit" : m < 6 ? "warn" : "ok";
  /* عددِ کنارِ عنوان باید *کل* باشد، نه چیزی که رندر می‌شود. قبلاً
     هر دو از یک `slice(0, 8)` می‌آمدند، پس پارتی با ۲۰ حرکت هم
     «۸» نشان می‌داد. */
  const histAll = movements.filter((x) => x.batchId === b.id);
  const hist = histAll.slice(0, 8);
  const mayMove = session ? can(session.role, "move") : false;
  const mayEditB = session ? can(session.role, "editProduct") : false;

  const openExpiry = () => {
    const [y, mo] = (b.expiry ?? "").split("-");
    setExYear(y ?? "");
    setExMonth(mo ? String(Number(mo)) : "");
    setExNone(expiryKind(b) === "none");
    setEditExp(true);
  };

  const saveExpiry = () => {
    if (exNone) {
      setBatchExpiry(b.id, null, true);
      setEditExp(false);
      toast("ثبت شد: این پارت تاریخِ انقضا ندارد", { tone: "ok" });
      return;
    }
    const y = Number(exYear), mo = Number(exMonth);
    if (!exYear && !exMonth) {
      setBatchExpiry(b.id, null, false);
      setEditExp(false);
      toast("انقضا «نامشخص» شد", { tone: "ok" });
      return;
    }
    if (!(y >= 2000 && y <= 2100) || !(mo >= 1 && mo <= 12)) {
      toast("سال بینِ ۲۰۰۰ تا ۲۱۰۰ و ماه بینِ ۱ تا ۱۲ باشد", { tone: "warn" });
      return;
    }
    setBatchExpiry(b.id, `${y}-${String(mo).padStart(2, "0")}`, false);
    setEditExp(false);
    toast("تاریخِ انقضا ثبت شد", { tone: "ok" });
  };

  return (
    <ScreenScroll>
      <Header theme={t} sub={p?.n ?? "کالا"} title={<Lat style={{ fontSize: 24, fontWeight: 800, color: v("ink") }}>{b.lotCode}</Lat>} onBack={onBack} />

      <Pad style={{ marginTop: 14 }}>
        <Card>
          <div style={{ display: "grid", gap: 12 }}>
            <KV label="موجودی" value={<><Num value={b.qty} /> عدد</>} strong />
            <KV label="انقضا" value={expiryText(b, expiryLabel)}
                tint={expiryKind(b) === "dated" ? v(tone as any) : v("inkFaint")} />
            <KV label="محلِ نگهداری" value={wh?.name ?? "—"} />
            <KV label="تأمین‌کننده" value={sp?.name ?? "—"} />
            <KV label="تاریخِ ورود" value={jalaliOf(b.entryDate)} />
            {p && <KV label="کدِ کالا" value={<Code code={p.d} style={{ fontSize: 12.5, color: v("ink") }} />} />}
          </div>
        </Card>
      </Pad>

      {mayMove && (
        <Pad style={{ marginTop: 14 }}>
          <div style={{ display: "grid", gridTemplateColumns: "repeat(3,1fr)", gap: 8 }}>
            <ActionTile icon={IconIn} label="ورود" onPress={() => nav.push("moveIn", { batchId: b.id })} />
            <ActionTile icon={IconOut} label="خروج" onPress={() => nav.push("moveOut", { batchId: b.id })} />
            <ActionTile icon={IconSwap} label="انتقال" onPress={() => nav.push("transfer", { batchId: b.id })} />
          </div>
        </Pad>
      )}

      {mayEditB && (
        <Pad style={{ marginTop: 10 }}>
          <Button tone="ghost" icon={IconHistory} onPress={openExpiry}>
            ویرایشِ تاریخِ انقضا
          </Button>
        </Pad>
      )}

      {mayMove && (
        <Pad style={{ marginTop: 10 }}>
          <Button tone="danger" icon={IconTrash} onPress={() => setConfirmDel(true)}>
            حذفِ این پارت
          </Button>
        </Pad>
      )}

      <Gap h={22} />

      {/* ورقهٔ پایینِ صفحهٔ پارت سیاه است → ردیف‌ها تیره */}
      <Pad>
        <SectionLabel tone="dark" count={histAll.length}>حرکت‌های این پارت</SectionLabel>
        <Gap h={10} />
        {hist.length === 0 ? (
          <Card pad={0} tone="dark">
            <Empty icon={IconClock} tone="dark" title="حرکتی ثبت نشده" />
          </Card>
        ) : (
          <div style={{ display: "grid", gap: 8 }}>
            {hist.map((x) => (
              <DarkRow key={x.id} height={54}
                       style={{ background: v("card"), boxShadow: SHADOW.soft }}>
                <IconSquare
                  icon={x.type === "IN" ? IconIn : x.type === "OUT" ? IconOut : IconSwap}
                  size={30} radius={10} iconSize={13} tone="dark"
                  color={x.type === "IN" ? v("ok") : x.type === "OUT" ? v("crit") : v("deepInkMuted")} />
                <div style={{ flex: 1, minWidth: 0, marginInlineStart: 11, fontSize: 12.5,
                              fontWeight: 700, color: v("deepInk") }}>
                  {x.type === "IN" ? "ورود" : x.type === "OUT" ? "خروج" : "انتقال"}
                  {x.reason ? ` · ${x.reason}` : ""}
                </div>
                <div style={{ fontSize: 13, fontWeight: 800,
                              color: x.type === "IN" ? v("ok") : v("crit") }}>
                  <Num value={x.qty} />
                </div>
              </DarkRow>
            ))}
            {histAll.length > hist.length && (
              /* عدد راست می‌گوید ولی فقط ۸ ردیف رندر می‌شود؛ پس باید
                 راهی به بقیه باشد، وگرنه عددِ درست خودش سؤال می‌شود.
                 «تاریخچه» همان فهرست را با فیلترِ همین کالا می‌دهد. */
              <Pressable onPress={() => nav.push("history", { productId: b.productId })}
                ariaLabel="دیدنِ همهٔ حرکت‌ها"
                style={{
                  height: 46, borderRadius: R.row, display: "grid", placeItems: "center",
                  background: v("card"), boxShadow: SHADOW.soft, marginTop: 2,
                }}>
                <span style={{ fontSize: 12, fontWeight: 800, color: v("ink") }}>
                  دیدنِ همهٔ <Num value={histAll.length} /> حرکت
                </span>
              </Pressable>
            )}
          </div>
        )}
      </Pad>

      {/* ── ویرایشِ انقضا ─────────────────────────────────
          سه حالت از یک جا: تاریخ، «ندارد»، و «نامشخص» (هر دو فیلد
          خالی). خالی‌گذاشتن عمداً یک حالتِ معتبر است — انباردار که
          جعبه دستش نیست نباید مجبور شود عددِ الکی بگذارد. */}
      <Sheet
        open={editExp}
        onClose={() => setEditExp(false)}
        title="تاریخِ انقضای این پارت"
        footer={
          <div style={{ display: "grid", gap: 8 }}>
            <Button onPress={saveExpiry}>ثبت</Button>
            <Button tone="ghost" onPress={() => setEditExp(false)}>انصراف</Button>
          </div>
        }
      >
        <div style={{ display: "grid", gap: 10, paddingBlock: 6 }}>
          <LightRow height={58}>
            <div style={{ flex: 1, minWidth: 0 }}>
              <div style={{ fontSize: 12.5, fontWeight: 700, color: v("ink") }}>
                تاریخِ انقضا ندارد
              </div>
              <div style={{ fontSize: 10.5, color: v("inkFaint") }}>
                مثلِ شانه و قیف و تجهیزات
              </div>
            </div>
            <Switch on={exNone} label="تاریخِ انقضا ندارد" onChange={setExNone} />
          </LightRow>

          {!exNone && (
            <>
              <div style={{ display: "flex", gap: 8 }}>
                <div style={{ flex: 1 }}>
                  <Field label="سال (میلادی)" value={exYear} ltr inputMode="numeric"
                         onChange={(x) => setExYear(x.replace(/[^0-9]/g, "").slice(0, 4))} />
                </div>
                <div style={{ flex: 1 }}>
                  <Field label="ماه" value={exMonth} ltr inputMode="numeric"
                         onChange={(x) => setExMonth(x.replace(/[^0-9]/g, "").slice(0, 2))} />
                </div>
              </div>
              <div style={{ fontSize: 11, color: v("inkFaint"), lineHeight: 1.9 }}>
                {Number(exYear) >= 2000 && Number(exMonth) >= 1 && Number(exMonth) <= 12
                  ? `یعنی «${expiryLabel(`${Number(exYear)}-${String(Number(exMonth)).padStart(2, "0")}`)}» شمسی`
                  : "هر دو را خالی بگذاری، انقضا «نامشخص» ثبت می‌شود."}
              </div>
            </>
          )}
        </div>
      </Sheet>

      <Sheet open={confirmDel} onClose={() => setConfirmDel(false)} title="حذفِ پارت"
        footer={
          <div style={{ display: "grid", gap: 8 }}>
            <Button tone="danger" icon={IconTrash}
              disabled={b.qty > 0 || hist.length > 0}
              onPress={() => {
                if (removeBatch(b.id)) {
                  setConfirmDel(false);
                  toast("پارت حذف شد", { tone: "ok" });
                  onBack();
                } else {
                  toast("این پارت حذف نمی‌شود", { tone: "warn" });
                }
              }}>
              {b.qty > 0 || hist.length > 0 ? "نمی‌شود حذف کرد" : "بله، حذف کن"}
            </Button>
            <Button tone="ghost" onPress={() => setConfirmDel(false)}>انصراف</Button>
          </div>
        }>
        <div style={{ paddingBlock: 10, fontSize: 12, lineHeight: 2, color: v("inkMuted") }}>
          {b.qty > 0 ? (
            <>
              این پارت هنوز <b style={{ color: v("ink") }}><Num value={b.qty} /></b> عدد
              موجودی دارد. اول با «خروج» خالی‌اش کن.
            </>
          ) : hist.length > 0 ? (
            <>
              <b style={{ color: v("ink") }}><Num value={hist.length} /></b> حرکت به این
              پارت وصل است و تاریخچه به آن اشاره می‌کند، پس حذف نمی‌شود.
            </>
          ) : (
            <>پارتِ «{b.lotCode}» خالی است و حرکتی ندارد. حذفش برگشت ندارد.</>
          )}
        </div>
      </Sheet>
    </ScreenScroll>
  );
}

export function KV({
  label, value, strong, tint,
}: { label: string; value: React.ReactNode; strong?: boolean; tint?: string }) {
  return (
    <div style={{ display: "flex", alignItems: "center", gap: 10 }}>
      <span style={{ fontSize: 11.5, color: v("inkFaint"), flex: "none" }}>{label}</span>
      <i style={{ flex: 1, height: 1, background: v("divider") }} />
      <span style={{ fontSize: strong ? 15 : 12.5, fontWeight: strong ? 800 : 700,
                     color: tint ?? v("ink"), flex: "none" }}>{value}</span>
    </div>
  );
}
