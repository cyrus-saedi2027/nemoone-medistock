/* تاریخچه + انبارِ تکی + گزارش‌ها */

import * as React from "react";
import { v } from "@/system/theme/ThemeProvider";
import { R, SHADOW } from "@/system/tokens";
import { useData } from "@/store/StoreProvider";
import { ScreenScroll } from "@/ui/chrome/ScreenScroll";
import { Header, inkOf } from "@/ui/chrome/Header";
import {
  Gap, Pad, SectionLabel, StatBlock, LightRow, DarkRow, IconSquare, Empty, Segmented, Card, Chip,
} from "@/ui/kit";
import { Num, Lat } from "@/ui/text/Text";
import { Reveal } from "@/ui/primitives/Motion";
import {
  IconIn, IconOut, IconSwap, IconClock, IconBox, IconChart, IconWarn, IconPill,
} from "@/ui/icons";
import { useScreenTheme } from "@/screens/useScreenTheme";
import { useNav } from "@/router/Router";
import { expiryLabel, toJalali, fmtJalali } from "@/system/i18n/jalali";
import {
  monthsUntil, expiryText, EXPIRY_CRIT_MONTHS, EXPIRY_WARN_MONTHS,
} from "@/domain/derive";
import { VirtualList } from "@/ui/list/VirtualList";
import { Pressable } from "@/ui/primitives/Pressable";
import { contentBottom } from "@/system/geometry/backdrop";
import { useFrame } from "@/system/frame";

const KIND = ["همه", "ورود", "خروج", "انتقال"];

export function HistoryScreen({
  params, onBack,
}: { params?: { productId?: number }; onBack: () => void }) {
  const { movements, batches, catalog, users } = useData();
  const nav = useNav();
  const t = useScreenTheme("history");
  const [kind, setKind] = React.useState(0);
  /* ── چرا صفحه‌ای، و چرا ۱۲۰تا ─────────────────────────────
   * این فهرست مجازی نیست (ردیف‌هایش پیچیده‌ترند)، پس رندرِ هزار
   * ردیف روی گوشیِ متوسط حس می‌شود. تا دیروز فقط ۱۲۰ تای اول را
   * می‌داد و بقیه **اصلاً قابلِ رسیدن نبودند** — با ۱٬۱۳۲ ثبتِ
   * موجودیِ اولیه یعنی ۹۰٪ تاریخچه پشتِ در. حالا با دکمه ادامه
   * می‌دهد. */
  const PAGE = 120;
  const [shown, setShown] = React.useState(PAGE);
  React.useEffect(() => { setShown(PAGE); }, [kind, params?.productId]);

  const rows = React.useMemo(() => {
    const byBatch = new Map(batches.map((b) => [b.id, b]));
    const byProd = new Map(catalog.map((c) => [c.i, c]));
    let list = movements;
    if (params?.productId != null) {
      list = list.filter((m) => byBatch.get(m.batchId)?.productId === params.productId);
    }
    if (kind > 0) {
      const want = kind === 1 ? "IN" : kind === 2 ? "OUT" : "TRANSFER";
      list = list.filter((m) => m.type === want);
    }
    return list.map((m) => {
      const b = byBatch.get(m.batchId);
      return {
        m, b,
        p: b ? byProd.get(b.productId) : undefined,
        u: users.find((x) => x.id === m.userId),
      };
    });
  }, [movements, batches, catalog, users, kind, params?.productId]);

  const totals = React.useMemo(() => {
    let inn = 0, out = 0;
    for (const m of movements) {
      if (m.type === "IN") inn += m.qty;
      else if (m.type === "OUT") out += m.qty;
    }
    return { inn, out, n: movements.length };
  }, [movements]);

  return (
    <ScreenScroll>
      <Header theme={t} sub="حرکتِ کالاها" title="تاریخچه" onBack={onBack} />

      <Pad style={{ marginTop: 14 }}>
        <div style={{ display: "flex", gap: 8 }}>
          <StatBlock label="کلِ ثبت" value={<Num value={totals.n} />} />
          <StatBlock label="واردشده" value={<Num value={totals.inn} />} tint={v("ok")} />
          <StatBlock label="خارج‌شده" value={<Num value={totals.out} />} tint={v("crit")} />
        </div>
      </Pad>

      <Gap h={18} />
      <Pad><Segmented items={KIND} index={kind} onChange={setKind} /></Pad>
      <Gap h={14} />

      <Pad>
        {rows.length === 0 ? (
          <Card pad={0} tone="dark">
            <Empty icon={IconClock} tone="dark" title="هنوز حرکتی ثبت نشده"
                   note="هر ورود، خروج و انتقالی که ثبت کنی اینجا می‌ماند." />
          </Card>
        ) : (
          <div style={{ display: "grid", gap: 8 }}>
            {rows.slice(0, shown).map(({ m, b, p, u }, i) => (
              <Reveal key={m.id} i={Math.min(i, 8)} step={32}>
                {/* ورقهٔ پایینِ این صفحه سیاه است (مثل Transactions نمونه) */}
                <DarkRow onPress={b ? () => nav.push("batch", { id: b.id }) : undefined} height={66}
                         style={{ background: v("card"), boxShadow: SHADOW.soft }}>
                  <IconSquare
                    icon={m.type === "IN" ? IconIn : m.type === "OUT" ? IconOut : IconSwap}
                    size={34} radius={11} iconSize={15} tone="dark"
                    color={m.type === "IN" ? v("ok") : m.type === "OUT" ? v("crit") : v("deepInkMuted")} />
                  <div style={{ flex: 1, minWidth: 0, marginInlineStart: 12 }}>
                    <div style={{ fontSize: 12.5, fontWeight: 700, color: v("deepInk"),
                                  whiteSpace: "nowrap", overflow: "hidden",
                                  textOverflow: "ellipsis" }}>
                      {p?.n ?? (b ? "کالای حذف‌شده" : "هنوز همگام نشده")}
                    </div>
                    <div style={{ marginTop: 2, fontSize: 10.5, color: v("deepInkMuted") }}>
                      {m.reason ?? (m.type === "IN" ? "ورود" : "انتقال")}
                      {u?.fullName ? ` · ${u.fullName}` : ""}
                    </div>
                  </div>
                  <div style={{ textAlign: "end", flex: "none" }}>
                    <div style={{ fontSize: 14, fontWeight: 800,
                                  color: m.type === "IN" ? v("ok")
                                       : m.type === "OUT" ? v("crit") : v("ink") }}>
                      {m.type === "IN" ? "+" : m.type === "OUT" ? "−" : ""}<Num value={m.qty} />
                    </div>
                    <div style={{ fontSize: 9.5, color: v("deepInkMuted") }}>
                      {fmtJalali(toJalali(new Date(m.createdAt)))}
                    </div>
                  </div>
                </DarkRow>
              </Reveal>
            ))}
            {rows.length > shown && (
              <Pressable onPress={() => setShown((n) => n + PAGE)}
                ariaLabel="نمایشِ بیشتر"
                style={{
                  height: 46, borderRadius: R.row, display: "grid", placeItems: "center",
                  background: v("card"), boxShadow: SHADOW.soft, marginTop: 2,
                }}>
                <span style={{ fontSize: 12, fontWeight: 800, color: v("ink") }}>
                  نمایشِ <Num value={Math.min(PAGE, rows.length - shown)} /> تای بعدی
                  {" · "}
                  <span style={{ color: v("inkFaint"), fontWeight: 700 }}>
                    <Num value={rows.length - shown} /> مانده
                  </span>
                </span>
              </Pressable>
            )}
          </div>
        )}
      </Pad>
    </ScreenScroll>
  );
}

/* ── انبارِ تکی ───────────────────────────────────────── */
export function WarehouseOneScreen({
  params, onBack,
}: { params: { id: number }; onBack: () => void }) {
  const { warehouses, batches, catalog } = useData();
  const { h } = useFrame();
  const nav = useNav();
  const t = useScreenTheme("warehouseOne");
  const box = React.useRef<HTMLDivElement>(null);

  const wh = warehouses.find((w) => w.id === params.id);
  const rows = React.useMemo(() => {
    const byProd = new Map(catalog.map((c) => [c.i, c]));
    return batches
      .filter((b) => b.warehouseId === params.id && b.qty > 0)
      .map((b) => ({ b, p: byProd.get(b.productId) }))
      .filter((x) => !!x.p);
  }, [batches, catalog, params.id]);

  const units = rows.reduce((s, r) => s + r.b.qty, 0);
  const kids = React.useMemo(
    () => warehouses.filter((x) => x.parentId === params.id),
    [warehouses, params.id]
  );
  const countIn = React.useCallback(
    (id: number) => batches.reduce((s, b) => (b.warehouseId === id && b.qty > 0 ? s + 1 : s), 0),
    [batches]
  );

  if (!wh) {
    return (
      <ScreenScroll>
        <Header theme={t} title="انبار" onBack={onBack} />
        <Empty icon={IconBox} title="این محل پیدا نشد" />
      </ScreenScroll>
    );
  }

  return (
    <div style={{ position: "absolute", inset: 0 }}>
      <div style={{ position: "absolute", insetInline: 0, top: 0, zIndex: 2 }}>
        <Header theme={t} sub="محلِ نگهداری" title={wh.name} onBack={onBack} big={false} />
        <Pad style={{ marginTop: 12 }}>
          <div style={{ display: "flex", gap: 8 }}>
            <StatBlock tone="dark" label="قلم" value={<Num value={rows.length} />} />
            <StatBlock tone="dark" label="کلِ عدد" value={<Num value={units} />} />
            <StatBlock tone="dark" label="زیرمجموعه" value={<Num value={kids.length} />} />
          </div>
        </Pad>
      </div>


      <div ref={box} style={{
        position: "absolute", insetInline: 0, top: 150, bottom: 0,
        overflowY: "auto", overflowX: "hidden", paddingInline: 18,
        paddingBottom: contentBottom(h), overscrollBehavior: "contain",
      }}>
        {/* انبارِ مادر خودش پارتی ندارد؛ کالاها داخلِ فایل‌هایش‌اند.
            به‌جای «خالی»، راه را به زیرمجموعه‌ها نشان می‌دهیم. */}
        {kids.length > 0 && (
          <div style={{ display: "grid", gap: 8, paddingBottom: rows.length ? 16 : 0 }}>
            <SectionLabel count={kids.length}>زیرمجموعه‌ها</SectionLabel>
            {kids.map((k) => (
              <LightRow key={k.id} onPress={() => nav.push("warehouseOne", { id: k.id })} height={58}>
                <IconSquare icon={IconBox} size={32} radius={10} iconSize={14} />
                <div style={{ flex: 1, minWidth: 0, marginInlineStart: 12, fontSize: 12.5,
                              fontWeight: 700, color: v("ink") }}>{k.name}</div>
                <div style={{ fontSize: 11.5, fontWeight: 700, color: v("inkMuted"), flex: "none" }}>
                  <Num value={countIn(k.id)} /> قلم
                </div>
              </LightRow>
            ))}
          </div>
        )}

        {rows.length === 0 ? (
          kids.length === 0 && (
            <Empty icon={IconBox} title="این محل خالی است" note="هیچ پارتی با موجودیِ مثبت اینجا نیست." />
          )
        ) : (
          <VirtualList items={rows} rowHeight={68} scrollRef={box}>
            {(r: any) => (
              <Pressable onPress={() => nav.push("batch", { id: r.b.id })} haptic={false} scale={0.985}
                style={{ display: "block", width: "100%", height: 60 }}>
                <div style={{ height: "100%", display: "flex", alignItems: "center",
                              background: v("card"), borderRadius: R.row, paddingInline: 13,
                              boxShadow: SHADOW.soft }}>
                  <div style={{ flex: 1, minWidth: 0 }}>
                    <div style={{ fontSize: 12.5, fontWeight: 700, color: v("ink"),
                                  whiteSpace: "nowrap", overflow: "hidden",
                                  textOverflow: "ellipsis" }}>{r.p.n}</div>
                    <div style={{ marginTop: 2, fontSize: 10, color: v("inkFaint") }}>
                      <Lat style={{ fontSize: 10 }}>{r.b.lotCode}</Lat> · {expiryText(r.b, expiryLabel)}
                    </div>
                  </div>
                  <Num value={r.b.qty} style={{ fontSize: 15, color: v("ink"), flex: "none" }} />
                </div>
              </Pressable>
            )}
          </VirtualList>
        )}
      </div>
    </div>
  );
}

/** نقطهٔ رنگی + برچسب + عدد — کوچک‌ترین واحدِ خواندنیِ یک راهنما */
function Tick({ tone, label, n, faint }: {
  tone: "ok" | "warn" | "crit"; label: string; n: number; faint?: boolean;
}) {
  return (
    <span style={{ display: "inline-flex", alignItems: "center", gap: 5,
                   fontSize: 10.5, color: v("inkMuted") }}>
      <i style={{ width: 7, height: 7, borderRadius: 99, background: v(tone),
                  opacity: faint ? 0.55 : 1, flex: "none" }} />
      {label} <b style={{ color: v("ink") }}><Num value={n} /></b>
    </span>
  );
}

/* ── گزارش‌ها ─────────────────────────────────────────── */
export function ReportsScreen({ onBack }: { onBack: () => void }) {
  const { catalog, batches, warehouses, movements, suppliers } = useData();
  const nav = useNav();
  const t = useScreenTheme("reports");

  /* ── انقضا به تفکیکِ تأمین‌کننده ─────────────────────────
   *
   * سؤالی که کارفرما موقعِ برگشت‌دادنِ جنس می‌پرسد این است: «کدام
   * شرکت بیشترین جنسِ نزدیک‌به‌انقضا را به من داده؟» جوابش تا حالا
   * فقط با نگاه‌کردن به تک‌تکِ پارت‌ها درمی‌آمد.
   *
   * شمارش بر اساسِ *عدد* است نه تعدادِ پارت — ده پارتِ یک‌تایی و یک
   * پارتِ صدتایی یک وزن ندارند.
   * ────────────────────────────────────────────────────── */
  const bySup = React.useMemo(() => {
    const now = new Date();
    const m = new Map<number | null, { gone: number; crit: number; warn: number; ok: number }>();
    for (const b of batches) {
      if (b.qty <= 0) continue;
      const key = b.supplierId ?? null;
      const e = m.get(key) ?? { gone: 0, crit: 0, warn: 0, ok: 0 };
      const mo = monthsUntil(b.expiry, now);
      if (mo == null) e.ok += b.qty;
      else if (mo < 0) e.gone += b.qty;
      else if (mo < EXPIRY_CRIT_MONTHS) e.crit += b.qty;
      else if (mo < EXPIRY_WARN_MONTHS) e.warn += b.qty;
      else e.ok += b.qty;
      m.set(key, e);
    }
    const nameOf = (id: number | null) =>
      id == null ? "بدونِ تأمین‌کننده" : suppliers.find((s) => s.id === id)?.name ?? "حذف‌شده";
    return [...m.entries()]
      .map(([id, e]) => ({
        id, name: nameOf(id), ...e,
        risk: e.gone + e.crit + e.warn,
        total: e.gone + e.crit + e.warn + e.ok,
      }))
      /* آنکه بیشترین ریسک را داده بالا؛ اگر هیچ‌کس ریسکی ندارد،
         بزرگ‌ترین تأمین‌کننده بالا می‌ماند تا فهرست بی‌ترتیب نشود. */
      .sort((a, z) => z.risk - a.risk || z.total - a.total);
  }, [batches, suppliers]);

  const riskyTotal = bySup.reduce((s, x) => s + x.risk, 0);

  const byCat = React.useMemo(() => {
    const m = new Map<string, { n: number; q: number }>();
    for (const c of catalog) {
      const k = c.c || "بدون دسته";
      const e = m.get(k) ?? { n: 0, q: 0 };
      e.n++; e.q += c.q;
      m.set(k, e);
    }
    return [...m.entries()].sort((a, z) => z[1].n - a[1].n);
  }, [catalog]);

  const byWh = React.useMemo(() => {
    const m = new Map<number, number>();
    for (const b of batches) if (b.qty > 0) m.set(b.warehouseId, (m.get(b.warehouseId) ?? 0) + b.qty);
    return warehouses.map((w) => ({ w, q: m.get(w.id) ?? 0 })).sort((a, z) => z.q - a.q);
  }, [batches, warehouses]);

  const maxCat = Math.max(1, ...byCat.map(([, e]) => e.n));
  const maxWh = Math.max(1, ...byWh.map((x) => x.q));

  return (
    <ScreenScroll>
      <Header theme={t} sub="تحلیلِ انبار" title="گزارش‌ها" onBack={onBack} />

      {/* بالای منحنی سفید است → کارتِ سفید. پایینش سیاه → ردیفِ تیره. */}
      <Pad style={{ marginTop: 14 }}>
        <div style={{ display: "flex", gap: 8 }}>
          <StatBlock label="اقلام" value={<Num value={catalog.length} />} />
          <StatBlock label="پارت‌ها" value={<Num value={batches.length} />} />
          <StatBlock label="حرکت‌ها" value={<Num value={movements.length} />} />
        </div>
      </Pad>

      <Gap h={24} />

      <Pad>
        <SectionLabel count={byCat.length}>پراکندگیِ دسته‌ها</SectionLabel>
        <Gap h={10} />
        <Card tone="dark">
          <div style={{ display: "grid", gap: 13 }}>
            {byCat.slice(0, 8).map(([name, e], i) => (
              <div key={name}>
                <div style={{ display: "flex", alignItems: "baseline", gap: 8 }}>
                  <span style={{ fontSize: 12, fontWeight: 700, color: v("deepInk"), flex: 1,
                                 whiteSpace: "nowrap", overflow: "hidden",
                                 textOverflow: "ellipsis" }}>{name}</span>
                  <span style={{ fontSize: 11.5, fontWeight: 800, color: v("deepInkMuted") }}>
                    <Num value={e.n} />
                  </span>
                </div>
                <div style={{ marginTop: 6, height: 5, borderRadius: 99,
                              background: v("cardDarkAlt") }}>
                  <div style={{
                    /* پرکنندهٔ نوار باید با ریلش تضاد داشته باشد.
                       `accentSurface` رنگِ *سطح* است نه رنگِ تأکید؛ روی
                       ریلِ روشن گم می‌شد. */
                    height: "100%", borderRadius: 99, background: v("accentStrong"),
                    width: `${(e.n / maxCat) * 100}%`,
                    transformOrigin: "right center",   /* اپ همیشه راست‌به‌چپ است */
                    animation: `grow 620ms cubic-bezier(.22,1,.36,1) ${i * 60}ms both`,
                  }} />
                </div>
              </div>
            ))}
          </div>
        </Card>
      </Pad>

      <Gap h={20} />

      <Pad>
        <SectionLabel count={byWh.length}>موجودی بر حسبِ محل</SectionLabel>
        <Gap h={10} />
        <div style={{ display: "grid", gap: 8 }}>
          {byWh.map(({ w, q }) => (
            <DarkRow key={w.id} onPress={() => nav.push("warehouseOne", { id: w.id })} height={58}>
              <IconSquare icon={IconBox} size={32} radius={10} iconSize={14} tone="dark" />
              <div style={{ flex: 1, minWidth: 0, marginInlineStart: 12 }}>
                <div style={{ fontSize: 12.5, fontWeight: 700, color: v("deepInk") }}>{w.name}</div>
                <div style={{ marginTop: 5, height: 4, borderRadius: 99,
                              background: v("cardDarkAlt") }}>
                  <div style={{ height: "100%", borderRadius: 99, background: v("ok"),
                                width: `${(q / maxWh) * 100}%` }} />
                </div>
              </div>
              <Num value={q} style={{ fontSize: 14, fontWeight: 800, color: v("deepInk"),
                                      flex: "none", marginInlineStart: 10 }} />
            </DarkRow>
          ))}
        </div>
      </Pad>

      <Gap h={22} />

      <Pad>
        <SectionLabel count={bySup.length}>انقضا بر اساسِ تأمین‌کننده</SectionLabel>
        <Gap h={10} />
        {bySup.length === 0 ? (
          <Card pad={0}>
            <Empty icon={IconWarn} title="هنوز پارتی ثبت نشده"
                   note="با «ورودِ کالا» یا واردکردنِ فایلِ اکسل پر می‌شود." />
          </Card>
        ) : (
          <>
            <div style={{ display: "grid", gap: 8 }}>
              {bySup.map((s) => (
                <div key={String(s.id)} style={{ padding: "13px 15px", borderRadius: R.row,
                                                 background: v("card"), boxShadow: SHADOW.soft }}>
                  <div style={{ display: "flex", alignItems: "baseline", gap: 8 }}>
                    <span style={{ flex: 1, minWidth: 0, fontSize: 12.5, fontWeight: 700,
                                   color: v("ink"), whiteSpace: "nowrap", overflow: "hidden",
                                   textOverflow: "ellipsis" }}>{s.name}</span>
                    <span style={{ fontSize: 10.5, fontWeight: 700, color: v("inkFaint"),
                                   flex: "none" }}>
                      <Num value={s.total} /> عدد
                    </span>
                  </div>

                  {/* یک نوار، چهار تکه — نسبت‌ها را یک‌جا نشان می‌دهد */}
                  <div style={{ display: "flex", marginTop: 8, height: 6, borderRadius: 99,
                                overflow: "hidden", background: v("surfaceAlt") }}>
                    {([["gone", "crit"], ["crit", "crit"], ["warn", "warn"], ["ok", "ok"]] as const)
                      .map(([k, tone], i) => (
                        s[k] > 0 ? (
                          <i key={k} style={{
                            width: `${(s[k] / s.total) * 100}%`,
                            background: v(tone as any),
                            opacity: i === 0 ? 0.55 : 1,
                          }} />
                        ) : null
                      ))}
                  </div>

                  <div style={{ display: "flex", gap: 12, marginTop: 8, flexWrap: "wrap" }}>
                    {s.gone > 0 && <Tick tone="crit" faint label="گذشته" n={s.gone} />}
                    {s.crit > 0 && <Tick tone="crit" label="زیر ۳ ماه" n={s.crit} />}
                    {s.warn > 0 && <Tick tone="warn" label="زیر ۶ ماه" n={s.warn} />}
                    {s.risk === 0 && <Tick tone="ok" label="همه سالم" n={s.ok} />}
                  </div>
                </div>
              ))}
            </div>

            <div style={{ marginTop: 12, padding: "12px 14px", borderRadius: R.row,
                          background: riskyTotal ? v("warnWash") : v("surfaceAlt"),
                          fontSize: 11, lineHeight: 1.9, fontWeight: riskyTotal ? 700 : 400,
                          color: riskyTotal ? v("warn") : v("inkMuted") }}>
              {riskyTotal
                ? <><Num value={riskyTotal} /> عدد کمتر از شش ماه تا انقضا دارد یا گذشته است.</>
                : "هیچ کالایی نزدیکِ انقضا نیست."}
            </div>
          </>
        )}
      </Pad>

      <style>{`@keyframes grow{ from{ transform:scaleX(0); transform-origin:var(--grow-o, right) } to{ transform:none } }`}</style>
    </ScreenScroll>
  );
}
