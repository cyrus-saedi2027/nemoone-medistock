/* تعریف/ویرایش کالا · انبارگردانی · اکسل · ثبتِ گروهی */

import * as React from "react";
import { v } from "@/system/theme/ThemeProvider";
import { R, SHADOW } from "@/system/tokens";
import { useData, useUi, useActions } from "@/store/StoreProvider";
import { ScreenScroll } from "@/ui/chrome/ScreenScroll";
import { Header } from "@/ui/chrome/Header";
import {
  Gap, Pad, Card, Button, Field, PickerRow, ChoiceRow, SectionLabel, Empty,
  LightRow, IconSquare, StatBlock, Stepper, Chip, Switch,
} from "@/ui/kit";
import { Num, Lat } from "@/ui/text/Text";
import { Reveal } from "@/ui/primitives/Motion";
import {
  IconPill, IconTag, IconFile, IconDownload, IconList, IconCheck, IconBox,
  IconIn, IconTrash, IconUpload, IconForward,
} from "@/ui/icons";
import { useScreenTheme } from "@/screens/useScreenTheme";
import { useNav } from "@/router/Router";
import { Sheet } from "@/ui/overlays/Sheet";
import { ProductSheet } from "@/screens/details/Move";
import { Pressable } from "@/ui/primitives/Pressable";
import { can, defaultWarehouseId } from "@/domain/derive";
import { todayJalaliRaw } from "@/system/i18n/jalali";
import { toFa, toEn } from "@/system/i18n/digits";
import {
  allSheets, sheetProducts, sheetBatches, sheetMovements, type Snapshot,
} from "@/domain/report";
import { KV } from "@/screens/details/Product";

/* ── تعریف / ویرایشِ کالا ─────────────────────────────── */
export function ProductEditScreen({
  params, onBack,
}: { params?: { id?: number }; onBack: () => void }) {
  const { catalog, cats, batches } = useData();
  const { session } = useUi();
  const { addProduct, updateProduct, removeProduct, toast } = useActions();
  const nav = useNav();
  const t = useScreenTheme("productEdit");
  const editing = params?.id != null ? catalog.find((c) => c.i === params.id) : null;

  const [nameFa, setNameFa] = React.useState(editing?.n ?? "");
  const [nameLat, setNameLat] = React.useState(editing?.l ?? "");
  const [cat, setCat] = React.useState(editing?.c ?? (cats[0] ?? "دارو"));
  const [minQty, setMinQty] = React.useState(editing?.m != null ? String(editing.m) : "");
  const [notes, setNotes] = React.useState(editing?.n2 ?? "");
  const [pick, setPick] = React.useState(false);
  const [confirmDel, setConfirmDel] = React.useState(false);

  const may = session ? can(session.role, "editProduct") : false;
  const dupe = React.useMemo(() => {
    const n = nameFa.trim();
    if (n.length < 2) return null;
    return catalog.find((c) => c.i !== editing?.i && c.n.trim() === n) ?? null;
  }, [catalog, nameFa, editing]);
  const ok = nameFa.trim().length >= 2;
  const nBatches = editing ? batches.filter((b) => b.productId === editing.i).length : 0;

  const parsedMin = () => {
    const s = toEn(minQty).replace(/[^\d]/g, "");
    return s === "" ? null : Number(s);
  };

  if (!may) {
    return (
      <ScreenScroll>
        <Header theme={t} title="کالا" onBack={onBack} />
        <Empty icon={IconPill} title="دسترسیِ ویرایش نداری" />
      </ScreenScroll>
    );
  }

  return (
    <>
      <ScreenScroll>
        <Header theme={t} sub={editing ? "ویرایش" : "تعریفِ جدید"}
                title={editing ? "ویرایشِ کالا" : "کالای جدید"} onBack={onBack} />

        <Pad style={{ marginTop: 16 }}>
          <Card>
            <div style={{ display: "grid", gap: 12 }}>
              <Field label="نامِ فارسی" value={nameFa} onChange={setNameFa}
                     placeholder="مثلاً: استامینوفن ۵۰۰" autoFocus={!editing} />
              <Field label="نامِ لاتین (اختیاری)" value={nameLat} onChange={setNameLat} ltr
                     placeholder="Acetaminophen 500" />
            </div>
          </Card>
        </Pad>

        <Pad style={{ marginTop: 10 }}>
          <PickerRow icon={IconTag} label="دسته" value={cat} onPress={() => setPick(true)} />
        </Pad>

        <Pad style={{ marginTop: 10 }}>
          <Card>
            <div style={{ display: "grid", gap: 12 }}>
              <Field label="حداقل موجودی (اختیاری)" value={minQty} onChange={setMinQty}
                     inputMode="numeric" placeholder="زیر این عدد هشدار بدهد" />
              <Field label="توضیحات (اختیاری)" value={notes} onChange={setNotes}
                     placeholder="هر یادداشتی دربارهٔ این کالا" />
            </div>
          </Card>
        </Pad>

        {/* هم‌نام‌بودن ممنوع نیست — همان کالا از دو شرکت واقعاً پیش
            می‌آید — ولی انباردار باید بداند، وگرنه ناخواسته تکراری می‌سازد. */}
        {dupe && (
          <Pad style={{ marginTop: 10 }}>
            <div style={{ padding: "12px 14px", borderRadius: R.row, background: v("warnWash"),
                          fontSize: 11, color: v("warn"), fontWeight: 700, lineHeight: 1.9 }}>
              کالایی با همین نام از قبل هست. اگر همان است، به‌جای ساختنِ
              تازه از «ورودِ کالا» استفاده کن.
            </div>
          </Pad>
        )}

        <Pad style={{ marginTop: 10 }}>
          <div style={{ padding: "12px 14px", borderRadius: R.row, background: v("surfaceAlt"),
                        fontSize: 11, color: v("inkMuted"), lineHeight: 1.9 }}>
            واحدِ همهٔ کالاها «عدد» است. موجودی از پارت‌ها محاسبه می‌شود،
            پس اینجا عددی وارد نمی‌کنی — با «ورودِ کالا» پارت می‌سازی.
          </div>
        </Pad>

        <Pad style={{ marginTop: 20 }}>
          <Button disabled={!ok} onPress={() => {
            if (!ok) return;
            if (editing) {
              updateProduct(editing.i, {
                n: nameFa.trim(), l: nameLat.trim(), c: cat,
                m: parsedMin(), n2: notes.trim(),
              });
              toast("کالا به‌روز شد", { tone: "ok" });
              onBack();
            } else {
              const id = addProduct({
                nameFa: nameFa.trim(), nameLat: nameLat.trim(),
                category: cat, minQty: parsedMin(), notes: notes.trim(),
              });
              toast("کالا ساخته شد", { tone: "ok" });
              nav.push("product", { id });
            }
          }}>{editing ? "ذخیرهٔ تغییرات" : "ساختِ کالا"}</Button>
        </Pad>

        {editing && (
          <Pad style={{ marginTop: 10 }}>
            <Button tone="danger" icon={IconTrash} onPress={() => setConfirmDel(true)}>
              حذفِ کالا
            </Button>
          </Pad>
        )}

        {!editing && (
          <Pad style={{ marginTop: 10 }}>
            <Button tone="ghost" icon={IconUpload} onPress={() => nav.push("importData")}>
              به‌جایش یک فایلِ اکسل وارد کن
            </Button>
          </Pad>
        )}
      </ScreenScroll>

      <Sheet open={pick} onClose={() => setPick(false)} title="دسته">
        <div style={{ display: "grid", gap: 8, paddingBlock: 6 }}>
          {(cats.length ? cats : ["دارو"]).map((c) => (
            <ChoiceRow key={c} label={c} on={c === cat} onPress={() => { setCat(c); setPick(false); }} />
          ))}
        </div>
      </Sheet>

      <Sheet open={confirmDel} onClose={() => setConfirmDel(false)} title="حذفِ کالا"
        footer={
          <div style={{ display: "grid", gap: 8 }}>
            <Button tone="danger" icon={IconTrash} disabled={nBatches > 0} onPress={() => {
              if (!editing) return;
              if (removeProduct(editing.i)) {
                setConfirmDel(false);
                toast("کالا حذف شد", { tone: "ok" });
                onBack();
              } else {
                toast("پارتِ وابسته دارد", { tone: "warn" });
              }
            }}>{nBatches > 0 ? "نمی‌شود حذف کرد" : "بله، حذف کن"}</Button>
            <Button tone="ghost" onPress={() => setConfirmDel(false)}>انصراف</Button>
          </div>
        }>
        <div style={{ paddingBlock: 10, fontSize: 12, lineHeight: 2, color: v("inkMuted") }}>
          {nBatches > 0 ? (
            <>
              این کالا <b style={{ color: v("ink") }}><Num value={nBatches} /></b> پارت دارد و
              حرکت‌های ثبت‌شده به آن اشاره می‌کنند. اول پارت‌ها را خالی و
              جابه‌جا کن، بعد حذف ممکن می‌شود.
            </>
          ) : (
            <>«{editing?.n}» از کاتالوگ برداشته می‌شود. این کار برگشت ندارد.</>
          )}
        </div>
      </Sheet>
    </>
  );
}

/* ── انبارگردانی ──────────────────────────────────────── */
export function StocktakeScreen({ onBack }: { onBack: () => void }) {
  const { warehouses, batches, catalog, users, policy, pending } = useData();
  const { session } = useUi();
  const { applyCounts, approveCount, rejectCount, toast } = useActions();
  const t = useScreenTheme("stocktake");
  const [whId, setWhId] = React.useState<number>(defaultWarehouseId(warehouses));
  const [pickWh, setPickWh] = React.useState(false);
  const [counted, setCounted] = React.useState<Record<number, number>>({});
  const [active, setActive] = React.useState<number | null>(null);

  const may = session ? can(session.role, "move") : false;
  const isAdmin = session ? can(session.role, "users") : false;

  /* صفِ تأیید: مدیر همه را می‌بیند، بقیه فقط درخواستِ خودشان را —
     انباردار باید بداند ثبتش گم نشده، ولی صفِ کلِ داروخانه کارِ او نیست. */
  const queue = React.useMemo(() => {
    const byBatch = new Map(batches.map((b) => [b.id, b]));
    const byProd = new Map(catalog.map((c) => [c.i, c]));
    const byUser = new Map(users.map((u) => [u.id, u]));
    return pending
      .filter((q) => isAdmin || q.userId === session?.id)
      .map((q) => {
        const b = byBatch.get(q.batchId);
        return { q, b, p: b ? byProd.get(b.productId) : undefined, u: byUser.get(q.userId) };
      });
  }, [pending, batches, catalog, users, isAdmin, session?.id]);

  /* ── بدونِ `slice` ────────────────────────────────────────
   * تا نسخهٔ ۱٫۴٫۱ اینجا `.slice(0, 60)` بود. یعنی روی «انبار اصلی»
   * که ۱٬۱۳۲ پارت دارد، کارتِ بالای صفحه «۶۰ پارت» می‌گفت و انباردار
   * فقط ۶۰ تا را می‌توانست بشمارد — بقیهٔ انبار برایش وجود نداشت.
   * انبارگردانیِ ناقص از انبارگردانی‌نکردن بدتر است، چون آدم فکر
   * می‌کند تمام شده.
   *
   * رندر با دکمهٔ «نمایشِ بیشتر» صفحه‌ای است، ولی عدد و شمارش روی
   * *همهٔ* پارت‌ها کار می‌کند. */
  const rows = React.useMemo(() => {
    const byProd = new Map(catalog.map((c) => [c.i, c]));
    return batches
      .filter((b) => b.warehouseId === whId && b.qty > 0)
      .map((b) => ({ b, p: byProd.get(b.productId) }))
      .filter((x) => !!x.p);
  }, [batches, catalog, whId]);

  const PAGE = 60;
  const [shown, setShown] = React.useState(PAGE);
  React.useEffect(() => { setShown(PAGE); }, [whId]);

  const done = Object.keys(counted).length;
  const diffs = rows.filter((r) => counted[r.b.id] != null && counted[r.b.id] !== r.b.qty);

  if (!may) {
    return (
      <ScreenScroll>
        <Header theme={t} title="انبارگردانی" onBack={onBack} />
        <Empty icon={IconList} title="دسترسیِ ثبت نداری" />
      </ScreenScroll>
    );
  }

  const target = active != null ? rows.find((r) => r.b.id === active) : null;

  return (
    <>
      <ScreenScroll>
        <Header theme={t} sub="شمارشِ فیزیکی" title="انبارگردانی" onBack={onBack} />

        <Pad style={{ marginTop: 14 }}>
          <div style={{ display: "flex", gap: 8 }}>
            <StatBlock tone="dark" label="پارت‌ها" value={<Num value={rows.length} />} />
            <StatBlock tone="dark" label="شمرده" value={<Num value={done} />} />
            <StatBlock tone="dark" label="اختلاف" value={<Num value={diffs.length} />}
                       tint={diffs.length ? v("crit") : undefined} />
          </div>
        </Pad>

        {/* ── منتظرِ تأیید ────────────────────────────────────
            بالای صفحه می‌نشیند نه پایین: چیزی که کارِ کسی را متوقف
            کرده باید اولین چیزی باشد که دیده می‌شود. */}
        {queue.length > 0 && (
          <>
            <Gap h={22} />
            <Pad>
              <SectionLabel count={queue.length}>
                {isAdmin ? "منتظرِ تأییدِ تو" : "منتظرِ تأییدِ مدیر"}
              </SectionLabel>
              <Gap h={10} />
              <div style={{ display: "grid", gap: 8 }}>
                {queue.map(({ q, b, p, u }) => {
                  const d = q.to - q.from;
                  return (
                    <div key={q.id} style={{ padding: "13px 15px", borderRadius: R.row,
                                             background: v("card"), boxShadow: SHADOW.soft }}>
                      <div style={{ display: "flex", alignItems: "center", gap: 10 }}>
                        <div style={{ flex: 1, minWidth: 0 }}>
                          <div style={{ fontSize: 12.5, fontWeight: 700, color: v("ink"),
                                        whiteSpace: "nowrap", overflow: "hidden",
                                        textOverflow: "ellipsis" }}>
                            {p?.n ?? "کالای حذف‌شده"}
                          </div>
                          <div style={{ marginTop: 3, fontSize: 10.5, color: v("inkFaint") }}>
                            {b ? <Lat style={{ fontSize: 10 }}>{b.lotCode}</Lat> : "پارتِ ناموجود"}
                            {u ? ` · ${u.fullName ?? u.username}` : ""}
                          </div>
                        </div>
                        <div style={{ textAlign: "end", flex: "none" }}>
                          <div style={{ fontSize: 14, fontWeight: 800,
                                        color: d > 0 ? v("ok") : v("crit") }}>
                            {d > 0 ? "+" : "−"}<Num value={Math.abs(d)} />
                          </div>
                          <div style={{ fontSize: 9.5, color: v("inkFaint") }}>
                            <Num value={q.from} /> ← <Num value={q.to} />
                          </div>
                        </div>
                      </div>

                      {isAdmin && (
                        <div style={{ display: "flex", gap: 8, marginTop: 12 }}>
                          <div style={{ flex: 1 }}>
                            <Button onPress={() => {
                              approveCount(q.id);
                              toast("اعمال شد", { tone: "ok" });
                            }}>تأیید</Button>
                          </div>
                          <div style={{ flex: 1 }}>
                            <Button tone="ghost" onPress={() => {
                              rejectCount(q.id);
                              toast("رد شد — موجودی دست‌نخورده ماند", { tone: "warn" });
                            }}>رد</Button>
                          </div>
                        </div>
                      )}
                    </div>
                  );
                })}
              </div>
            </Pad>
          </>
        )}

        <Gap h={22} />

        <Pad>
          <PickerRow icon={IconBox} label="محل" value={warehouses.find((w) => w.id === whId)?.name}
                     onPress={() => setPickWh(true)} />
        </Pad>

        <Gap h={14} />

        <Pad>
          <SectionLabel count={rows.length}>فهرستِ شمارش</SectionLabel>
          <Gap h={10} />
          {rows.length === 0 ? (
            <Card pad={0}><Empty icon={IconBox} title="این محل خالی است" /></Card>
          ) : (
            <div style={{ display: "grid", gap: 8 }}>
              {rows.slice(0, shown).map((r, i) => {
                const c = counted[r.b.id];
                const diff = c != null ? c - r.b.qty : null;
                return (
                  <Reveal key={r.b.id} i={Math.min(i, 8)} step={30}>
                    <LightRow onPress={() => setActive(r.b.id)} height={64}>
                      <div style={{
                        width: 26, height: 26, borderRadius: 999, flex: "none",
                        display: "grid", placeItems: "center",
                        background: c != null ? (diff === 0 ? v("okWash") : v("warnWash")) : v("surfaceAlt"),
                      }}>
                        {c != null
                          ? <IconCheck size={13} stroke={3} color={diff === 0 ? v("ok") : v("warn")} />
                          : <span style={{ fontSize: 10, fontWeight: 800, color: v("inkFaint") }}>
                              {toFa(i + 1)}
                            </span>}
                      </div>
                      <div style={{ flex: 1, minWidth: 0, marginInlineStart: 11 }}>
                        <div style={{ fontSize: 12.5, fontWeight: 700, color: v("ink"),
                                      whiteSpace: "nowrap", overflow: "hidden",
                                      textOverflow: "ellipsis" }}>{r.p!.n}</div>
                        <div style={{ marginTop: 2, fontSize: 10, color: v("inkFaint") }}>
                          <Lat style={{ fontSize: 10 }}>{r.b.lotCode}</Lat> · سیستم <Num value={r.b.qty} />
                        </div>
                      </div>
                      {c != null && (
                        <div style={{ textAlign: "end", flex: "none" }}>
                          <Num value={c} style={{ fontSize: 15,
                                                  color: diff === 0 ? v("ok") : v("warn") }} />
                          {diff !== 0 && (
                            <div style={{ fontSize: 9.5, fontWeight: 800, color: v("warn") }}>
                              {diff! > 0 ? "+" : "−"}<Num value={Math.abs(diff!)} />
                            </div>
                          )}
                        </div>
                      )}
                    </LightRow>
                  </Reveal>
                );
              })}
              {rows.length > shown && (
                <Pressable onPress={() => setShown((n) => n + PAGE)}
                  ariaLabel="نمایشِ بیشتر"
                  style={{
                    height: 46, borderRadius: R.row, display: "grid", placeItems: "center",
                    background: v("card"), boxShadow: SHADOW.soft, marginTop: 2,
                  }}>
                  <span style={{ fontSize: 12, fontWeight: 800, color: v("ink") }}>
                    نمایشِ <Num value={Math.min(PAGE, rows.length - shown)} /> پارتِ بعدی
                    {" · "}
                    <span style={{ color: v("inkFaint"), fontWeight: 700 }}>
                      <Num value={rows.length - shown} /> مانده
                    </span>
                  </span>
                </Pressable>
              )}
            </div>
          )}
        </Pad>

        {diffs.length > 0 && (
          <Pad style={{ marginTop: 20 }}>
            {policy.stocktakeApproval && !isAdmin && (
              <div style={{ marginBottom: 10, padding: "12px 14px", borderRadius: R.row,
                            background: v("warnWash"), fontSize: 11, fontWeight: 700,
                            color: v("warn"), lineHeight: 1.9 }}>
                اختلافِ بیشتر از <Num value={policy.stocktakeThreshold} /> عدد به مدیر
                فرستاده می‌شود و تا تأییدِ او اعمال نمی‌شود.
              </div>
            )}
            <Button onPress={() => {
              const r = applyCounts(diffs.map((d) => ({
                batchId: d.b.id, from: d.b.qty, to: counted[d.b.id],
              })));
              setCounted({});
              toast(
                r.queued === 0 ? `${toFa(r.applied)} اختلاف اعمال شد`
                : r.applied === 0 ? `${toFa(r.queued)} مورد به مدیر رفت`
                : `${toFa(r.applied)} اعمال شد · ${toFa(r.queued)} منتظرِ تأیید`,
                { tone: r.queued ? "warn" : "ok" }
              );
            }}>اعمالِ <Num value={diffs.length} /> اختلاف</Button>
          </Pad>
        )}
      </ScreenScroll>

      <Sheet open={pickWh} onClose={() => setPickWh(false)} title="محلِ شمارش">
        <div style={{ display: "grid", gap: 8, paddingBlock: 6 }}>
          {warehouses.map((w) => (
            <ChoiceRow key={w.id} label={w.name} on={w.id === whId}
                       onPress={() => { setWhId(w.id); setCounted({}); setPickWh(false); }} />
          ))}
        </div>
      </Sheet>

      <Sheet
        open={active != null}
        onClose={() => setActive(null)}
        title={target?.p?.n ?? "شمارش"}
        footer={
          <Button onPress={() => setActive(null)}>ثبتِ شمارش</Button>
        }
      >
        {target && (
          <div style={{ paddingBlock: 10 }}>
            <div style={{ fontSize: 11.5, color: v("inkFaint"), marginBottom: 12 }}>
              موجودیِ سیستم: <b style={{ color: v("ink") }}><Num value={target.b.qty} /></b> عدد
            </div>
            <Stepper
              value={counted[target.b.id] ?? target.b.qty}
              onChange={(n) => setCounted((c) => ({ ...c, [target.b.id]: n }))}
              min={0}
            />
          </div>
        )}
      </Sheet>
    </>
  );
}

/* ── خروجیِ اکسل ──────────────────────────────────────────
 *
 * قبلاً یک CSVِ شش‌ستونی می‌ساخت که نه انبار داشت، نه تأمین‌کننده، نه
 * انقضا، نه حداقلِ موجودی — یعنی هیچ‌کدام از ستون‌هایی که کارفرما
 * خودش در فایلش داشت. حالا xlsxِ واقعی با هشت برگه ساخته می‌شود و
 * ستون‌هایش دقیقاً همان قالبِ اوست، به‌علاوهٔ ستون‌های محاسبه‌شده.
 * ────────────────────────────────────────────────────────── */

type ExportKind = "all" | "products" | "batches" | "moves";

const KINDS: { k: ExportKind; fa: string }[] = [
  { k: "all",      fa: "بستهٔ کامل" },
  { k: "products", fa: "کالاها" },
  { k: "batches",  fa: "پارت‌ها" },
  { k: "moves",    fa: "حرکت‌ها" },
];

export function ExcelScreen({ onBack }: { onBack: () => void }) {
  const { catalog, batches, movements, warehouses, suppliers, users, cats } = useData();
  const { session } = useUi();
  const { toast } = useActions();
  const nav = useNav();
  const t = useScreenTheme("excel");
  const [kind, setKind] = React.useState<ExportKind>("all");
  const [csv, setCsv] = React.useState(false);
  const [busy, setBusy] = React.useState(false);

  const snap: Snapshot = { catalog, batches, movements, warehouses, suppliers, users, cats };

  const sheets = React.useMemo(() => {
    if (kind === "all") return allSheets(snap);
    if (kind === "products") return [sheetProducts(snap)];
    if (kind === "batches") return [sheetBatches(snap)];
    return [sheetMovements(snap)];
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [kind, catalog, batches, movements, warehouses, suppliers, users, cats]);

  const rowCount = sheets.reduce((n, s) => n + s.rows.length, 0);
  /* CSV یک برگه بیشتر نمی‌گیرد — «بستهٔ کامل» با آن بی‌معناست */
  const csvAllowed = sheets.length === 1;

  /* `import()` پویا: نویسندهٔ xlsx (ZIP + CRC + XML) حدودِ ۵KB است و
     فقط همین‌جا و در ورودِ گروهی لازم می‌شود. با ایستا واردکردنش،
     هر بارِ اولِ اپ روی نتِ ضعیف ۵KB بی‌مصرف دانلود می‌شد. */
  const build = async () => {
    if (busy) return;
    setBusy(true);
    try {
      const { buildXlsx, buildCsv, download } = await import("@/system/xlsx");
      const stamp = todayJalaliRaw().replace(/\//g, "-");
      if (csv && csvAllowed) {
        download(buildCsv(sheets[0]), `medistock-${kind}-${stamp}.csv`);
      } else {
        download(await buildXlsx(sheets), `medistock-${kind}-${stamp}.xlsx`);
      }
      toast("فایل ساخته شد", { tone: "ok" });
    } catch {
      toast("ساختِ فایل نشد — دوباره امتحان کن", { tone: "crit" });
    } finally {
      setBusy(false);
    }
  };

  const mayImport = session ? can(session.role, "editProduct") : false;

  return (
    <ScreenScroll>
      <Header theme={t} sub="گرفتنِ خروجی" title="خروجی اکسل" onBack={onBack} />

      <Pad style={{ marginTop: 16 }}>
        <div style={{ display: "flex", gap: 7, flexWrap: "wrap" }}>
          {KINDS.map((x) => (
            <Chip key={x.k} on={kind === x.k} onPress={() => setKind(x.k)}>{x.fa}</Chip>
          ))}
        </div>
      </Pad>

      <Pad style={{ marginTop: 16 }}>
        <Card tone="dark">
          <div style={{ display: "flex", alignItems: "center", gap: 12 }}>
            <IconSquare icon={IconFile} size={44} radius={14} iconSize={20} tone="accent" />
            <div style={{ flex: 1, minWidth: 0 }}>
              <div style={{ fontSize: 14, fontWeight: 800, color: v("deepInk") }}>
                <Num value={sheets.length} /> برگه · <Num value={rowCount} /> ردیف
              </div>
              <div style={{ marginTop: 3, fontSize: 11, color: v("deepInkMuted"), lineHeight: 1.7 }}>
                {sheets.map((s) => s.name).join(" · ")}
              </div>
            </div>
          </div>

          <Gap h={14} />
          <div style={{ display: "grid", gap: 9 }}>
            {sheets.map((s) => (
              <KV key={s.name} label={s.name} value={<Num value={s.rows.length} />} />
            ))}
          </div>

          <Gap h={16} />
          <Button icon={IconDownload} disabled={busy} onPress={build}>
            {busy ? "در حالِ ساخت…" : csv && csvAllowed ? "دانلودِ CSV" : "دانلودِ اکسل"}
          </Button>
        </Card>
      </Pad>

      <Pad style={{ marginTop: 12 }}>
        <LightRow height={62}>
          <IconSquare icon={IconFile} size={32} radius={10} iconSize={14} />
          <div style={{ flex: 1, minWidth: 0, marginInlineStart: 12 }}>
            <div style={{ fontSize: 12.5, fontWeight: 700, color: v("ink") }}>
              به‌جایش CSV بده
            </div>
            <div style={{ fontSize: 10.5, color: v("inkFaint"), lineHeight: 1.7 }}>
              {csvAllowed
                ? "ساده‌تر، ولی بدونِ چند برگه و بدونِ قالب‌بندی"
                : "برای «بستهٔ کامل» ممکن نیست — CSV چند برگه ندارد"}
            </div>
          </div>
          <Switch on={csv && csvAllowed} onChange={(on) => setCsv(on && csvAllowed)}
                  label="خروجیِ CSV" />
        </LightRow>
      </Pad>

      {mayImport && (
        <Pad style={{ marginTop: 12 }}>
          <LightRow height={62} onPress={() => nav.push("importData")}>
            <IconSquare icon={IconUpload} size={32} radius={10} iconSize={14} />
            <div style={{ flex: 1, minWidth: 0, marginInlineStart: 12 }}>
              <div style={{ fontSize: 12.5, fontWeight: 700, color: v("ink") }}>
                ورودِ گروهی از اکسل
              </div>
              <div style={{ fontSize: 10.5, color: v("inkFaint") }}>
                همین قالب را پر کن و برگردان
              </div>
            </div>
            <IconForward size={15} stroke={2} color={v("inkFaint")} />
          </LightRow>
        </Pad>
      )}

      <Pad style={{ marginTop: 14 }}>
        <div style={{ padding: "13px 15px", borderRadius: R.row,
                      background: v("surfaceAlt"),
                      fontSize: 11, color: v("inkMuted"), lineHeight: 2 }}>
          فایل روی همین دستگاه ساخته می‌شود و جایی فرستاده نمی‌شود؛
          بدونِ اینترنت هم کار می‌کند.
        </div>
      </Pad>
    </ScreenScroll>
  );
}

/* ── ثبتِ گروهی ───────────────────────────────────────── */
