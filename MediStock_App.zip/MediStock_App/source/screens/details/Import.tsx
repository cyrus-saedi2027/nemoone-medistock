/* ─────────────────────────────────────────────────────────────
 *  ورودِ گروهی از اکسل / CSV
 *
 *  کارفرما ۵۰۱۰ قلم را در اکسل داد. هر بار که فهرست به‌روز شود،
 *  دستی زدنش غیرممکن است. این صفحه همان فایل را می‌خورد.
 *
 *  سه اصل:
 *   ۱) هیچ‌چیز بدونِ پیش‌نمایش اعمال نمی‌شود — اول می‌گوید چه اتفاقی
 *      می‌افتد، بعد دکمهٔ تأیید می‌آید.
 *   ۲) ستون‌ها با *نامِ نرمال‌شده* پیدا می‌شوند، نه با شمارهٔ ستون.
 *      پس اگر کسی ستونی جابه‌جا کرد یا «ي» عربی نوشت، باز کار می‌کند.
 *   ۳) اگر کالایی از قبل هست، دوباره ساخته نمی‌شود؛ فقط موجودی
 *      اضافه می‌شود. وگرنه کاتالوگ با هر ورود دوبرابر می‌شد.
 * ───────────────────────────────────────────────────────────── */

import * as React from "react";
import { v } from "@/system/theme/ThemeProvider";
import { R } from "@/system/tokens";
import { useActions, useUi, type ImportRow, type ImportResult } from "@/store/StoreProvider";
import { ScreenScroll } from "@/ui/chrome/ScreenScroll";
import { Header } from "@/ui/chrome/Header";
import { Gap, Pad, Card, Button, SectionLabel, Empty, LightRow, IconSquare, Switch } from "@/ui/kit";
import { Num } from "@/ui/text/Text";
import { Reveal } from "@/ui/primitives/Motion";
import { IconUpload, IconFile, IconCheck, IconWarn, IconDownload, IconList } from "@/ui/icons";
import { useScreenTheme } from "@/screens/useScreenTheme";
import { useNav } from "@/router/Router";
import { can } from "@/domain/derive";
import type { Table } from "@/system/xlsxRead";
import { normalize } from "@/system/i18n/normalize";
import { toEn } from "@/system/i18n/digits";
import { fromJalali } from "@/system/i18n/jalali";
import { KV } from "@/screens/details/Product";

/* ── نگاشتِ ستون ─────────────────────────────────────── */
type Field =
  | "nameFa" | "nameLat" | "category" | "warehouse" | "supplier"
  | "expiry" | "entryDate" | "qty" | "minQty" | "notes";

/** کلیدواژه‌های هر ستون. تطبیق «شامل بودن» است، نه برابری. */
const HINTS: Record<Field, string[]> = {
  nameFa:    ["نام دارو", "نام کالا", "نام فارسی", "کالا", "دارو", "نام"],
  nameLat:   ["نام لاتین", "لاتین", "english", "latin"],
  category:  ["دسته"],
  warehouse: ["انبار", "محل"],
  supplier:  ["تامین", "تأمین", "شرکت", "پخش"],
  expiry:    ["انقضا", "expire", "exp"],
  entryDate: ["ورود به انبار", "تاریخ ورود", "ورود"],
  qty:       ["تعداد موجودی", "موجودی", "تعداد"],
  minQty:    ["حداقل"],
  notes:     ["توضیح", "یادداشت"],
};

/** ستون‌هایی که باید *قبل* از ستون‌های عام‌تر امتحان شوند */
const ORDER: Field[] = [
  "nameLat", "nameFa", "category", "entryDate", "expiry",
  "minQty", "qty", "warehouse", "supplier", "notes",
];

function mapColumns(head: string[]) {
  const norm = head.map((h) => normalize(h));
  const used = new Set<number>();
  const at: Partial<Record<Field, number>> = {};

  for (const f of ORDER) {
    for (const hint of HINTS[f]) {
      const key = normalize(hint);
      const i = norm.findIndex((h, ix) => !used.has(ix) && h.includes(key));
      if (i >= 0) { at[f] = i; used.add(i); break; }
    }
  }
  return at;
}

/* ── تبدیلِ مقدارها ───────────────────────────────────── */
const num = (s: string) => {
  const n = Number(toEn(s).replace(/[^\d.-]/g, ""));
  return Number.isFinite(n) ? n : 0;
};

/**
 * «۲۰۲۷/۰۳» یا «2027-03» یا «03/2027» → «2027-03».
 * سالِ چهاررقمیِ بزرگ‌تر از ۱۹۰۰ میلادی است، وگرنه شمسی.
 */
/**
 * «این قلم انقضا ندارد» را از خودِ سلول می‌فهمد.
 *
 * چرا لازم است: سلولِ *خالی* یعنی «نمی‌دانیم»، و آن دو تا در اپ دو
 * چیزِ متفاوت‌اند. بدونِ این، تنها راهِ گفتنِ «ندارد» در یک فایلِ
 * اکسل، نگذاشتنِ هیچ چیز است — که همان «نمی‌دانیم» می‌شود و کارِ
 * ناتمام را از کارِ تمام‌شده جدا نمی‌کند.
 */
function isNoExpiry(raw: string): boolean {
  const s = normalize(raw);
  return s === "ندارد" || s === "بدون" || s === "بدون انقضا"
      || s === "بدون تاریخ" || s === "بدون تاریخ انقضا" || s === "-";
}

function parseExpiry(raw: string): string {
  const s = toEn(raw).trim();
  if (!s) return "";
  const parts = s.split(/[^\d]+/).filter(Boolean).map(Number);
  if (parts.length < 2) return "";
  let [a, b] = parts;
  if (a < 100 && b > 1000) [a, b] = [b, a];      // 03/2027
  if (a > 1900) return `${a}-${String(b).padStart(2, "0")}`;
  if (a > 1200 && a < 1600) {                     // شمسی
    const d = fromJalali(a, Math.min(12, Math.max(1, b)), 15);
    return `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, "0")}`;
  }
  return "";
}

/** «۱۴۰۵/۰۵/۰۲» یا «2026-08-08» → ISO. خالی یعنی نامعلوم. */
function parseDate(raw: string): string {
  const s = toEn(raw).trim();
  if (!s) return "";
  const p = s.split(/[^\d]+/).filter(Boolean).map(Number);
  if (p.length < 3) return "";
  const [a, b, c] = p;
  if (a > 1900) return new Date(a, b - 1, c).toISOString();
  if (a > 1200 && a < 1600) return fromJalali(a, b, c).toISOString();
  return "";
}

function toRows(t: Table): ImportRow[] {
  const at = mapColumns(t.head);
  const get = (r: string[], f: Field) => {
    const i = at[f];
    return i == null ? "" : (r[i] ?? "").trim();
  };
  return t.rows.map((r) => ({
    nameFa: get(r, "nameFa"),
    nameLat: get(r, "nameLat"),
    category: get(r, "category"),
    warehouse: get(r, "warehouse"),
    supplier: get(r, "supplier"),
    expiry: parseExpiry(get(r, "expiry")),
    noExpiry: isNoExpiry(get(r, "expiry")),
    entryDate: parseDate(get(r, "entryDate")),
    qty: num(get(r, "qty")),
    minQty: get(r, "minQty") ? num(get(r, "minQty")) : null,
    notes: get(r, "notes"),
  })).filter((x) => x.nameFa);
}

const FIELD_FA: Record<Field, string> = {
  nameFa: "نام دارو / کالا", nameLat: "نام لاتین", category: "دسته‌بندی",
  warehouse: "انبار", supplier: "تأمین‌کننده", expiry: "تاریخ انقضا",
  entryDate: "تاریخ ورود", qty: "تعداد موجودی", minQty: "حداقل موجودی", notes: "توضیحات",
};

/* ── صفحه ─────────────────────────────────────────────── */
type Stage =
  | { k: "idle" }
  | { k: "busy" }
  | { k: "ready"; rows: ImportRow[]; found: Field[]; missing: Field[]; fileName: string }
  | { k: "done"; res: ImportResult }
  | { k: "error"; msg: string };

export function ImportScreen({ onBack }: { onBack: () => void }) {
  const { session } = useUi();
  const { importRows, toast } = useActions();
  const nav = useNav();
  const t = useScreenTheme("importData");
  const [stage, setStage] = React.useState<Stage>({ k: "idle" });
  const [withStock, setWithStock] = React.useState(true);
  const pick = React.useRef<HTMLInputElement>(null);

  const may = session ? can(session.role, "editProduct") : false;

  if (!may) {
    return (
      <ScreenScroll>
        <Header theme={t} title="ورودِ گروهی" onBack={onBack} />
        <Empty icon={IconUpload} title="دسترسیِ ثبت نداری"
               note="فقط مدیر و انباردار می‌توانند فهرست وارد کنند." />
      </ScreenScroll>
    );
  }

  const onFile = async (f: File | undefined) => {
    if (!f) return;
    setStage({ k: "busy" });
    try {
      /* خواننده و نویسندهٔ فایل هر دو پویا بار می‌شوند — تا وقتی کسی
         واقعاً فایل ندهد، یک بایتشان هم دانلود نمی‌شود. */
      const { readTable } = await import("@/system/xlsxRead");
      const table = await readTable(f);
      const at = mapColumns(table.head);
      const found = (Object.keys(FIELD_FA) as Field[]).filter((k) => at[k] != null);
      const missing = (Object.keys(FIELD_FA) as Field[]).filter((k) => at[k] == null);
      if (!found.includes("nameFa")) {
        setStage({ k: "error", msg: "ستونِ «نام دارو / کالا» پیدا نشد. سرصفحهٔ فایل را چک کن." });
        return;
      }
      const rows = toRows(table);
      if (!rows.length) {
        setStage({ k: "error", msg: "هیچ ردیفِ پُری در فایل نبود." });
        return;
      }
      setStage({ k: "ready", rows, found, missing, fileName: f.name });
    } catch (e: any) {
      setStage({ k: "error", msg: e?.message || "فایل خوانده نشد" });
    }
  };

  /** قالبِ خالی برای وقتی کارفرما از صفر می‌خواهد پر کند */
  const template = async () => {
    const { buildXlsx, download } = await import("@/system/xlsx");
    const blob = await buildXlsx([{
      name: "لیست محصولات",
      title: "لیست محصولات انبار داروخانه   —   MediStock",
      note: "هر ردیف = یک پارت از یک کالا.  اگر یک دارو را از دو شرکت یا با دو "
          + "تاریخ انقضای مختلف دارید، برای هرکدام یک ردیف جدا بزنید.  "
          + "فقط ستونِ «نام دارو / کالا» اجباری است.  "
          + "تاریخ انقضا شمسی یا میلادی — هر دو خوانده می‌شود.  "
          + "اگر کالایی اصلاً تاریخ انقضا ندارد، در همان ستون بنویسید «ندارد».",
      labelFirstCol: true,
      head: ["نام دارو / کالا", "نام لاتین", "دسته‌بندی", "انبار", "شرکت تأمین‌کننده",
             "تاریخ انقضا", "تاریخ ورود به انبار", "تعداد موجودی", "واحد شمارش",
             "حداقل موجودی", "توضیحات"],
      widths: [52, 46, 22, 20, 24, 16, 20, 16, 14, 16, 30],
      rows: [["استامینوفن ۵۰۰", "Acetaminophen 500", "دارو", "انبار اصلی", "داروپخش",
              "2027/03", "1405/05/02", 120, "عدد", 20,
              "ردیفِ نمونه — پاک کنید و اطلاعاتِ خودتان را وارد کنید"],
             ["باند کشی ۱۰ سانتی", "Elastic bandage 10cm", "تجهیزات پزشکی و ارتوپدی",
              "انبار اصلی", "", "ندارد", "", 40, "عدد", "",
              "نمونهٔ کالایی که تاریخ انقضا ندارد"]],
    }]);
    download(blob, "medistock-template.xlsx");
    toast("قالبِ خالی ساخته شد", { tone: "ok" });
  };

  return (
    <ScreenScroll>
      <Header theme={t} sub="از فایلِ اکسل" title="ورودِ گروهی" onBack={onBack} />

      <input
        ref={pick}
        type="file"
        accept=".xlsx,.csv,text/csv,application/vnd.openxmlformats-officedocument.spreadsheetml.sheet"
        style={{ display: "none" }}
        onChange={(e) => { onFile(e.target.files?.[0]); e.target.value = ""; }}
      />

      {stage.k === "idle" && (
        <>
          <Pad style={{ marginTop: 16 }}>
            <Card>
              <div style={{ display: "flex", alignItems: "center", gap: 12 }}>
                <IconSquare icon={IconUpload} size={44} radius={14} iconSize={20} tone="accent" />
                <div style={{ flex: 1, minWidth: 0 }}>
                  <div style={{ fontSize: 14, fontWeight: 800, color: v("ink") }}>
                    فایلِ اکسل یا CSV
                  </div>
                  <div style={{ marginTop: 3, fontSize: 11, color: v("inkFaint"), lineHeight: 1.8 }}>
                    ستون‌ها خودکار شناخته می‌شوند — جای ستون‌ها هم مهم نیست
                  </div>
                </div>
              </div>
              <Gap h={16} />
              <Button icon={IconUpload} onPress={() => pick.current?.click()}>
                انتخابِ فایل
              </Button>
            </Card>
          </Pad>

          <Pad style={{ marginTop: 12 }}>
            <Button tone="ghost" icon={IconDownload} onPress={template}>
              گرفتنِ قالبِ خالی
            </Button>
          </Pad>

          <Gap h={22} />

          <Pad>
            <SectionLabel>چه اتفاقی می‌افتد</SectionLabel>
            <Gap h={10} />
            <div style={{ display: "grid", gap: 8 }}>
              <Note icon={IconCheck} title="کالای تازه ساخته می‌شود"
                    note="هر نامی که در کاتالوگ نباشد، اضافه می‌شود." />
              <Note icon={IconCheck} title="کالای تکراری ساخته نمی‌شود"
                    note="اگر نام از قبل باشد فقط موجودی‌اش زیاد می‌شود. ی/ك و نیم‌فاصله خودکار یکسان می‌شوند." />
              <Note icon={IconCheck} title="انبار و تأمین‌کننده خودکار ساخته می‌شوند"
                    note="لازم نیست از قبل تعریفشان کنی." />
              <Note icon={IconWarn} title="چیزی پاک نمی‌شود"
                    note="ورودِ گروهی فقط اضافه می‌کند؛ کالای موجود را حذف نمی‌کند." />
            </div>
          </Pad>
        </>
      )}

      {stage.k === "busy" && (
        <Pad style={{ marginTop: 30 }}>
          <Empty icon={IconFile} title="در حالِ خواندنِ فایل…" />
        </Pad>
      )}

      {stage.k === "error" && (
        <>
          <Pad style={{ marginTop: 18 }}>
            <div style={{ padding: "14px 16px", borderRadius: R.row, background: v("critWash"),
                          color: v("crit"), fontSize: 12, fontWeight: 700, lineHeight: 2 }}>
              {stage.msg}
            </div>
          </Pad>
          <Pad style={{ marginTop: 14 }}>
            <Button tone="ghost" onPress={() => setStage({ k: "idle" })}>دوباره</Button>
          </Pad>
        </>
      )}

      {stage.k === "ready" && (
        <>
          <Pad style={{ marginTop: 16 }}>
            <Card>
              <div style={{ fontSize: 13, fontWeight: 800, color: v("ink"), wordBreak: "break-all" }}>
                {stage.fileName}
              </div>
              <Gap h={12} />
              <div style={{ display: "grid", gap: 11 }}>
                <KV label="ردیفِ خوانده‌شده" value={<Num value={stage.rows.length} />} />
                <KV label="ستون‌های شناخته‌شده"
                    value={stage.found.map((f) => FIELD_FA[f]).join("، ")} />
                {stage.missing.length > 0 && (
                  <KV label="ستون‌های نیامده"
                      value={stage.missing.map((f) => FIELD_FA[f]).join("، ")}
                      tint={v("inkFaint")} />
                )}
              </div>
            </Card>
          </Pad>

          <Pad style={{ marginTop: 12 }}>
            <LightRow height={62}>
              <IconSquare icon={IconList} size={32} radius={10} iconSize={14} />
              <div style={{ flex: 1, minWidth: 0, marginInlineStart: 12 }}>
                <div style={{ fontSize: 12.5, fontWeight: 700, color: v("ink") }}>
                  موجودی هم وارد شود
                </div>
                <div style={{ fontSize: 10.5, color: v("inkFaint"), lineHeight: 1.7 }}>
                  خاموش یعنی فقط نامِ کالاها ثبت شود، بدونِ تعداد و انقضا
                </div>
              </div>
              <Switch on={withStock} onChange={setWithStock} label="ورودِ موجودی" />
            </LightRow>
          </Pad>

          <Pad style={{ marginTop: 18 }}>
            <Button icon={IconCheck} onPress={() => {
              const res = importRows(stage.rows, { withStock });
              setStage({ k: "done", res });
            }}>
              وارد کردنِ <Num value={stage.rows.length} /> ردیف
            </Button>
          </Pad>

          <Pad style={{ marginTop: 10 }}>
            <Button tone="ghost" onPress={() => setStage({ k: "idle" })}>انصراف</Button>
          </Pad>
        </>
      )}

      {stage.k === "done" && (
        <>
          <Pad style={{ marginTop: 16 }}>
            <Card>
              <div style={{ display: "flex", alignItems: "center", gap: 12 }}>
                <IconSquare icon={IconCheck} size={44} radius={14} iconSize={20} tone="accent" />
                <div style={{ fontSize: 14, fontWeight: 800, color: v("ink") }}>انجام شد</div>
              </div>
              <Gap h={16} />
              <div style={{ display: "grid", gap: 11 }}>
                <KV label="ردیفِ خوانده‌شده" value={<Num value={stage.res.read} />} />
                <KV label="کالای تازه" value={<Num value={stage.res.newProducts} />} />
                <KV label="کالای از قبل موجود" value={<Num value={stage.res.matched} />} />
                <KV label="پارتِ ساخته‌شده" value={<Num value={stage.res.batches} />} />
                <KV label="انبارِ تازه" value={<Num value={stage.res.newWarehouses} />} />
                <KV label="تأمین‌کنندهٔ تازه" value={<Num value={stage.res.newSuppliers} />} />
                <KV label="دستهٔ تازه" value={<Num value={stage.res.newCategories} />} />
                {stage.res.skipped > 0 && (
                  <KV label="ردیفِ ردشده" value={<Num value={stage.res.skipped} />} tint={v("warn")} />
                )}
              </div>
            </Card>
          </Pad>

          <Pad style={{ marginTop: 16 }}>
            <Button onPress={() => nav.goTab(1)}>دیدنِ کالاها</Button>
          </Pad>
          <Pad style={{ marginTop: 10 }}>
            <Button tone="ghost" onPress={() => setStage({ k: "idle" })}>فایلِ دیگر</Button>
          </Pad>
        </>
      )}
    </ScreenScroll>
  );
}

function Note({ icon, title, note }: { icon: any; title: string; note: string }) {
  return (
    <Reveal i={0} step={0}>
      <LightRow height={64}>
        <IconSquare icon={icon} size={32} radius={10} iconSize={14} />
        <div style={{ flex: 1, minWidth: 0, marginInlineStart: 12 }}>
          <div style={{ fontSize: 12.5, fontWeight: 700, color: v("ink") }}>{title}</div>
          <div style={{ marginTop: 2, fontSize: 10.5, color: v("inkFaint"), lineHeight: 1.7 }}>
            {note}
          </div>
        </div>
      </LightRow>
    </Reveal>
  );
}
