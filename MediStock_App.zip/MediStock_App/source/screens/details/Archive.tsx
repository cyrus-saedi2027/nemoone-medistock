/* ─────────────────────────────────────────────────────────────
 *  آرشیوِ ماهانهٔ تاریخچه
 *
 *  هر ماه که بسته می‌شود، حرکت‌های آن ماه در یک بسته می‌روند به گروهِ
 *  بله و از اپ برداشته می‌شوند. کالاها، پارت‌ها، موجودی و دفترِ
 *  تغییرات دست نمی‌خورند.
 *
 *  ── چرا دو فایل ──
 *  `.json` برای برگرداندن (ماشین می‌خواندش) و `.xlsx` برای خواندن
 *  (آدم می‌خواندش). بکاپی که فقط ماشین بتواند بازش کند، روزی که لازم
 *  شود کسی برای بازکردنش سراغِ ما می‌آید.
 * ───────────────────────────────────────────────────────────── */

import * as React from "react";
import { v } from "@/system/theme/ThemeProvider";
import { R, SHADOW } from "@/system/tokens";
import { useData, useUi, useActions } from "@/store/StoreProvider";
import { ScreenScroll } from "@/ui/chrome/ScreenScroll";
import { Header } from "@/ui/chrome/Header";
import {
  Gap, Pad, Card, Button, SectionLabel, Empty, StatBlock, LightRow, IconSquare,
} from "@/ui/kit";
import { Num } from "@/ui/text/Text";
import { Reveal } from "@/ui/primitives/Motion";
import { IconCloud, IconDownload, IconSend, IconCheck, IconInfo } from "@/ui/icons";
import { useScreenTheme } from "@/screens/useScreenTheme";
import { Sheet } from "@/ui/overlays/Sheet";
import { can } from "@/domain/derive";
import {
  archivableMonths, movementsOf, buildBundle, bundleCaption, monthLabel,
  type MonthBucket,
} from "@/domain/archive";
import { sheetMovements } from "@/domain/report";
import { shipArchive, HAS_API, type ShipResult } from "@/system/archiveShip";
import { KV } from "@/screens/details/Product";

type Busy = { key: string; step: string } | null;

export function ArchiveScreen({ onBack }: { onBack: () => void }) {
  const d = useData();
  const { session } = useUi();
  const { closeMonth, toast } = useActions();
  const t = useScreenTheme("archive");
  const [busy, setBusy] = React.useState<Busy>(null);
  const [ask, setAsk] = React.useState<MonthBucket | null>(null);
  const [note, setNote] = React.useState("");
  const tried = React.useRef(false);

  const may = session ? can(session.role, "settings") : false;

  const months = React.useMemo(
    () => archivableMonths(d.movements, d.archived),
    [d.movements, d.archived]
  );

  /** بسته را می‌سازد. هنوز چیزی حذف نمی‌شود. */
  const pack = React.useCallback(async (m: MonthBucket) => {
    const byBatch = new Map(d.batches.map((b) => [b.id, b]));
    const byProd = new Map(d.catalog.map((c) => [c.i, c]));
    const mine = movementsOf(d.movements, m.key);

    const bundle = buildBundle({
      key: m.key,
      movements: mine,
      users: d.users,
      productOf: (bid) => {
        const b = byBatch.get(bid);
        const p = b ? byProd.get(b.productId) : undefined;
        return p ? { id: p.i, name: p.n } : null;
      },
      lotOf: (bid) => byBatch.get(bid)?.lotCode ?? "",
      warehouses: d.warehouses,
      by: session?.fullName ?? session?.username ?? null,
    });

    const { buildXlsx } = await import("@/system/xlsx");
    const sheet = sheetMovements({
      catalog: d.catalog, batches: d.batches, movements: mine,
      warehouses: d.warehouses, suppliers: d.suppliers, users: d.users, cats: d.cats,
    });
    sheet.title = `آرشیوِ تاریخچه — ${m.label}   —   MediStock`;
    const xlsx = await buildXlsx([sheet]);

    return {
      json: new Blob([JSON.stringify(bundle)], { type: "application/json" }),
      xlsx,
      base: `medistock-archive-${m.key}`,
    };
  }, [d, session]);

  /**
   * تلاش برای فرستادن. اگر نرفت، *هیچ چیزی حذف نمی‌شود* — تنها راهِ
   * از‌دست‌دادنِ همیشگیِ داده همین است که قبل از تأییدِ خروج پاک کنیم.
   */
  const shipOne = React.useCallback(async (m: MonthBucket): Promise<ShipResult> => {
    setBusy({ key: m.key, step: "در حالِ بستنِ فایل…" });
    try {
      const { json, xlsx, base } = await pack(m);
      setBusy({ key: m.key, step: "در حالِ فرستادن…" });
      const cap = bundleCaption(m);
      const a = await shipArchive(json, `${base}.json`, cap);
      if (a !== "sent") return a;
      await shipArchive(xlsx, `${base}.xlsx`, `📄 نسخهٔ خواندنیِ ${m.label}`);
      closeMonth(m.key, "بله");
      return "sent";
    } catch {
      return "failed";
    } finally {
      setBusy(null);
    }
  }, [pack, closeMonth]);

  /** راهِ دستی: فایل‌ها دانلود می‌شوند، بعد مدیر تأیید می‌کند */
  const downloadOne = React.useCallback(async (m: MonthBucket) => {
    setBusy({ key: m.key, step: "در حالِ ساختِ فایل…" });
    try {
      const { json, xlsx, base } = await pack(m);
      const { download } = await import("@/system/xlsx");
      download(json, `${base}.json`);
      download(xlsx, `${base}.xlsx`);
      setAsk(m);
    } catch {
      toast("ساختِ فایل نشد", { tone: "crit" });
    } finally {
      setBusy(null);
    }
  }, [pack, toast]);

  /* ── تلاشِ خودکار ──────────────────────────────────────
   *
   * یک بار در هر بازکردنِ صفحه، برای قدیمی‌ترین ماهِ باز. اگر سرور
   * نبود، بی‌سروصدا کنار می‌کشد و راهِ دستی سرِ جایش می‌ماند —
   * پیامِ خطای هر بار برای کاری که کاربر نخواسته، آزار است.
   * ──────────────────────────────────────────────────── */
  React.useEffect(() => {
    if (!may || tried.current || !d.ready || !months.length) return;
    tried.current = true;
    if (!HAS_API) {
      /* ساختنِ فایلی که جایی نمی‌رود، فقط گوشی را گرم می‌کند */
      setNote("ارسالِ خودکار وقتی سرور بالا بیاید انجام می‌شود. تا آن موقع دستی بفرست.");
      return;
    }
    (async () => {
      const r = await shipOne(months[0]);
      if (r === "sent") {
        setNote("");
        toast(`آرشیوِ ${months[0].label} به بله رفت`, { tone: "ok" });
      } else {
        setNote(r === "failed"
          ? "سرور جواب داد ولی ارسال نشد. فعلاً دستی بفرست."
          : "ارسالِ خودکار وقتی سرور بالا بیاید انجام می‌شود. تا آن موقع دستی بفرست.");
      }
    })();
  }, [may, d.ready, months, shipOne, toast]);

  if (!may) {
    return (
      <ScreenScroll>
        <Header theme={t} title="آرشیوِ ماهانه" onBack={onBack} />
        <Empty icon={IconCloud} title="دسترسی نداری"
               note="فقط مدیر می‌تواند تاریخچه را آرشیو کند." />
      </ScreenScroll>
    );
  }

  const totalOpen = months.reduce((n, m) => n + m.count, 0);

  return (
    <>
      <ScreenScroll>
        <Header theme={t} sub="بستنِ تاریخچهٔ ماه‌های گذشته" title="آرشیوِ ماهانه"
                onBack={onBack} />

        <Pad style={{ marginTop: 14 }}>
          <div style={{ display: "flex", gap: 8 }}>
            <StatBlock tone="dark" label="ماهِ باز" value={<Num value={months.length} />} />
            <StatBlock tone="dark" label="ثبتِ آرشیو‌نشده" value={<Num value={totalOpen} />} />
            <StatBlock tone="dark" label="بسته‌شده" value={<Num value={d.archived.length} />} />
          </div>
        </Pad>

        <Gap h={24} />

        <Pad>
          <Card>
            <div style={{ display: "flex", alignItems: "center", gap: 12 }}>
              <IconSquare icon={IconCloud} size={44} radius={14} iconSize={20} tone="accent" />
              <div style={{ flex: 1, minWidth: 0 }}>
                <div style={{ fontSize: 14, fontWeight: 800, color: v("ink") }}>
                  چه چیزی آرشیو می‌شود
                </div>
                <div style={{ marginTop: 3, fontSize: 11, color: v("inkFaint"), lineHeight: 1.8 }}>
                  فقط تاریخچهٔ ورود و خروج و انتقال
                </div>
              </div>
            </div>
            <Gap h={14} />
            <div style={{ display: "grid", gap: 11 }}>
              <KV label="کالاها و موجودی" value="دست‌نخورده" tint={v("ok")} />
              <KV label="پارت‌ها و انبارها" value="دست‌نخورده" tint={v("ok")} />
              <KV label="دفترِ تغییرات" value="دست‌نخورده" tint={v("ok")} />
              <KV label="تاریخچهٔ ماهِ جاری" value="دست‌نخورده" tint={v("ok")} />
              <KV label="تاریخچهٔ ماه‌های بسته" value="به بله می‌رود" tint={v("warn")} />
            </div>
          </Card>
        </Pad>

        {note && (
          <Pad style={{ marginTop: 12 }}>
            <div style={{ display: "flex", gap: 9, padding: "12px 14px", borderRadius: R.row,
                          background: v("warnWash"), fontSize: 11, fontWeight: 700,
                          color: v("warn"), lineHeight: 1.9 }}>
              <IconInfo size={15} />
              <span style={{ flex: 1 }}>{note}</span>
            </div>
          </Pad>
        )}

        <Gap h={22} />

        <Pad>
          <SectionLabel count={months.length}>ماه‌های آمادهٔ بستن</SectionLabel>
          <Gap h={10} />
          {months.length === 0 ? (
            <Card pad={0}>
              <Empty icon={IconCheck} title="چیزی برای آرشیو نیست"
                     note="ماهِ جاری هیچ‌وقت آرشیو نمی‌شود؛ هر ماه که تمام شود، خودش اینجا می‌آید." />
            </Card>
          ) : (
            <div style={{ display: "grid", gap: 10 }}>
              {months.map((m, i) => (
                <Reveal key={m.key} i={Math.min(i, 8)} step={32}>
                  <Card pad={14}>
                    <div style={{ display: "flex", alignItems: "baseline", gap: 8 }}>
                      <span style={{ flex: 1, fontSize: 14, fontWeight: 800, color: v("ink") }}>
                        {m.label}
                      </span>
                      <span style={{ fontSize: 11, fontWeight: 700, color: v("inkFaint") }}>
                        <Num value={m.count} /> ثبت
                      </span>
                    </div>
                    <div style={{ marginTop: 6, fontSize: 10.5, color: v("inkFaint") }}>
                      واردشده <b style={{ color: v("ok") }}><Num value={m.inQty} /></b>
                      {" · "}
                      خارج‌شده <b style={{ color: v("crit") }}><Num value={m.outQty} /></b>
                    </div>

                    {busy?.key === m.key ? (
                      <div style={{ marginTop: 12, fontSize: 11.5, fontWeight: 700,
                                    color: v("accentStrong"), textAlign: "center" }}>
                        {busy.step}
                      </div>
                    ) : (
                      <>
                        <Gap h={12} />
                        <Button icon={IconSend} onPress={async () => {
                          const r = await shipOne(m);
                          if (r === "sent") toast(`آرشیوِ ${m.label} به بله رفت`, { tone: "ok" });
                          else toast("سرور در دسترس نیست — دستی بفرست", { tone: "warn" });
                        }}>فرستادن به بله</Button>
                        <Gap h={8} />
                        <Button tone="ghost" icon={IconDownload}
                                onPress={() => downloadOne(m)}>
                          گرفتنِ فایل و فرستادنِ دستی
                        </Button>
                      </>
                    )}
                  </Card>
                </Reveal>
              ))}
            </div>
          )}
        </Pad>

        {d.archived.length > 0 && (
          <>
            <Gap h={22} />
            <Pad>
              <SectionLabel count={d.archived.length}>ماه‌های بسته‌شده</SectionLabel>
              <Gap h={10} />
              <div style={{ display: "grid", gap: 8 }}>
                {[...d.archived].sort().reverse().map((k) => (
                  <LightRow key={k} height={52}>
                    <IconSquare icon={IconCheck} size={30} radius={10} iconSize={13}
                                color={v("ok")} />
                    <div style={{ flex: 1, minWidth: 0, marginInlineStart: 11, fontSize: 12.5,
                                  fontWeight: 700, color: v("ink") }}>{monthLabel(k)}</div>
                    <span style={{ fontSize: 10, fontWeight: 700, color: v("inkFaint") }}>
                      در گروهِ بله
                    </span>
                  </LightRow>
                ))}
              </div>
            </Pad>
          </>
        )}

        <Pad style={{ marginTop: 16 }}>
          <div style={{ padding: "13px 15px", borderRadius: R.row, background: v("surfaceAlt"),
                        fontSize: 11, color: v("inkMuted"), lineHeight: 2 }}>
            تا وقتی فایل بیرون نرفته، هیچ ثبتی از اپ برداشته نمی‌شود.
            گزارش‌های «کلِ ثبت» فقط ماه‌های بسته‌نشده را می‌شمارند.
          </div>
        </Pad>
      </ScreenScroll>

      {/* بعد از دانلود: تا مدیر نگوید «گرفتمش»، چیزی پاک نمی‌شود */}
      <Sheet open={ask != null} onClose={() => setAsk(null)} title="فایل را گرفتی؟"
        footer={
          <div style={{ display: "grid", gap: 8 }}>
            <Button icon={IconCheck} onPress={() => {
              if (!ask) return;
              const n = closeMonth(ask.key, "دانلود");
              toast(`${ask.label} بسته شد — ${n} ثبت`, { tone: "ok" });
              setAsk(null);
            }}>بله، گرفتم — ببند</Button>
            <Button tone="ghost" onPress={() => setAsk(null)}>هنوز نه</Button>
          </div>
        }>
        <div style={{ paddingBlock: 10, fontSize: 12, lineHeight: 2, color: v("inkMuted") }}>
          دو فایلِ «{ask?.label}» دانلود شد. آن‌ها را در گروهِ بله بگذار،
          بعد اینجا تأیید کن تا تاریخچهٔ آن ماه از اپ برداشته شود.
          <br />
          <b style={{ color: v("ink") }}>تا تأیید نکنی هیچ‌چیز پاک نمی‌شود.</b>
        </div>
      </Sheet>
    </>
  );
}
