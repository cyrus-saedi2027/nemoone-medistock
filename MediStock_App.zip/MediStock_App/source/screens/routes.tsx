/* ثبتِ صفحه‌ها — تنها فایلی که همهٔ صفحه‌ها را می‌شناسد */

import * as React from "react";
import type { ScreenKey } from "@/screens/screenThemes";
import { ProductScreen, BatchScreen } from "@/screens/details/Product";
import { MoveScreen } from "@/screens/details/Move";
import { ReceiptScreen } from "@/screens/details/Receipt";
import { HistoryScreen, WarehouseOneScreen, ReportsScreen } from "@/screens/details/History";
import { ProductEditScreen, StocktakeScreen, ExcelScreen } from "@/screens/details/Tools";
import { BulkScreen } from "@/screens/details/Bulk";
import {
  BackupScreen, SuppliersScreen, CategoriesScreen, CompanyScreen, NotificationsScreen,
  UsersScreen, UserOneScreen, UserNewScreen, SettingsScreen, OutReasonsScreen,
} from "@/screens/details/Admin";
import { ImportScreen } from "@/screens/details/Import";
import { LabelsScreen } from "@/screens/details/Labels";
import { AuditScreen } from "@/screens/details/Audit";
import { ArchiveScreen } from "@/screens/details/Archive";

export type ScreenProps = { params: any; onBack: () => void };

export const SCREENS: Partial<Record<ScreenKey, React.ComponentType<ScreenProps>>> = {
  product:       ({ params, onBack }) => <ProductScreen params={params} onBack={onBack} />,
  batch:         ({ params, onBack }) => <BatchScreen params={params} onBack={onBack} />,
  moveIn:        ({ params, onBack }) => <MoveScreen type="IN" params={params ?? {}} onBack={onBack} />,
  moveOut:       ({ params, onBack }) => <MoveScreen type="OUT" params={params ?? {}} onBack={onBack} />,
  transfer:      ({ params, onBack }) => <MoveScreen type="TRANSFER" params={params ?? {}} onBack={onBack} />,
  receipt:       ({ params, onBack }) => <ReceiptScreen params={params} onBack={onBack} />,
  history:       ({ params, onBack }) => <HistoryScreen params={params} onBack={onBack} />,
  warehouseOne:  ({ params, onBack }) => <WarehouseOneScreen params={params} onBack={onBack} />,
  reports:       ({ onBack }) => <ReportsScreen onBack={onBack} />,
  productEdit:   ({ params, onBack }) => <ProductEditScreen params={params} onBack={onBack} />,
  stocktake:     ({ onBack }) => <StocktakeScreen onBack={onBack} />,
  excel:         ({ onBack }) => <ExcelScreen onBack={onBack} />,
  importData:    ({ onBack }) => <ImportScreen onBack={onBack} />,
  labels:        ({ onBack }) => <LabelsScreen onBack={onBack} />,
  bulk:          ({ onBack }) => <BulkScreen onBack={onBack} />,
  backup:        ({ onBack }) => <BackupScreen onBack={onBack} />,
  suppliers:     ({ onBack }) => <SuppliersScreen onBack={onBack} />,
  categories:    ({ onBack }) => <CategoriesScreen onBack={onBack} />,
  outReasons:    ({ onBack }) => <OutReasonsScreen onBack={onBack} />,
  company:       ({ onBack }) => <CompanyScreen onBack={onBack} />,
  notifications: ({ onBack }) => <NotificationsScreen onBack={onBack} />,
  users:         ({ onBack }) => <UsersScreen onBack={onBack} />,
  userOne:       ({ params, onBack }) => <UserOneScreen params={params} onBack={onBack} />,
  userNew:       ({ onBack }) => <UserNewScreen onBack={onBack} />,
  settings:      ({ onBack }) => <SettingsScreen onBack={onBack} />,
  audit:         ({ onBack }) => <AuditScreen onBack={onBack} />,
  archive:       ({ onBack }) => <ArchiveScreen onBack={onBack} />,
};
