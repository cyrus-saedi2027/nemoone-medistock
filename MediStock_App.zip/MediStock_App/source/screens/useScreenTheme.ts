import * as React from "react";
import { useTheme } from "@/system/theme/ThemeProvider";
import { ST, effectiveTheme, type ScreenKey } from "@/screens/screenThemes";

/**
 * تمِ صفحه، بعد از اعمالِ سبکِ پس‌زمینه.
 *
 * صفحه‌ها به‌جای `ST.x` این را صدا می‌زنند، وگرنه در سبکِ «ساده»
 * سرصفحه با جوهرِ روشن روی سطحِ روشن می‌افتد و ناخوانا می‌شود.
 */
export function useScreenTheme(key: ScreenKey) {
  const { bg } = useTheme();
  return React.useMemo(() => effectiveTheme(ST[key], bg), [key, bg]);
}
