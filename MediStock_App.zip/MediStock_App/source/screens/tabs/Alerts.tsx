/* هشدارها — سه دستهٔ واقعی: منقضی‌شده، نزدیکِ انقضا، ناموجود */

import * as React from "react";
import { v } from "@/system/theme/ThemeProvider";
import { R, SHADOW } from "@/system/tokens";
import { useData, useUi } from "@/store/StoreProvider";
import { ScreenScroll } from "@/ui/chrome/ScreenScroll";
import { Header } from "@/ui/chrome/Header";
import { Gap, Pad, SectionLabel, StatBlock, Empty, Segmented, Card } from "@/ui/kit";
import { Pressable } from "@/ui/primitives/Pressable";
import { Num, Lat } from "@/ui/text/Text";
import { Reveal } from "@/ui/primitives/Motion";
import { IconWarn, IconCheck, IconCloud } from "@/ui/icons";
import { useScreenTheme } from "@/screens/useScreenTheme";
import { useNav } from "@/router/Router";
import {
  monthsUntil, can, expiryKind, type ExpiryKind,
} from "@/domain/derive";
import { archivableMonths } from "@/domain/archive";
import { expiryLabel } from "@/system/i18n/jalali";
import { toFa } from "@/system/i18n/digits";
import { Skeleton } from "@/screens/tabs/Home";

type Kind = 0 | 1 | 2 | 3;
const TABS = ["منقضی", "نزدیک", "ناموجود", "زیرِ حداقل"];

/* ردیفِ تیره — این صفحه ورقهٔ پایینش سیاه است (مثل Payments نمونه) */
function AlertRow({
  rail, title, meta, right, onPress,
}: {
  rail: string; title: React.ReactNode; meta: React.ReactNode;
  right: React.ReactNode; onPress: () => void;
}) {
  return (
    <Pressable onPress={onPress} scale={0.985}
      style={{
        display: "flex", alignItems: "center", width: "100%", minHeight: 66,
        paddingInline: 14, overflow: "hidden",
        borderRadius: R.row, background: v("card"), boxShadow: SHADOW.soft,
      }}>
      <i style={{ width: 3, height: 32, borderRadius: 99, flex: "none", background: rail }} />
      <div style={{ flex: 1, minWidth: 0, marginInlineStart: 12 }}>
        <div style={{ fontSize: 13, fontWeight: 700, color: v("deepInk"),
                      whiteSpace: "nowrap", overflow: "hidden",
                      textOverflow: "ellipsis" }}>{title}</div>
        <div style={{ marginTop: 2, fontSize: 10.5, color: v("deepInkMuted") }}>{meta}</div>
      </div>
      {right}
    </Pressable>
  );
}

export function AlertsScreen() {
  const { catalog, batches, movements, pending, archived, ready } = useData();
  const { session } = useUi();
  const nav = useNav();
  const t = useScreenTheme("alerts");
  const [kind, setKind] = React.useState<Kind>(1);

  /* صفحهٔ «نیازِ رسیدگی» جای درستِ چیزی است که کارِ یک نفرِ دیگر را
     متوقف کرده. بدونِ این، انباردار می‌شمارد و منتظر می‌ماند و مدیر
     هیچ‌وقت خبردار نمی‌شود. */
  const waiting = session && can(session.role, "users") ? pending.length : 0;

  /* یادآورِ آرشیو. هیچ درخواستی به شبکه نمی‌زند — فقط تاریخِ خودِ
     حرکت‌ها را نگاه می‌کند. بدونِ این، «هر ماه یک بار» یعنی «هر وقت
     مدیر یادش افتاد». */
  const dueMonths = React.useMemo(
    () => (session && can(session.role, "settings"))
      ? archivableMonths(movements, archived) : [],
    [session, movements, archived]
  );

  /* ── سه دستهٔ متفاوت، یک تب ────────────────────────────────
   *
   * تبِ «منقضی» علاوه بر پارت‌های گذشته، پارت‌هایی را هم نشان می‌دهد
   * که *تاریخ ندارند*. خواستهٔ صریحِ محمد بود، و منطقش هم درست است:
   * هر سه دسته یک چیزِ مشترک دارند — از روی تاریخ نمی‌شود گفت این
   * پارت سالم است.
   *
   * ولی سه چیزِ متفاوت‌اند و نباید یکی نشان داده شوند:
   *   `expired` — تاریخش گذشته. باید برود.
   *   `unknown` — تاریخ هنوز وارد نشده. کارِ ناتمام است.
   *   `none`    — عمداً تاریخ ندارد (باند، ست سرم، ژیلت). سالم است.
   *
   * پس هر ردیف نشانِ خودش را دارد و فهرست هم بخش‌بندی می‌شود. عددِ
   * قرمزِ بالای صفحه فقط `expired` را می‌شمارد — وگرنه «۵۱ قلمِ
   * منقضی» به کسی می‌گوید فاجعه‌ای رخ داده که رخ نداده. */
  const groups = React.useMemo(() => {
    const byId = new Map(catalog.map((c) => [c.i, c]));
    const now = new Date();
    type Row = { b: any; p: any; m: number; kind: ExpiryKind };
    const expired: Row[] = [];
    const noDate: Row[] = [];
    const near: Row[] = [];
    for (const b of batches) {
      if (b.qty <= 0) continue;
      const p = byId.get(b.productId);
      if (!p) continue;
      const k = expiryKind(b);
      if (k !== "dated") {
        /* «نامشخص» بالاتر از «بدون انقضا» می‌نشیند: یکی کارِ ناتمام
           است و دیگری یک وضعیتِ تمام‌شده. */
        noDate.push({ b, p, m: 0, kind: k });
        continue;
      }
      const m = monthsUntil(b.expiry, now);
      if (m == null) continue;
      if (m < 0) expired.push({ b, p, m, kind: "dated" });
      else if (m < 6) near.push({ b, p, m, kind: "dated" });
    }
    expired.sort((a, z) => a.m - z.m);
    near.sort((a, z) => a.m - z.m);
    noDate.sort((a, z) =>
      a.kind === z.kind ? 0 : a.kind === "unknown" ? -1 : 1);

    const zero = catalog.filter((c) => c.q === 0);
    /* «زیرِ حداقل» فقط برای کالاهایی که مدیر برایشان حداقل گذاشته.
       موجودیِ صفر جای خودش را دارد، پس اینجا تکرارش نمی‌کنیم. */
    const low = catalog.filter((c) => c.m != null && c.q > 0 && c.q <= c.m);
    /* بدونِ `slice`. قبلاً هر دسته روی ۱۵۰ بریده می‌شد در حالی که
       کاشیِ بالای صفحه عددِ کامل را می‌گفت — «ناموجود ۴٬۳۸۲» و زیرش
       ۱۵۰ ردیف. همان بیماریِ سقفِ ۴۰۰ در جست‌وجو. حالا فهرست با
       دکمهٔ «نمایشِ بیشتر» جلو می‌رود و عدد همیشه راست می‌گوید. */
    return { expired, near, noDate, zero, low,
             nExpired: expired.length, nNear: near.length,
             nNoDate: noDate.length,
             nUnknown: noDate.filter((x) => x.kind === "unknown").length,
             nZero: zero.length, nLow: low.length };
  }, [catalog, batches]);

  const list = kind === 0 ? [...groups.expired, ...groups.noDate]
             : kind === 1 ? groups.near : [];

  /* رندرِ چند هزار ردیف روی گوشیِ متوسط حس می‌شود، پس صفحه‌ای —
     ولی *همه* در دسترس‌اند، نه ۱۵۰ تای اول. */
  const PAGE = 60;
  const [shown, setShown] = React.useState(PAGE);
  React.useEffect(() => { setShown(PAGE); }, [kind]);
  const products = kind === 2 ? groups.zero : kind === 3 ? groups.low : [];

  return (
    <ScreenScroll>
      <Header theme={t} sub="نیازِ رسیدگی" title="هشدارها" />

      {/* بالای منحنی سفید است، پس آمار کارتِ سفید با سایه می‌شود —
          همان TabbedCard نمونه در صفحهٔ Payments. */}
      <Pad style={{ marginTop: 14 }}>
        <div style={{ display: "flex", gap: 8 }}>
          <StatBlock label="منقضی" value={<Num value={groups.nExpired} />}
                     tint={v("crit")} onPress={() => setKind(0)} />
          <StatBlock label="زیر ۶ ماه" value={<Num value={groups.nNear} />}
                     onPress={() => setKind(1)} />
          <StatBlock label="ناموجود" value={<Num value={groups.nZero} />}
                     onPress={() => setKind(2)} />
          <StatBlock label="زیرِ حداقل" value={<Num value={groups.nLow} />}
                     tint={groups.nLow ? v("warn") : undefined} onPress={() => setKind(3)} />
        </div>
      </Pad>

      {waiting > 0 && (
        <Pad style={{ marginTop: 12 }}>
          <Pressable onPress={() => nav.push("stocktake")} scale={0.985}
            style={{ display: "flex", alignItems: "center", width: "100%", minHeight: 62,
                     paddingInline: 14, borderRadius: R.row, background: v("warnWash"),
                     textAlign: "start" }}>
            <IconWarn size={17} color={v("warn")} />
            <div style={{ flex: 1, minWidth: 0, marginInlineStart: 11 }}>
              <div style={{ fontSize: 12.5, fontWeight: 800, color: v("warn") }}>
                <Num value={waiting} /> اختلافِ انبارگردانی منتظرِ تأییدِ توست
              </div>
              <div style={{ marginTop: 2, fontSize: 10.5, color: v("warn"), opacity: 0.85 }}>
                تا تأیید نکنی، موجودی عوض نمی‌شود
              </div>
            </div>
          </Pressable>
        </Pad>
      )}

      {dueMonths.length > 0 && (
        <Pad style={{ marginTop: 12 }}>
          <Pressable onPress={() => nav.push("archive")} scale={0.985}
            style={{ display: "flex", alignItems: "center", width: "100%", minHeight: 62,
                     paddingInline: 14, borderRadius: R.row, background: v("surfaceAlt"),
                     textAlign: "start" }}>
            <IconCloud size={17} color={v("inkMuted")} />
            <div style={{ flex: 1, minWidth: 0, marginInlineStart: 11 }}>
              <div style={{ fontSize: 12.5, fontWeight: 800, color: v("ink") }}>
                تاریخچهٔ {dueMonths[0].label} آمادهٔ آرشیو است
              </div>
              <div style={{ marginTop: 2, fontSize: 10.5, color: v("inkFaint") }}>
                {dueMonths.length > 1
                  ? <><Num value={dueMonths.length} /> ماه منتظر است · موجودی دست نمی‌خورد</>
                  : "فقط تاریخچه بسته می‌شود؛ موجودی و کالاها دست نمی‌خورند"}
              </div>
            </div>
          </Pressable>
        </Pad>
      )}

      <Gap h={24} />

      <Pad>
        <Segmented items={TABS} index={kind} onChange={(i) => setKind(i as Kind)} />
      </Pad>

      <Gap h={14} />

      <Pad>
        {!ready ? (
          <Skeleton rows={6} />
        ) : kind >= 2 ? (
          products.length === 0 ? (
            <Empty icon={IconCheck}
                   title={kind === 2 ? "همه‌چیز موجود است" : "چیزی زیرِ حداقل نیست"}
                   note={kind === 3 && groups.nLow === 0 && !catalog.some((c) => c.m != null)
                         ? "هنوز برای هیچ کالایی «حداقل موجودی» تعیین نشده. در صفحهٔ ویرایشِ کالا می‌شود گذاشت."
                         : undefined} />
          ) : (
            <div style={{ display: "grid", gap: 8 }}>
              {products.slice(0, shown).map((p, i) => (
                <Reveal key={p.i} i={Math.min(i, 8)} step={34}>
                  <AlertRow onPress={() => nav.push("product", { id: p.i })}
                            rail={kind === 2 ? v("deepInkMuted") : v("warn")} title={p.n}
                            meta={kind === 2
                              ? `موجودی صفر · ${p.c || "بدون دسته"}`
                              : <><Num value={p.q} /> عدد · حداقل <Num value={p.m ?? 0} /></>}
                            right={
                              /* برچسبِ «سفارش» قبلاً `accentSurface` روی
                                 `cardDarkAlt` بود — یعنی کهربای روشن روی
                                 خاکستریِ خیلی روشن، که در عمل ناپیدا بود.
                                 حالا جفتِ تضمین‌شده است: جوهرِ سطحِ تأکید
                                 روی خودِ سطحِ تأکید. */
                              <div style={{ fontSize: 11, fontWeight: 800,
                                            color: v("accentSurfaceInk"),
                                            padding: "4px 9px", borderRadius: 999,
                                            border: `1px solid ${v("hair")}`,
                                            background: v("accentSurface"), flex: "none" }}>سفارش</div>
                            } />
                </Reveal>
              ))}
            {products.length > shown && (
              <Pressable onPress={() => setShown((n) => n + PAGE)}
                ariaLabel="نمایشِ بیشتر"
                style={{
                  height: 46, borderRadius: R.row, display: "grid", placeItems: "center",
                  background: v("card"), boxShadow: SHADOW.soft, marginTop: 2,
                }}>
                <span style={{ fontSize: 12, fontWeight: 800, color: v("ink") }}>
                  نمایشِ <Num value={Math.min(PAGE, products.length - shown)} /> تای بعدی
                  {" · "}
                  <span style={{ color: v("inkFaint"), fontWeight: 700 }}>
                    <Num value={products.length - shown} /> مانده
                  </span>
                </span>
              </Pressable>
            )}
            </div>
          )
        ) : list.length === 0 ? (
          <Empty icon={IconCheck} title={kind === 0 ? "هیچ پارتِ منقضی نیست" : "چیزی زیر ۶ ماه نیست"} />
        ) : (
          <div style={{ display: "grid", gap: 8 }}>
            {list.slice(0, shown).map(({ b, p, m, kind: ek }, i) => {
              /* رنگ و نشان از روی *نوع* می‌آید، نه فقط از عدد:
                   گذشته      → قرمز
                   نامشخص     → نارنجی (کارِ ناتمام)
                   بدون انقضا → خاکستری (سالم، فقط تاریخ ندارد) */
              const tone = ek === "none" ? "deepInkMuted"
                         : ek === "unknown" ? "warn"
                         : m < 0 || m < 3 ? "crit" : "warn";
              const badge = ek === "none" ? "بدون انقضا"
                          : ek === "unknown" ? "نامشخص"
                          : null;
              /* اولین ردیفِ هر دسته یک عنوانِ کوچک می‌گیرد. بدونِ آن،
                 ۵۱ ردیفِ پشتِ سرِ هم با سه معنیِ متفاوت یک تودهٔ گنگ
                 است و کسی نمی‌فهمد کدام واقعاً مشکل دارد. */
              const prev = i > 0 ? list[i - 1].kind : null;
              const head = ek !== prev
                ? (ek === "dated" ? `منقضی — ${toFa(groups.nExpired)} پارت`
                 : ek === "unknown" ? `انقضا هنوز وارد نشده — ${toFa(groups.nUnknown)} پارت`
                 : `بدون تاریخِ انقضا — ${toFa(groups.nNoDate - groups.nUnknown)} پارت`)
                : null;
              return (
                <React.Fragment key={b.id}>
                  {head && (
                    <div style={{ marginTop: i ? 10 : 0, marginBottom: 2,
                                  fontSize: 10.5, fontWeight: 800,
                                  color: v("deepInkMuted") }}>
                      {head}
                    </div>
                  )}
                  <Reveal i={Math.min(i, 8)} step={34}>
                    <AlertRow onPress={() => nav.push("product", { id: p.i })}
                      rail={v(tone)} title={p.n}
                      /* برای ردیف‌های بی‌تاریخ، متن دوباره تکرار
                         نمی‌شود: نشانِ سمتِ راست همان را می‌گوید. */
                      meta={ek === "dated"
                        ? <>{expiryLabel(b.expiry)} · <Lat style={{ fontSize: 10.5, color: v("deepInkMuted") }}>{b.lotCode}</Lat></>
                        : <Lat style={{ fontSize: 10.5, color: v("deepInkMuted") }}>{b.lotCode}</Lat>}
                      right={
                        <div style={{ textAlign: "end", flex: "none" }}>
                          <div style={{
                            fontSize: 10.5, fontWeight: 800, color: v(tone),
                            background: v("cardDarkAlt"),
                            padding: "3px 8px", borderRadius: 999,
                          }}>
                            {badge ?? (m < 0 ? <>گذشته</> : <><Num value={m} /> ماه</>)}
                          </div>
                          <div style={{ marginTop: 3, fontSize: 10.5, fontWeight: 700,
                                        color: v("deepInkMuted") }}>
                            <Num value={b.qty} /> عدد
                          </div>
                        </div>
                      } />
                  </Reveal>
                </React.Fragment>
              );
            })}
            {list.length > shown && (
              <Pressable onPress={() => setShown((n) => n + PAGE)}
                ariaLabel="نمایشِ بیشتر"
                style={{
                  height: 46, borderRadius: R.row, display: "grid", placeItems: "center",
                  background: v("card"), boxShadow: SHADOW.soft, marginTop: 2,
                }}>
                <span style={{ fontSize: 12, fontWeight: 800, color: v("ink") }}>
                  نمایشِ <Num value={Math.min(PAGE, list.length - shown)} /> تای بعدی
                  {" · "}
                  <span style={{ color: v("inkFaint"), fontWeight: 700 }}>
                    <Num value={list.length - shown} /> مانده
                  </span>
                </span>
              </Pressable>
            )}
          </div>
        )}
      </Pad>
    </ScreenScroll>
  );
}
