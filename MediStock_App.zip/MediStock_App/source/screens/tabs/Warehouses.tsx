/* انبارها — درختِ دو سطحی: انبارِ اصلی و فایل‌هایش، بعد بقیه */

import * as React from "react";
import { v } from "@/system/theme/ThemeProvider";
import { R, SHADOW } from "@/system/tokens";
import { useData } from "@/store/StoreProvider";
import { ScreenScroll } from "@/ui/chrome/ScreenScroll";
import { Header } from "@/ui/chrome/Header";
import { Gap, IconSquare, LightRow, Pad, SectionLabel, StatBlock, Button, Empty } from "@/ui/kit";
import { Num } from "@/ui/text/Text";
import { Reveal } from "@/ui/primitives/Motion";
import { IconBox, IconShelf, IconForward, IconPlus, IconTruck, IconEdit, IconTrash } from "@/ui/icons";
import { useScreenTheme } from "@/screens/useScreenTheme";
import { useNav } from "@/router/Router";
import { Sheet } from "@/ui/overlays/Sheet";
import { Field } from "@/ui/kit";
import { useActions } from "@/store/StoreProvider";
import { useUi } from "@/store/StoreProvider";
import { can } from "@/domain/derive";
import { Pressable } from "@/ui/primitives/Pressable";
import type { Warehouse } from "@/domain/types";

export function WarehousesScreen() {
  const { warehouses, batches } = useData();
  const { session } = useUi();
  const { addWarehouse, renameWarehouse, removeWarehouse, toast } = useActions();
  const nav = useNav();
  const t = useScreenTheme("warehouse");
  /* `adding` هم «انبارِ مستقل» است هم «زیرمجموعهٔ فلان» — مقدارش
     شناسهٔ والد است، یا `null` برای مستقل. `false` یعنی بسته. */
  const [adding, setAdding] = React.useState<number | null | false>(false);
  const [editing, setEditing] = React.useState<Warehouse | null>(null);
  const [eName, setEName] = React.useState("");
  const [eErr, setEErr] = React.useState("");
  const [name, setName] = React.useState("");
  const parentOf = adding == null ? null : warehouses.find((w) => w.id === adding);

  const stats = React.useMemo(() => {
    const items = new Map<number, number>();
    const units = new Map<number, number>();
    for (const b of batches) {
      if (b.qty <= 0) continue;
      items.set(b.warehouseId, (items.get(b.warehouseId) ?? 0) + 1);
      units.set(b.warehouseId, (units.get(b.warehouseId) ?? 0) + b.qty);
    }
    return { items, units };
  }, [batches]);

  const roots = warehouses.filter((w) => w.parentId == null);
  const kidsOf = (id: number) => warehouses.filter((w) => w.parentId === id);
  const totalUnits = React.useMemo(
    () => batches.reduce((s, b) => s + Math.max(0, b.qty), 0), [batches]
  );

  const mayEdit = session ? can(session.role, "editProduct") : false;

  return (
    <>
      <ScreenScroll>
        <Header theme={t} sub="محل‌های نگهداری" title="انبارها" />

        <Pad style={{ marginTop: 14 }}>
          <div style={{ display: "flex", gap: 8 }}>
            <StatBlock tone="accent" label="محل‌ها" value={<Num value={warehouses.length} />} />
            <StatBlock tone="accent" label="کلِ عدد" value={<Num value={totalUnits} />} />
            <StatBlock tone="accent" label="فایل‌ها"
                       value={<Num value={warehouses.filter((w) => w.parentId != null).length} />} />
          </div>
        </Pad>

        <Gap h={24} />

        <Pad>
          {roots.map((root, ri) => {
            const kids = kidsOf(root.id);
            return (
              <Reveal key={root.id} i={ri} step={44} style={{ marginBottom: 18 }}>
                <LightRow onPress={() => nav.push("warehouseOne", { id: root.id })} height={68}>
                  <IconSquare icon={IconBox} size={38} radius={12} iconSize={17} tone="accent" />
                  <div style={{ flex: 1, minWidth: 0, marginInlineStart: 12 }}>
                    <div style={{ fontSize: 14, fontWeight: 800, color: v("ink") }}>{root.name}</div>
                    <div style={{ marginTop: 2, fontSize: 10.5, color: v("inkFaint") }}>
                      <Num value={stats.items.get(root.id) ?? 0} /> قلم
                      {kids.length > 0 && <> · <Num value={kids.length} /> فایل</>}
                    </div>
                  </div>
                  {mayEdit && (
                    <EditBtn onPress={() => { setEditing(root); setEName(root.name); setEErr(""); }}
                             label={root.name} />
                  )}
                  <IconForward size={16} stroke={2} color={v("inkFaint")} />
                </LightRow>

                {kids.length > 0 && (
                  <div style={{
                    marginTop: 8, marginInlineStart: 16,
                    borderInlineStart: `1.5px solid ${v("divider")}`,
                    paddingInlineStart: 12, display: "grid", gap: 7,
                  }}>
                    {kids.map((k) => (
                      <LightRow key={k.id} onPress={() => nav.push("warehouseOne", { id: k.id })} height={54}>
                        <IconSquare icon={IconShelf} size={30} radius={10} iconSize={13} />
                        <div style={{ flex: 1, minWidth: 0, marginInlineStart: 11 }}>
                          <div style={{ fontSize: 12.5, fontWeight: 700, color: v("ink") }}>{k.name}</div>
                        </div>
                        <div style={{ fontSize: 11.5, fontWeight: 700, color: v("inkMuted") }}>
                          <Num value={stats.items.get(k.id) ?? 0} />
                        </div>
                        {mayEdit && (
                          <EditBtn onPress={() => { setEditing(k); setEName(k.name); setEErr(""); }}
                                   label={k.name} />
                        )}
                        <IconForward size={14} stroke={2} color={v("inkFaint")}
                                     style={{ marginInlineStart: 8 }} />
                      </LightRow>
                    ))}
                  </div>
                )}

                {/* «فایل‌بندی حتماً قابلِ تغییر باشه» — خواستهٔ صریحِ
                    کارفرما. زیرمجموعه از دلِ همان انبار ساخته می‌شود، نه
                    از یک صفحهٔ جدا که کسی پیدایش نکند. */}
                {mayEdit && (
                  <div style={{ marginTop: 8, marginInlineStart: 16, paddingInlineStart: 12 }}>
                    <Pressable onPress={() => { setName(""); setAdding(root.id); }} scale={0.97}
                      style={{
                        display: "flex", alignItems: "center", gap: 8, width: "100%",
                        minHeight: 44, paddingInline: 12, borderRadius: R.row,
                        border: `1.5px dashed ${v("divider")}`, color: v("inkMuted"),
                        fontSize: 11.5, fontWeight: 700,
                      }}>
                      <IconPlus size={14} stroke={2.2} />
                      زیرمجموعه برای «{root.name}»
                    </Pressable>
                  </div>
                )}
              </Reveal>
            );
          })}
        </Pad>

        <Pad>
          <SectionLabel>تأمین‌کننده‌ها</SectionLabel>
          <Gap h={10} />
          <LightRow onPress={() => nav.push("suppliers")} height={56}>
            <IconSquare icon={IconTruck} size={32} radius={10} iconSize={14} />
            <div style={{ flex: 1, minWidth: 0, marginInlineStart: 12, fontSize: 13,
                          fontWeight: 700, color: v("ink") }}>فهرستِ شرکت‌های پخش</div>
            <IconForward size={15} stroke={2} color={v("inkFaint")} />
          </LightRow>
        </Pad>

        {mayEdit && (
          <Pad style={{ marginTop: 18 }}>
            <Button tone="ghost" icon={IconPlus} onPress={() => { setName(""); setAdding(null); }}>
              افزودنِ انبارِ مستقل
            </Button>
          </Pad>
        )}
      </ScreenScroll>

      <Sheet
        open={adding !== false}
        onClose={() => setAdding(false)}
        title={parentOf ? `زیرمجموعهٔ ${parentOf.name}` : "انبارِ مستقلِ جدید"}
        footer={
          <Button onPress={() => {
            const n = name.trim();
            if (n.length < 2) return;
            addWarehouse(n, adding === false ? null : adding);
            setName(""); setAdding(false);
            toast(parentOf ? "زیرمجموعه اضافه شد" : "انبار اضافه شد", { tone: "ok" });
          }}>ثبت</Button>
        }
      >
        <div style={{ paddingTop: 6, paddingBottom: 8 }}>
          <Field label="نامِ محل" value={name} onChange={setName} autoFocus
                 placeholder={parentOf ? "مثلاً: فایل مکمل" : "مثلاً: انبار طبقهٔ دوم"} />
          <div style={{ marginTop: 8, fontSize: 11, color: v("inkFaint"), lineHeight: 1.9 }}>
            {parentOf
              ? "زیرمجموعه‌ها داخلِ انبارِ مادر می‌نشینند — مثلِ «فایل دارو» در «انبار اصلی»."
              : "انبارِ مستقل خودش سرِ فهرست می‌آید — مثلِ «قفسهٔ داروخانه»."}
          </div>
        </div>
      </Sheet>

      <Sheet open={editing != null} onClose={() => setEditing(null)} title={editing?.name}
        footer={
          <div style={{ display: "grid", gap: 8 }}>
            <Button onPress={() => {
              const n = eName.trim();
              if (n.length < 2) { setEErr("نام خیلی کوتاه است"); return; }
              renameWarehouse(editing!.id, n);
              setEditing(null);
              toast("نام عوض شد", { tone: "ok" });
            }}>ذخیرهٔ نام</Button>
            <Button tone="danger" icon={IconTrash} onPress={() => {
              if (removeWarehouse(editing!.id)) {
                setEditing(null);
                toast("محل حذف شد", { tone: "ok" });
              } else {
                setEErr("اول باید پارت‌ها و زیرمجموعه‌هایش را جابه‌جا کنی");
              }
            }}>حذفِ محل</Button>
          </div>
        }>
        <div style={{ paddingBlock: 8 }}>
          <Field label="نامِ محل" value={eName} onChange={(x) => { setEName(x); setEErr(""); }} />
          <div style={{ minHeight: 18, marginTop: 6, fontSize: 11, fontWeight: 700,
                        color: v("crit"), textAlign: "center", lineHeight: 1.8 }}>{eErr}</div>
        </div>
      </Sheet>
    </>
  );
}

/**
 * دکمهٔ ریزِ ویرایش روی ردیف.
 *
 * دو نکته که هر دو لازم‌اند:
 *  ۱) `as="div"` — خودِ ردیف یک <button> است و <button> تودرتو HTMLِ
 *     نامعتبر است؛ مرورگر ساختار را می‌شکند و کلیک نامطمئن می‌شود.
 *  ۲) `stopPropagation` — وگرنه لمسِ ویرایش، ردیف را هم باز می‌کند.
 */
function EditBtn({ onPress, label }: { onPress: () => void; label: string }) {
  return (
    <div
      onClick={(e) => { e.stopPropagation(); onPress(); }}
      onPointerDown={(e) => e.stopPropagation()}
      style={{ flex: "none", marginInlineStart: 6 }}
    >
      <Pressable
        as="div"
        onPress={() => {}}
        scale={0.86}
        ariaLabel={`ویرایشِ ${label}`}
        style={{ width: 34, height: 34, borderRadius: 11,
                 display: "grid", placeItems: "center",
                 background: v("surfaceAlt"), color: v("inkMuted") }}
      >
        <IconEdit size={14} />
      </Pressable>
    </div>
  );
}
