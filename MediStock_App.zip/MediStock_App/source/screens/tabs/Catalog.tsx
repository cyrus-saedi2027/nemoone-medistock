/* کالاها — صفحهٔ اثباتِ سرعت: ۵۰۱۰ ردیفِ واقعی، ~۲۵ ردیف در DOM */

import * as React from "react";
import { useData, useUi } from "@/store/StoreProvider";
import { can } from "@/domain/derive";
import { VirtualList } from "@/ui/list/VirtualList";
import { v } from "@/system/theme/ThemeProvider";
import { Lat, Num, Code } from "@/ui/text/Text";
import { R, SHADOW, EASE } from "@/system/tokens";
import { parseQuery, matches, isCodeQuery, type Query } from "@/domain/search";
import { IconSearch, IconX, IconFilter, IconGrid, IconPlus, IconQr } from "@/ui/icons";
import { Pressable } from "@/ui/primitives/Pressable";
import type { CatalogRow } from "@/domain/types";
import { Header, inkSoftOf } from "@/ui/chrome/Header";
import { useScreenTheme } from "@/screens/useScreenTheme";
import { contentBottom, topFade } from "@/system/geometry/backdrop";
import { useFrame } from "@/system/frame";
import { PAD, Empty, Button } from "@/ui/kit";
import {
  FilterPanel, EMPTY_FILTERS, countActive, passes, type Filters,
} from "@/ui/list/SearchFilters";
import { SELECT } from "@/system/haptics";
import { Skeleton } from "@/screens/tabs/Home";
import { useNav } from "@/router/Router";
import { ScanSheet } from "@/ui/overlays/ScanSheet";
import { codeFromScan } from "@/domain/types";
import { useActions } from "@/store/StoreProvider";

const ROW_H = 68;
const TONE = { ok: "ok", warn: "warn", crit: "crit" } as const;

/* ردیفِ تیره — عیناً TimelineItem نمونه با variant="dark".
   روی ورقهٔ سیاهِ پایین می‌نشیند و وقتی با اسکرول از منحنی رد شود و
   روی ناحیهٔ سفیدِ بالا بیاید هم درست خوانده می‌شود. برعکسش (کارتِ
   سفید روی ورقهٔ سیاه) خراب دیده می‌شود، برای همین نمونه هم همین
   سمت را انتخاب کرده. */
const Row = React.memo(function Row({
  r, onPress, dark,
}: { r: CatalogRow; onPress: (id: number) => void; dark: boolean }) {
  return (
    <Pressable onPress={() => onPress(r.i)} haptic={false} scale={0.985}
      style={{ display: "block", width: "100%", height: ROW_H - 8 }}>
      <div style={{
        height: "100%", display: "flex", alignItems: "center", gap: 11,
        background: v("card"), borderRadius: R.row, paddingInline: 13,
        boxShadow: dark ? SHADOW.rowDark : SHADOW.soft,
        position: "relative", overflow: "hidden",
        contentVisibility: "auto", containIntrinsicSize: "auto 60px",
      }}>
        <i style={{
          position: "absolute", insetInlineEnd: 0, top: 0, bottom: 0, width: 4,
          background: v(TONE[r.s]),
        }} />
        <div style={{ flex: 1, minWidth: 0 }}>
          <div style={{
            fontSize: 13.5, fontWeight: 700, lineHeight: 1.5,
            color: dark ? v("deepInk") : v("ink"),
            whiteSpace: "nowrap", overflow: "hidden", textOverflow: "ellipsis",
          }}>{r.n}</div>
          {/* کد کنارِ نامِ لاتین می‌نشیند تا در فهرست هم دیده شود —
              خواستهٔ صریح: «هر جایی که کد رو نوشتی، قبلش # بزار». */}
          <div style={{ display: "flex", alignItems: "center", gap: 7, marginTop: 1,
                        minWidth: 0 }}>
            <Code code={r.d} style={{ flex: "none", fontSize: 10.5,
                                      color: dark ? v("deepInkMuted") : v("inkFaint") }} />
            {r.l && (
              <Lat style={{ color: dark ? v("deepInkMuted") : v("inkFaint"),
                            whiteSpace: "nowrap", overflow: "hidden",
                            textOverflow: "ellipsis", minWidth: 0 }}>
                {r.l}
              </Lat>
            )}
          </div>
        </div>
        <div style={{ textAlign: "end", flex: "none", paddingInlineEnd: 6 }}>
          <Num value={r.q} style={{ fontSize: 16,
            color: r.q === 0 ? v("crit") : v("ink") }} />
          <div style={{ fontSize: 9, fontWeight: 700,
                        color: dark ? v("deepInkMuted") : v("inkFaint") }}>عدد</div>
        </div>
      </div>
    </Pressable>
  );
});

export function CatalogScreen() {
  const { catalog, cats, batches, warehouses, suppliers, policy, ready } = useData();
  const { session } = useUi();
  const { h } = useFrame();
  const nav = useNav();
  const mayAdd = session ? can(session.role, "editProduct") : false;
  const { toast } = useActions();
  const scrollRef = React.useRef<HTMLDivElement>(null);
  const [q, setQ] = React.useState("");
  const [dq, setDq] = React.useState<Query>({ mode: "none" });
  const [showFilters, setShowFilters] = React.useState(false);
  const [scan, setScan] = React.useState(false);
  const [filters, setFilters] = React.useState<Filters>(EMPTY_FILTERS);
  const t = useScreenTheme("catalog");

  /* دیبانسِ ۹۰ms — تایپ نباید ۵۰۱۰ ردیف را در هر کاراکتر بگردد */
  React.useEffect(() => {
    const id = setTimeout(() => setDq(parseQuery(q)), 90);
    return () => clearTimeout(id);
  }, [q]);

  /* پارت‌ها را یک‌بار بر اساسِ کالا گروه می‌کنیم، وگرنه فیلتر برای هر
     ردیف کلِ آرایه را می‌گشت — روی ۵۰۱۰ ردیف یعنی مرگِ سرچ. */
  const batchesByProduct = React.useMemo(() => {
    const m = new Map<number, typeof batches>();
    for (const b of batches) {
      const arr = m.get(b.productId);
      if (arr) arr.push(b); else m.set(b.productId, [b]);
    }
    return m;
  }, [batches]);
  const batchesOf = React.useCallback(
    (id: number) => batchesByProduct.get(id) ?? [], [batchesByProduct]
  );

  /* ردیف‌ها فقط وقتی تیره‌اند که ورقهٔ پایینِ همین صفحه تیره باشد.
     در سبکِ «ساده» اصلاً ناحیهٔ تیره‌ای نداریم، پس روشن می‌شوند. */
  const rowsDark = t.low === "dark";

  const nFilters = countActive(filters);

  /* ── چرا دیگر سقفِ ۴۰۰تایی نیست ────────────────────────────
   *
   * قبلاً وقتی جست‌وجو یا فیلتری فعال بود، حلقه بعد از ۴۰۰ نتیجه
   * می‌ایستاد. نیتش سرعت بود ولی نتیجه‌اش **دروغ** بود: فیلترِ
   * «موجود» می‌گفت «۴۰۰ قلم» در حالی که ۸۳۶ کالا موجودی داشتند، و
   * بقیه اصلاً قابلِ رسیدن نبودند. عددِ غلط از عددِ کند بدتر است.
   *
   * و اصلاً لازم نبود: فهرست *مجازی* است، پس ۴۰۰ ردیف و ۵٬۲۱۸ ردیف
   * هزینهٔ رندرِ یکسانی دارند (کمتر از ۴۰ ردیف در DOM). تنها هزینهٔ
   * واقعی همین حلقه است — یک `indexOf` روی رشتهٔ از پیش نرمال‌شده و
   * یک جست‌وجوی Map برای پارت‌ها. اندازه‌گیری شد: میانه دست‌نخورده
   * ماند (۱۶٫۷ms). */
  const items = React.useMemo(() => {
    if (!catalog.length) return [];
    if (dq.mode === "none" && !nFilters) return catalog;
    const out: CatalogRow[] = [];
    for (const r of catalog) {
      if (!matches(r, dq)) continue;
      if (nFilters && !passes(r, filters, batchesOf)) continue;
      out.push(r);
    }
    return out;
  }, [catalog, dq, filters, nFilters, batchesOf]);

  const catList = React.useMemo(() => cats.filter(Boolean), [cats]);

  const open = React.useCallback((id: number) => nav.push("product", { id }), [nav]);

  /**
   * نتیجهٔ اسکن.
   *
   * مستقیم به صفحهٔ کالا می‌رود، نه اینکه فقط جست‌وجو را پر کند —
   * انباردار بارکد را می‌زند چون *همان* کالا را می‌خواهد. اگر کد
   * ناشناس بود، به‌جای سکوت می‌گوید چه دید.
   */
  const onScanned = React.useCallback((raw: string) => {
    setScan(false);
    const code = codeFromScan(raw);
    const hit = code ? catalog.find((c) => c.d === code) : null;
    if (hit) { nav.push("product", { id: hit.i }); return; }
    toast(code ? `کالایی با کدِ ${code} پیدا نشد` : "این بارکد مالِ این سامانه نیست",
          { tone: "warn" });
  }, [catalog, nav, toast]);

  /* ارتفاعِ سرصفحه با باز و بسته‌شدنِ فیلترها عوض می‌شود، پس اندازه‌اش
     را می‌سنجیم؛ عددِ ثابت باعث می‌شد فهرست زیرِ فیلترها پنهان شود. */
  const headRef = React.useRef<HTMLDivElement>(null);
  const [headH, setHeadH] = React.useState(HEADER_H);
  React.useLayoutEffect(() => {
    const measure = () => setHeadH(headRef.current?.offsetHeight ?? HEADER_H);
    measure();
    const ro = new ResizeObserver(measure);
    if (headRef.current) ro.observe(headRef.current);
    return () => ro.disconnect();
  }, []);

  /* فقط بالای فهرست محو می‌شود تا ردیفِ در حالِ عبور زیرِ سرصفحهٔ ثابت
     با خطِ تیغی بریده نشود. پایین دیگر ماسک ندارد — `NavScrim` کارش را
     می‌کند و محتوا زیرِ قرص هم دیده می‌شود. */
  const mask = React.useMemo(() => topFade(), []);

  return (
    <div style={{ position: "absolute", inset: 0 }}>
      {/* سرصفحه ثابت است — فقط لیست اسکرول می‌شود، پس منحنی نمی‌لرزد */}
      <div ref={headRef} style={{ position: "absolute", insetInline: 0, top: 0, zIndex: 2 }}>
        {/* عنوان درشت مثلِ بقیهٔ تب‌ها. ارتفاعِ سرصفحه با ResizeObserver
            اندازه گرفته می‌شود، پس فهرست خودش را جابه‌جا می‌کند. */}
        <Header theme={t} title="کالاها" sub="کاتالوگ"
          right={
            <div style={{ fontSize: 11, fontWeight: 700, color: inkSoftOf(t) }}>
              <Num value={items.length} /> قلم
            </div>
          } />

        <div style={{ paddingInline: PAD, marginTop: 12, display: "flex", gap: 8 }}>
          <div style={{
            flex: 1, minWidth: 0,
            display: "flex", alignItems: "center", gap: 9,
            background: v("card"), borderRadius: 999, height: 48, paddingInline: 15,
            boxShadow: SHADOW.card,
          }}>
            <IconSearch size={17} color={v("inkFaint")} />
            <input
              value={q}
              onChange={(e) => setQ(e.target.value)}
              placeholder="نام دارو، یا ‎#کد"
              style={{
                flex: 1, minWidth: 0, border: 0, outline: 0, background: "none",
                fontSize: 13.5, fontFamily: "inherit", fontWeight: 600, color: v("ink"),
              }}
            />
            {q && (
              <Pressable onPress={() => setQ("")} haptic={false} scale={0.85} ariaLabel="پاک‌کردن"
                style={{ width: 26, height: 26, borderRadius: 99, display: "grid", flex: "none",
                         placeItems: "center", background: v("surfaceAlt"), color: v("inkMuted") }}>
                <IconX size={13} />
              </Pressable>
            )}
          </div>

          {/* دکمهٔ فیلتر — پررنگ و مستقل، نه یک آیکونِ محو داخلِ نوار */}
          <Pressable
            onPress={() => { SELECT(); setShowFilters((s) => !s); }}
            ariaLabel={showFilters ? "بستنِ فیلترها" : "بازکردنِ فیلترها"}
            scale={0.92}
            style={{
              width: 48, height: 48, flex: "none", borderRadius: 16, position: "relative",
              display: "grid", placeItems: "center",
              background: showFilters || nFilters ? v("accentStrong") : v("card"),
              color: showFilters || nFilters ? v("accentStrongInk") : v("ink"),
              boxShadow: SHADOW.card,
              transition: `background 220ms ${EASE.out}, color 220ms ${EASE.out}`,
            }}>
            <IconFilter size={20} stroke={2.4} />
            {nFilters > 0 && !showFilters && (
              <span style={{
                position: "absolute", top: -4, insetInlineEnd: -4,
                minWidth: 18, height: 18, paddingInline: 4, borderRadius: 999,
                background: v("crit"), color: "#fff",
                fontSize: 10, fontWeight: 800, display: "grid", placeItems: "center",
              }}><Num value={nFilters} /></span>
            )}
          </Pressable>

          {/* اسکنِ بارکد — سریع‌ترین راهِ رسیدن به یک کالا در انبارِ ۵۰۱۰تایی.
              پیش‌فرض خاموش است؛ مدیر از «تنظیمات ← بارکد و QR» روشنش می‌کند.
              تا وقتی برچسبی چاپ و چسبانده نشده، این دکمه فقط سردرگمی است. */}
          {policy.qrEnabled && (
            <Pressable
              onPress={() => { SELECT(); setScan(true); }}
              ariaLabel="اسکنِ بارکد" scale={0.92}
              style={{
                width: 48, height: 48, flex: "none", borderRadius: 16,
                display: "grid", placeItems: "center",
                background: v("card"), color: v("ink"), boxShadow: SHADOW.card,
              }}>
              <IconQr size={20} stroke={2.1} />
            </Pressable>
          )}

          {/* افزودنِ کالا — قبلاً صفحه‌اش بود ولی هیچ راهی به آن نمی‌رسید */}
          {mayAdd && (
            <Pressable
              onPress={() => { SELECT(); nav.push("productEdit"); }}
              ariaLabel="افزودنِ کالا" scale={0.92}
              style={{
                width: 48, height: 48, flex: "none", borderRadius: 16,
                display: "grid", placeItems: "center",
                background: v("deep"), color: v("onDark"), boxShadow: SHADOW.card,
              }}>
              <IconPlus size={21} stroke={2.4} />
            </Pressable>
          )}
        </div>

        <div style={{ paddingInline: PAD }}>
          <FilterPanel open={showFilters} filters={filters} set={setFilters}
                       cats={catList} warehouses={warehouses} suppliers={suppliers} />
        </div>

        <div style={{ height: 10 }} />
      </div>


      {/* ناحیهٔ اسکرول — ارتفاعِ سرصفحه از بالا کم شده */}
      <div
        ref={scrollRef}
        style={{
          position: "absolute", insetInline: 0, top: headH, bottom: 0,
          overflowY: "auto", overflowX: "hidden",
          WebkitOverflowScrolling: "touch", overscrollBehavior: "contain",
          maskImage: mask, WebkitMaskImage: mask,
          paddingInline: PAD,
          paddingBottom: contentBottom(h),
        }}
      >
        {!ready ? (
          <Skeleton rows={8} height={ROW_H - 8} />
        ) : catalog.length === 0 ? (
          /* کاتالوگِ خالی با «چیزی پیدا نشد» فرق دارد: اینجا مشکل
             جست‌وجو نیست، هنوز هیچ کالایی ثبت نشده. */
          <>
            <Empty icon={IconGrid} title="هنوز کالایی ثبت نشده"
                   note={mayAdd ? "یکی‌یکی اضافه کن، یا کلِ فهرست را از اکسل وارد کن."
                                : "از مدیر بخواه فهرستِ کالاها را وارد کند."} />
            {mayAdd && (
              <div style={{ display: "grid", gap: 8, maxWidth: 320, margin: "0 auto" }}>
                <Button icon={IconPlus} onPress={() => nav.push("productEdit")}>کالای جدید</Button>
                <Button tone="ghost" onPress={() => nav.push("importData")}>ورودِ گروهی از اکسل</Button>
              </div>
            )}
          </>
        ) : items.length === 0 ? (
          /* وقتی کاربر با `#` گشته، راهنماییِ «املا را عوض کن» بی‌ربط
             است — او کد زده، نه اسم. */
          <Empty icon={IconGrid} title="چیزی پیدا نشد"
                 note={isCodeQuery(dq)
                   ? "کدی با این شماره نیست. مثال: ‎#0005 — یا ‎#5 که همهٔ کدهای منتهی به ۵ را می‌آورد."
                   : "املای دیگری را امتحان کن، یا دسته را عوض کن."} />
        ) : (
          <VirtualList items={items} rowHeight={ROW_H} scrollRef={scrollRef}>
            {(r) => <Row r={r as CatalogRow} onPress={open} dark={rowsDark} />}
          </VirtualList>
        )}
      </div>

      <ScanSheet open={scan} onClose={() => setScan(false)} onCode={onScanned} />
    </div>
  );
}

/** ارتفاعِ ثابتِ سرصفحه: عنوان ۶۰ + جست‌وجو ۵۸ + تراشه‌ها ۴۸ */
const HEADER_H = 166;
