/* خانه — بالا: تاریخ و آمار. پایین: کارها و میان‌بُرها. */

import * as React from "react";
import { v } from "@/system/theme/ThemeProvider";
import { R, SHADOW } from "@/system/tokens";
import { useData, useUi } from "@/store/StoreProvider";
import { ScreenScroll } from "@/ui/chrome/ScreenScroll";
import { Header } from "@/ui/chrome/Header";
import {
  Card, IconSquare, LightRow, SectionLabel, StatBlock, Gap, Pad, Empty, HAIR,
} from "@/ui/kit";
import { HStrip } from "@/ui/list/HStrip";
import { Num, Lat } from "@/ui/text/Text";
import { Reveal } from "@/ui/primitives/Motion";
import {
  IconIn, IconOut, IconSwap, IconWarn, IconBell, IconBox, IconForward,
  IconChart, IconList, IconClock, IconFile, IconPlus, IconUpload,
} from "@/ui/icons";
import { Pressable } from "@/ui/primitives/Pressable";
import { useScreenTheme } from "@/screens/useScreenTheme";
import { useNav } from "@/router/Router";
import { toJalali, longJalali } from "@/system/i18n/jalali";
import { expiryHealth, can } from "@/domain/derive";

/** کارهای ثبت — فقط برای نقشی که اجازهٔ حرکت دارد */
const QUICK_WRITE = [
  { key: "moveIn",    fa: "ورود کالا",   icon: IconIn },
  { key: "moveOut",   fa: "خروج کالا",   icon: IconOut },
  { key: "transfer",  fa: "انتقال",      icon: IconSwap },
  { key: "stocktake", fa: "انبارگردانی", icon: IconList },
] as const;

/** جایگزینِ نقش‌های فقط‌خواندنی — به‌جای دکمه‌ای که همیشه رد می‌شود */
const QUICK_READ = [
  { key: "history", fa: "تاریخچه",  icon: IconClock },
  { key: "reports", fa: "گزارش‌ها", icon: IconChart },
  { key: "excel",   fa: "اکسل",     icon: IconFile },
  { key: "notifications", fa: "اعلان‌ها", icon: IconBell },
] as const;

export function HomeScreen({ onTab }: { onTab: (i: number) => void }) {
  const { catalog, batches, warehouses, notifs, ready } = useData();
  const { session } = useUi();
  const nav = useNav();
  const t = useScreenTheme("home");

  const stats = React.useMemo(() => {
    if (!catalog.length) return { total: 0, near: 0, zero: 0 };
    let near = 0, zero = 0;
    for (const c of catalog) {
      if (c.q === 0) zero++;
      else if (c.s === "warn" || c.s === "crit") near++;
    }
    return { total: catalog.length, near, zero };
  }, [catalog]);

  /* بحرانی‌ترین‌ها: نزدیک‌ترین انقضا با موجودیِ مثبت */
  const urgent = React.useMemo(() => {
    if (!batches.length) return [];
    const now = new Date();
    const rows: { b: (typeof batches)[number]; p: (typeof catalog)[number] }[] = [];
    const byId = new Map(catalog.map((c) => [c.i, c]));
    for (const b of batches) {
      if (b.qty <= 0) continue;
      if (expiryHealth(b.expiry, now) !== "crit") continue;
      const p = byId.get(b.productId);
      if (!p) continue;
      rows.push({ b, p });
      if (rows.length >= 4) break;
    }
    return rows;
  }, [batches, catalog]);

  /* نمایشِ دکمه‌ای که همیشه به «دسترسی نداری» می‌رسد، بدتر از
     نبودنش است. نقشِ فقط‌خواندنی میان‌بُرهای خواندنی می‌گیرد. */
  const mayMove = session ? can(session.role, "move") : false;
  const mayEdit = session ? can(session.role, "editProduct") : false;
  const QUICK = mayMove ? QUICK_WRITE : QUICK_READ;

  const jd = React.useMemo(() => longJalali(toJalali(new Date())), []);
  const unread = notifs.filter((n) => n.unread).length;

  return (
    <ScreenScroll>
      {/* عنوان مثلِ بقیهٔ تب‌هاست: نامِ خودِ صفحه، نه سلام‌واحوال‌پرسی.
          نامِ کاربر جایش در «پروفایل» است. */}
      <Header
        theme={t}
        sub={jd}
        title="خانه"
        right={
          /* قبلاً `rgba(255,255,255,.45)` بود؛ روی پس‌زمینهٔ سفیدِ اپ
             یعنی دکمه‌ای که اصلاً دیده نمی‌شود. */
          <Pressable onPress={() => nav.push("notifications")} scale={0.9}
            style={{ width: 38, height: 38, borderRadius: 13, position: "relative", flex: "none",
                     display: "grid", placeItems: "center", border: HAIR,
                     background: v("surfaceAlt"), color: v("ink") }}>
            <IconBell size={17} stroke={1.9} />
            {unread > 0 && (
              <i style={{ position: "absolute", top: 8, insetInlineEnd: 8, width: 7, height: 7,
                          borderRadius: 99, background: v("attn"),
                          boxShadow: `0 0 0 2px ${v("surfaceAlt")}` }} />
            )}
          </Pressable>
        }
      />

      {/* آمار روی ناحیهٔ زرد */}
      <Pad style={{ marginTop: 14 }}>
        <div style={{ display: "flex", gap: 8 }}>
          <StatBlock tone="accent" label="کلِ اقلام" value={<Num value={stats.total} />}
                     onPress={() => onTab(1)} />
          <StatBlock tone="accent" label="نزدیکِ انقضا" value={<Num value={stats.near} />}
                     tint={v("crit")} onPress={() => onTab(3)} />
          <StatBlock tone="accent" label="ناموجود" value={<Num value={stats.zero} />}
                     onPress={() => onTab(3)} />
        </div>
      </Pad>

      <Gap h={26} />

      {/* کارهای سریع — روی ناحیهٔ روشن */}
      <Pad>
        <SectionLabel>{mayMove ? "کارهای سریع" : "میان‌بُرها"}</SectionLabel>
        <Gap h={10} />
        <div style={{ display: "grid", gridTemplateColumns: "repeat(4,1fr)", gap: 8 }}>
          {QUICK.map((q, i) => (
            <Reveal key={q.key} i={i} step={36}>
              <Pressable onPress={() => nav.push(q.key as any)} scale={0.94}
                style={{
                  width: "100%", display: "grid", justifyItems: "center", gap: 7,
                  padding: "14px 4px", borderRadius: R.row,
                  background: v("card"), boxShadow: SHADOW.soft,
                }}>
                <div style={{ width: 38, height: 38, borderRadius: 13, display: "grid",
                              placeItems: "center", background: v("accentSurface"),
                              color: v("accentSurfaceInk") }}>
                  <q.icon size={18} stroke={1.9} />
                </div>
                <span style={{ fontSize: 10.5, fontWeight: 700, color: v("ink"),
                               textAlign: "center", lineHeight: 1.4 }}>{q.fa}</span>
              </Pressable>
            </Reveal>
          ))}
        </div>
      </Pad>

      <Gap h={22} />

      {/* فوریت‌ها */}
      <Pad>
        <SectionLabel count={urgent.length} action="همه" onAction={() => onTab(3)}>
          نیازِ رسیدگی
        </SectionLabel>
        <Gap h={10} />
        {!ready ? (
          <Skeleton rows={3} />
        ) : urgent.length === 0 ? (
          <Card pad={0}>
            <Empty icon={IconWarn} title="چیزی فوری نیست" note="هیچ پارتی زیر ۳ ماه تا انقضا ندارد." />
          </Card>
        ) : (
          <div style={{ display: "grid", gap: 8 }}>
            {urgent.map(({ b, p }, i) => (
              <Reveal key={b.id} i={i} step={40}>
                <LightRow onPress={() => nav.push("product", { id: p.i })} height={64}>
                  <i style={{ width: 3, height: 30, borderRadius: 99, flex: "none",
                              background: v("crit") }} />
                  <div style={{ flex: 1, minWidth: 0, marginInlineStart: 12 }}>
                    <div style={{ fontSize: 13, fontWeight: 700, color: v("ink"),
                                  whiteSpace: "nowrap", overflow: "hidden", textOverflow: "ellipsis" }}>
                      {p.n}
                    </div>
                    <div style={{ marginTop: 2, fontSize: 10.5, color: v("inkFaint") }}>
                      انقضای نزدیک · <Lat style={{ fontSize: 10.5 }}>{b.lotCode}</Lat>
                    </div>
                  </div>
                  <div style={{ textAlign: "end", flex: "none" }}>
                    <Num value={b.qty} style={{ fontSize: 15, color: v("ink") }} />
                    <div style={{ fontSize: 9, fontWeight: 700, color: v("inkFaint") }}>عدد</div>
                  </div>
                </LightRow>
              </Reveal>
            ))}
          </div>
        )}
      </Pad>

      <Gap h={22} />

      {/* انبارها */}
      <Pad>
        <SectionLabel count={warehouses.length} action="انبارها" onAction={() => onTab(2)}>
          محل‌های نگهداری
        </SectionLabel>
      </Pad>
      <Gap h={10} />
      <HStrip>
        {warehouses.map((wh) => {
          const n = batches.reduce((s, b) => (b.warehouseId === wh.id && b.qty > 0 ? s + 1 : s), 0);
          return (
            <Pressable key={wh.id} onPress={() => nav.push("warehouseOne", { id: wh.id })} scale={0.96}
              style={{
                flex: "none", width: 132, padding: 13, borderRadius: R.row,
                background: v("card"), border: HAIR, boxShadow: SHADOW.soft,
              }}>
              <IconSquare icon={IconBox} size={32} radius={10} iconSize={14} />
              <div style={{ marginTop: 9, fontSize: 12.5, fontWeight: 700, color: v("ink"),
                            whiteSpace: "nowrap", overflow: "hidden", textOverflow: "ellipsis" }}>
                {wh.name}
              </div>
              <div style={{ marginTop: 2, fontSize: 10.5, color: v("inkFaint") }}>
                <Num value={n} /> قلم
              </div>
            </Pressable>
          );
        })}
      </HStrip>

      <Gap h={22} />

      <Pad>
        <SectionLabel>میان‌بُرها</SectionLabel>
        <Gap h={10} />
        <div style={{ display: "grid", gap: 8 }}>
          {mayEdit && (
            <>
              <ShortcutRow icon={IconPlus} label="کالای جدید"
                           onPress={() => nav.push("productEdit")} />
              <ShortcutRow icon={IconUpload} label="ورودِ گروهی از اکسل"
                           onPress={() => nav.push("importData")} />
            </>
          )}
          <ShortcutRow icon={IconClock} label="تاریخچهٔ حرکت‌ها" onPress={() => nav.push("history")} />
          <ShortcutRow icon={IconChart} label="گزارش‌ها" onPress={() => nav.push("reports")} />
          {mayMove && (
            <ShortcutRow icon={IconList} label="ثبتِ گروهی" onPress={() => nav.push("bulk")} />
          )}
        </div>
      </Pad>
    </ScreenScroll>
  );
}

function ShortcutRow({ icon, label, onPress }: { icon: any; label: string; onPress: () => void }) {
  return (
    <LightRow onPress={onPress} height={56}>
      <IconSquare icon={icon} size={32} radius={10} iconSize={14} />
      <div style={{ flex: 1, minWidth: 0, marginInlineStart: 12, fontSize: 13,
                    fontWeight: 700, color: v("ink") }}>{label}</div>
      <IconForward size={15} stroke={2} color={v("inkFaint")} />
    </LightRow>
  );
}

export function Skeleton({ rows = 4, height = 62 }: { rows?: number; height?: number }) {
  return (
    <div style={{ display: "grid", gap: 8 }}>
      {Array.from({ length: rows }).map((_, i) => (
        <div key={i} style={{
          height, borderRadius: R.row,
          background: `linear-gradient(90deg, ${v("surfaceAlt")} 25%, ${v("card")} 50%, ${v("surfaceAlt")} 75%)`,
          backgroundSize: "220% 100%",
          animation: "shimmer 1400ms linear infinite",
          opacity: 1 - i * 0.12,
        }} />
      ))}
    </div>
  );
}
