/* پروفایل — حساب، ابزارها، مدیریت */

import * as React from "react";
import { v } from "@/system/theme/ThemeProvider";
import { R, SHADOW } from "@/system/tokens";
import { useData, useUi, useActions } from "@/store/StoreProvider";
import { ScreenScroll } from "@/ui/chrome/ScreenScroll";
import { Header, inkOf, inkSoftOf } from "@/ui/chrome/Header";
import { Gap, IconSquare, LightRow, Pad, SectionLabel, Button, StatBlock } from "@/ui/kit";
import { Num, Lat } from "@/ui/text/Text";
import { Reveal } from "@/ui/primitives/Motion";
import {
  IconForward, IconGear, IconUsers, IconFile, IconCloud, IconChart,
  IconBuilding, IconLogout, IconShield, IconHistory, IconList, IconTruck, IconTag, IconOut, IconQr,
  IconClock,
} from "@/ui/icons";
import { type ScreenKey } from "@/screens/screenThemes";
import { useScreenTheme } from "@/screens/useScreenTheme";
import { useNav } from "@/router/Router";
import { Sheet } from "@/ui/overlays/Sheet";
import { can, type Action } from "@/domain/derive";
import { APP_VERSION, checkForUpdate, type Newer } from "@/system/version";

const ROLE_FA: Record<string, string> = {
  MANAGER: "مدیر", FOUNDER: "مؤسس", KEEPER: "انباردار", TECHNICIAN: "تکنسین",
};

type Item = {
  key: ScreenKey; fa: string; icon: any; need?: Action;
  /** فقط وقتی دیده شود که بارکد از تنظیمات روشن باشد */
  needQr?: boolean;
};

const TOOLS: Item[] = [
  { key: "history",  fa: "تاریخچهٔ حرکت‌ها", icon: IconHistory },
  { key: "reports",  fa: "گزارش‌ها",         icon: IconChart },
  { key: "excel",    fa: "خروجی اکسل",       icon: IconFile, need: "excel" },
  { key: "labels",   fa: "برچسب‌های بارکد",  icon: IconQr,   need: "excel", needQr: true },
  { key: "bulk",     fa: "ثبتِ گروهی",       icon: IconList, need: "move" },
];

const ADMIN: Item[] = [
  { key: "users",     fa: "کاربران",        icon: IconUsers,    need: "users" },
  { key: "audit",     fa: "دفترِ تغییرات",  icon: IconHistory,  need: "users" },
  { key: "suppliers", fa: "تأمین‌کننده‌ها", icon: IconTruck,    need: "editProduct" },
  { key: "categories", fa: "دسته‌ها",       icon: IconTag,      need: "editProduct" },
  { key: "outReasons", fa: "علت‌های خروج",  icon: IconOut,      need: "editProduct" },
  { key: "company",   fa: "مشخصاتِ داروخانه", icon: IconBuilding, need: "settings" },
  { key: "backup",    fa: "پشتیبان‌گیری",   icon: IconCloud,    need: "settings" },
  { key: "archive",   fa: "آرشیوِ ماهانه",  icon: IconClock,    need: "settings" },
  { key: "settings",  fa: "تنظیمات",        icon: IconGear },
];

export function ProfileScreen() {
  const { session } = useUi();
  const { movements, catalog, policy } = useData();
  const { signOut } = useActions();
  const nav = useNav();
  const t = useScreenTheme("profile");
  const [bye, setBye] = React.useState(false);
  /* یک بار در هر بازکردنِ صفحه. اگر نشد، بی‌صدا رد می‌شود. */
  const [newer, setNewer] = React.useState<Newer>(null);
  React.useEffect(() => {
    let alive = true;
    void checkForUpdate().then((n) => { if (alive) setNewer(n); });
    return () => { alive = false; };
  }, []);

  if (!session) return null;
  const mine = movements.filter((m) => m.userId === session.id).length;

  const list = (items: Item[]) =>
    items.filter((it) =>
      (!it.need || can(session.role, it.need)) &&
      (!it.needQr || policy.qrEnabled));

  return (
    <>
      <ScreenScroll>
        <Header theme={t} sub="حسابِ کاربری" title="پروفایل" />

        {/* کارتِ کاربر روی ناحیهٔ تیره */}
        <Pad style={{ marginTop: 14 }}>
          <div style={{
            display: "flex", alignItems: "center", gap: 13,
            padding: 15, borderRadius: R.card, background: v("cardDark"),
          }}>
            <div style={{
              width: 52, height: 52, borderRadius: 18, flex: "none",
              display: "grid", placeItems: "center",
              background: v("accentSurface"), color: v("accentSurfaceInk"),
              fontSize: 17, fontWeight: 800,
            }}>{session.initials}</div>
            <div style={{ flex: 1, minWidth: 0 }}>
              <div style={{ fontSize: 15, fontWeight: 800, color: inkOf(t) }}>
                {session.fullName ?? session.username}
              </div>
              <div style={{ marginTop: 3, display: "flex", alignItems: "center", gap: 6 }}>
                <span style={{
                  fontSize: 10, fontWeight: 800, padding: "3px 9px", borderRadius: 999,
                  background: v("cardDarkAlt"), color: inkOf(t),
                }}>{ROLE_FA[session.role]}</span>
                <span style={{ fontSize: 10.5, color: inkSoftOf(t) }} dir="ltr">@{session.username}</span>
              </div>
            </div>
          </div>

          <div style={{ display: "flex", gap: 8, marginTop: 10 }}>
            <StatBlock tone="dark" label="ثبت‌های من" value={<Num value={mine} />} />
            <StatBlock tone="dark" label="کلِ اقلام" value={<Num value={catalog.length} />} />
            <StatBlock tone="dark" label="دسترسی" value={ROLE_FA[session.role]} />
          </div>
        </Pad>

        <Gap h={26} />

        <Pad>
          <SectionLabel>ابزارها</SectionLabel>
          <Gap h={10} />
          <div style={{ display: "grid", gap: 8 }}>
            {list(TOOLS).map((it, i) => (
              <Reveal key={it.key} i={i} step={36}>
                <NavRow icon={it.icon} label={it.fa} onPress={() => nav.push(it.key)} />
              </Reveal>
            ))}
          </div>
        </Pad>

        <Gap h={22} />

        <Pad>
          <SectionLabel>مدیریت</SectionLabel>
          <Gap h={10} />
          <div style={{ display: "grid", gap: 8 }}>
            {list(ADMIN).map((it, i) => (
              <Reveal key={it.key} i={i} step={36}>
                <NavRow icon={it.icon} label={it.fa} onPress={() => nav.push(it.key)} />
              </Reveal>
            ))}
          </div>
        </Pad>

        <Gap h={22} />

        <Pad>
          <NavRow icon={IconShield} label="رمزِ عبورِ من"
                  onPress={() => nav.push("userOne", { id: session.id, self: true })} />
          <Gap h={10} />
          <Button tone="danger" icon={IconLogout} onPress={() => setBye(true)}>
            خروج از حساب
          </Button>
        </Pad>

        <Gap h={16} />
        <Pad>
          {/* ── چرا این تذکر هست ───────────────────────────────
              کارفرما آیکونِ کهربایی می‌دید و انباردار سیاه، چون
              نصبِ او مالِ قبل از ۱٫۴٫۱ بود و هیچ‌چیز در اپ به او
              نمی‌گفت نسخهٔ تازه‌تری آمده. آیکونِ لانچر فقط با نصبِ
              دوباره عوض می‌شود، پس باید *گفته* شود.

              لینک عمداً نامِ **ثابت** است، نه نامِ نسخه‌دارِ داخلِ
              `version.json`: وب زودتر از فایلِ نصبی مستقر می‌شود، پس
              آن نام می‌تواند هنوز روی سرور نباشد — و چون SPA است،
              ۴۰۴ به‌جای خطا صفحهٔ اصلی را می‌دهد و کاربر فکر می‌کند
              دانلود شد. `/MediStock.apk` همیشه به آخرین فایلِ موجود
              اشاره می‌کند و nginx با هدرِ دانلود سروش می‌کند. */}
          {newer && (
            <a
              href="https://medistock.ir/MediStock.apk"
              style={{
                display: "block", textAlign: "center", textDecoration: "none",
                marginBottom: 10, padding: "9px 12px", borderRadius: 12,
                background: v("warn"), color: "#fff",
                fontSize: 11.5, fontWeight: 800, lineHeight: 1.7,
              }}
            >
              نسخهٔ <Lat>{newer.version}</Lat> آمده — برای گرفتنش بزن
            </a>
          )}
          <div style={{ textAlign: "center", fontSize: 10.5, color: v("inkFaint") }}>
            مدی‌استاک · نسخهٔ <Lat>{APP_VERSION}</Lat> · medistock.ir
          </div>
        </Pad>
      </ScreenScroll>

      <Sheet
        open={bye}
        onClose={() => setBye(false)}
        title="خروج از حساب"
        footer={
          <div style={{ display: "grid", gap: 8 }}>
            <Button tone="danger" onPress={() => { setBye(false); signOut(); }}>بله، خارج شو</Button>
            <Button tone="ghost" onPress={() => setBye(false)}>انصراف</Button>
          </div>
        }
      >
        <div style={{ paddingBlock: 6, fontSize: 13, color: v("inkMuted"), lineHeight: 2 }}>
          برای ورودِ بعدی دوباره نام کاربری و رمز لازم است.
          کارهای ثبت‌نشده‌ای که در صف مانده‌اند از بین نمی‌روند.
        </div>
      </Sheet>
    </>
  );
}

function NavRow({ icon, label, onPress }: { icon: any; label: string; onPress: () => void }) {
  return (
    <LightRow onPress={onPress} height={56}>
      <IconSquare icon={icon} size={32} radius={10} iconSize={14} />
      <div style={{ flex: 1, minWidth: 0, marginInlineStart: 12, fontSize: 13,
                    fontWeight: 700, color: v("ink") }}>{label}</div>
      <IconForward size={15} stroke={2} color={v("inkFaint")} />
    </LightRow>
  );
}
