/* ─────────────────────────────────────────────────────────────
 *  تمِ هر صفحه — نگاشتِ مستقیمِ جدولِ THEMES نمونه
 *
 *  در نمونه هویتِ هر صفحه از سه چیز می‌آید: رنگِ ناحیهٔ بالا،
 *  روشن/تیره بودنِ ورقهٔ پایین، و *ارتفاعِ* تقسیم‌کننده (yMid).
 *  چون yMid فنر می‌خورد، عبور بینِ صفحه‌ها به‌جای بریدن سُر می‌خورد.
 *
 *  ریتمِ پنج تبِ نمونه عیناً حفظ شده:
 *      Overview   زرد بالا  | روشن پایین | 224
 *      Projects   سفید بالا | تیره پایین | 330
 *      Dashboard  زرد بالا  | روشن پایین | 396
 *      Payments   سفید بالا | تیره پایین | 330
 *      Profile    تیره بالا | روشن پایین | 300
 *
 *  یعنی از پنج تب، *دو تا ورقهٔ پایینشان سیاه است* و یکی سیاهیِ بالا
 *  دارد. این تناوب همان چیزی است که اپ را «زنده» نشان می‌دهد؛ اگر
 *  همه‌شان یک‌جور باشند، طرح می‌میرد.
 *
 *  قانونِ چیدمان: تقسیم‌کننده صاف نیست — لبهٔ راست ۴۳px بالا می‌کشد
 *  و لبهٔ چپ ۶۱px پایین می‌افتد. متنِ فارسی از راست شروع می‌شود، پس
 *  محتوای ناحیهٔ بالا باید بالای `yMid − 43` تمام شود.
 * ───────────────────────────────────────────────────────────── */

export type ScreenTheme = {
  key: string;
  /** پرکنندهٔ ناحیهٔ بالا */
  up: "accent" | "card" | "deep";
  /** ورقهٔ پایین (جایی که نوار می‌نشیند) */
  low: "light" | "dark";
  /** ارتفاعِ تقسیم‌کننده از بالای قاب */
  yMid: number;
  canvas: "canvas" | "canvasWarm";
  /** جوهرِ متن روی ناحیهٔ بالا */
  ink: "accentSurfaceInk" | "ink" | "deepInk";
};

/** زرد بالا · روشن پایین — کارت‌های سفید زیرِ منحنی */
const gold = (key: string, yMid: number, x: Partial<ScreenTheme> = {}): ScreenTheme => ({
  key, up: "accent", low: "light", yMid, canvas: "canvas", ink: "accentSurfaceInk", ...x,
});

/** سفید بالا · **تیره پایین** — ردیف‌های زیرِ منحنی باید تیره باشند */
const split = (key: string, yMid: number, x: Partial<ScreenTheme> = {}): ScreenTheme => ({
  key, up: "card", low: "dark", yMid, canvas: "canvasWarm", ink: "ink", ...x,
});

/** تیره بالا · روشن پایین */
const deep = (key: string, yMid: number, x: Partial<ScreenTheme> = {}): ScreenTheme => ({
  key, up: "deep", low: "light", yMid, canvas: "canvas", ink: "deepInk", ...x,
});

export const ST = {
  /* ── پنج تب: عیناً ریتمِ نمونه ── */
  home:      gold("home", 224),        // Overview
  catalog:   split("catalog", 330),    // Projects   ← ورقهٔ سیاه پایین
  warehouse: gold("warehouse", 396),   // Dashboard
  alerts:    split("alerts", 330),     // Payments   ← ورقهٔ سیاه پایین
  profile:   deep("profile", 300),     // Profile

  /* ── جزئیات: نگاشت به همان تم‌های نمونه ── */
  product:      deep("product", 352),       // projectDetail
  batch:        split("batch", 330),        // invoiceDetail
  moveIn:       split("moveIn", 330),       // invoiceNew
  moveOut:      split("moveOut", 330),
  transfer:     split("transfer", 330),
  receipt:      gold("receipt", 232),       // goals
  history:      split("history", 330),      // transactions
  warehouseOne: deep("warehouseOne", 300),  // clientDetail
  productEdit:  gold("productEdit", 224),
  stocktake:    deep("stocktake", 340),     // timeTracker
  reports:      split("reports", 250),      // agenda
  excel:        split("excel", 250),
  importData:   gold("importData", 224),
  labels:       gold("labels", 224),
  backup:       deep("backup", 300),
  suppliers:    split("suppliers", 250),
  categories:   split("categories", 250),
  outReasons:   split("outReasons", 250),
  company:      split("company", 250),
  notifications: gold("notifications", 230),
  users:        split("users", 250),
  userOne:      deep("userOne", 300),
  userNew:      gold("userNew", 224),
  settings:     deep("settings", 210),
  bulk:         split("bulk", 250),
  audit:        split("audit", 250),
  archive:      deep("archive", 300),

  login: gold("login", 286),
} as const;

export type ScreenKey = keyof typeof ST;

/** آیا ردیف‌های زیرِ تقسیم‌کننده باید تیره باشند؟ */
export const isSplit = (t: ScreenTheme) => t.low === "dark";

/**
 * تمِ صفحه بعد از اعمالِ سبکِ پس‌زمینه.
 *
 * در سبکِ «ساده» کلِ صفحه یک سطحِ روشن است، پس نمی‌شود جوهرِ روشن
 * (deepInk) یا جوهرِ روی‌زرد داشت — سرصفحه ناخوانا می‌شد. اینجا همهٔ
 * صفحه‌ها به یک تمِ روشنِ واحد نگاشت می‌شوند.
 */
/**
 * حالا فقط یک پس‌زمینه داریم و روشن است، پس همهٔ صفحه‌ها یک تمِ روشنِ
 * واحد می‌گیرند. `ST` سرِ جایش مانده چون صفحه‌ها از آن برای جوهرِ
 * سرصفحه استفاده می‌کنند و اگر بعداً سبکِ تازه‌ای آمد، دوباره زنده می‌شود.
 */
export function effectiveTheme(t: ScreenTheme, _bg: string): ScreenTheme {
  return { ...t, up: "card", low: "light", ink: "ink" };
}
