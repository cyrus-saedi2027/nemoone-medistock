/* ─────────────────────────────────────────────────────────────
 *  ورود
 *
 *  دکمه‌های «ورودِ سریع» حذف شده‌اند: روی دستگاهِ مشترکِ داروخانه
 *  یعنی هر کسی با یک لمس به حسابِ مدیر می‌رود.
 *
 *  چیدمان: یک سردرِ توپُر تا حدودِ ۴۴٪ صفحه، و کارتِ ورود که *روی
 *  مرزِ آن* می‌نشیند. این همان الگویی است که کلِ اپ دارد (ناحیهٔ
 *  بالا + کارت‌های شناور) — پس اولین صفحه‌ای که کاربر می‌بیند همان
 *  زبانِ بصریِ بقیهٔ اپ را حرف می‌زند، نه چیزِ دیگری.
 *
 *  همهٔ حرکت‌ها فقط transform و opacity‌اند و روی GPU می‌روند؛ صفحهٔ
 *  ورود اولین برداشتِ کاربر از سرعتِ اپ است.
 * ───────────────────────────────────────────────────────────── */

import * as React from "react";
import { v } from "@/system/theme/ThemeProvider";
import { R, SHADOW, EASE } from "@/system/tokens";
import { useActions } from "@/store/StoreProvider";
import { Button, Field, PAD, HAIR } from "@/ui/kit";
import { IconEye, IconEyeOff, IconUser, IconShield, IconCloud, IconBox } from "@/ui/icons";
import { Pressable } from "@/ui/primitives/Pressable";
import { Fade } from "@/ui/primitives/Motion";
import { SUCCESS } from "@/system/haptics";
import { useFrame } from "@/system/frame";
import { toFa } from "@/system/i18n/digits";
import { queuedCount } from "@/store/sync";

/** سه خطِ کوتاه زیرِ کارت — می‌گوید اپ چه‌کاره است، بدونِ شعار */
const FACTS = [
  { icon: IconBox,    fa: "ورود، خروج و انتقالِ کالا" },
  { icon: IconShield, fa: "هر ثبت به نامِ کاربرِ خودش" },
  { icon: IconCloud,  fa: "پشتیبانِ خودکارِ ماهانه" },
] as const;

export function Login() {
  const { signIn, authenticate } = useActions();
  const { h } = useFrame();
  const [u, setU] = React.useState("");
  const [p, setP] = React.useState("");
  const [show, setShow] = React.useState(false);
  const [err, setErr] = React.useState("");
  const [shake, setShake] = React.useState(0);

  const [busy, setBusy] = React.useState(false);

  /* اعتبارسنجی در استور است، نه اینجا: مدیر می‌تواند کاربر بسازد و
     رمز عوض کند، و صفحهٔ ورود باید همان فهرستِ زنده را ببیند.
     حالا اول از سرور می‌پرسد، پس async است — و تا جواب نیامده دکمه
     قفل می‌شود تا کسی سه‌بار پشتِ‌سرِ‌هم نزند. */
  const go = async () => {
    if (busy) return;
    setBusy(true);
    let res: Awaited<ReturnType<typeof authenticate>>;
    try { res = await authenticate(u, p); } finally { setBusy(false); }
    if (res === null) {
      setErr("نام کاربری یا رمز درست نیست");
      setShake((s) => s + 1);
      return;
    }
    if (res === "inactive") {
      /* ── A closed account still holding unsent work ───────────
       *
       * This is how the keeper's phone was left: the account was
       * closed on 26 Shahrivar while the phone was still signed in
       * to it, so every entry since then sat in the outbox with no
       * way out -- the server will not, and should not, accept work
       * from a closed account.
       *
       * Reopening the account is the wrong fix; whoever closed it
       * had a reason. Signing in as anybody still active sends the
       * same entries, recorded under that person's name. A stock
       * movement under the wrong name is a small untruth. A stock
       * movement that never happened is a wrong shelf.
       * ────────────────────────────────────────────────────── */
      const left = queuedCount();
      setErr(left
        ? `این حساب بسته شده. ${toFa(left)} ثبتِ نرفته محفوظ است — با یک حسابِ فعالِ دیگر وارد شو تا فرستاده شوند`
        : "این حساب غیرفعال است");
      return;
    }
    if (typeof res === "object" && "locked" in res) {
      /* دقیقه گرد به بالا — «۴ دقیقه» از «۲۳۷ ثانیه» خواناتر است */
      const min = Math.ceil(res.locked / 60);
      setErr(`تلاشِ زیاد. ${toFa(min)} دقیقهٔ دیگر دوباره امتحان کن`);
      setShake((s) => s + 1);
      return;
    }
    setErr("");
    SUCCESS();
    signIn(res);
  };

  /* ارتفاعِ سردر با ارتفاعِ قاب می‌آید تا روی گوشیِ کوتاه، کارتِ ورود
     زیرِ خطِ تا نیفتد و روی گوشیِ بلند، صفحه خالی نماند. */
  const heroH = Math.round(Math.min(Math.max(h * 0.44, 280), 400));

  return (
    <div style={{ position: "absolute", inset: 0, overflowY: "auto",
                  WebkitOverflowScrolling: "touch" }}>
      {/* ── سردر ───────────────────────────────────────────── */}
      <div style={{
        position: "relative", height: heroH,
        background: v("deepGrad"),
        borderEndStartRadius: 34, borderEndEndRadius: 34,
        overflow: "hidden",
        display: "grid", placeItems: "center", textAlign: "center",
      }}>
        {/* دو حلقهٔ خیلی محو، فقط برای اینکه سطحِ توپُر مسطح نباشد.
            SVG نیست و انیمیشن هم ندارد — یک بار رَستر می‌شود. */}
        <i aria-hidden style={{
          position: "absolute", width: heroH * 1.5, height: heroH * 1.5,
          borderRadius: "50%", top: -heroH * 0.72, insetInlineEnd: -heroH * 0.5,
          border: `1px solid ${v("navEdge")}`,
        }} />
        <i aria-hidden style={{
          position: "absolute", width: heroH, height: heroH,
          borderRadius: "50%", bottom: -heroH * 0.55, insetInlineStart: -heroH * 0.3,
          border: `1px solid ${v("navEdge")}`,
        }} />

        <div style={{ position: "relative", paddingInline: PAD, paddingBottom: 26 }}>
          <Fade y={12}>
            {/* نشانِ مربعی — همان حروفِ فونتِ اختصاصی، در قاب */}
            <div style={{
              width: 62, height: 62, borderRadius: 20, margin: "0 auto",
              display: "grid", placeItems: "center",
              background: v("onDark"), color: v("deep"),
              boxShadow: "0 14px 30px -14px rgba(0,0,0,.6)",
            }}>
              <span dir="ltr" style={{
                fontFamily: "'MediStockMark','Vazirmatn',sans-serif",
                fontWeight: 300, fontSize: 30, lineHeight: 1,
              }}>M</span>
            </div>
          </Fade>

          {/* `dir="ltr"` روی خودِ نشان لازم است: صفحه RTL است و بدونِ
              آن مرورگر می‌تواند حروفِ لاتین را جابه‌جا بچیند.
              فونتِ MediStockMark فقط همین ۹ نویسه را دارد (~۱KB) و
              به‌صورتِ data-URI داخلِ index.html نشسته — صفر درخواستِ شبکه. */}
          <Fade y={12} delay={70}>
            <div dir="ltr" style={{
              marginTop: 18,
              fontFamily: "'MediStockMark','Vazirmatn',sans-serif",
              fontWeight: 300,
              fontSize: "clamp(32px, 10vw, 44px)",
              letterSpacing: "0.055em",
              lineHeight: 1.1,
              color: v("onDark"),
            }}>
              MediStock
            </div>
          </Fade>

          <Fade y={10} delay={140}>
            <div style={{
              marginTop: 10, fontSize: 12, fontWeight: 600, lineHeight: 1.9,
              color: v("navInk"),
            }}>
              اپلیکیشنِ جامعِ مدیریتِ انبارِ داروخانه
            </div>
          </Fade>
        </div>
      </div>

      {/* ── کارتِ ورود — روی مرزِ سردر می‌نشیند ──────────────── */}
      <div style={{ paddingInline: PAD, marginTop: -34, position: "relative", zIndex: 1 }}>
        <Fade y={16} delay={110}>
          <form
            key={shake}
            onSubmit={(e) => { e.preventDefault(); void go(); }}
            style={{
              background: v("card"), borderRadius: R.card, padding: 18,
              border: HAIR, boxShadow: SHADOW.lifted,
              animation: shake ? `shakeX 320ms ${EASE.out}` : undefined,
            }}
          >
            <div style={{ fontSize: 14.5, fontWeight: 800, color: v("ink"), marginBottom: 14 }}>
              ورود به حساب
            </div>

            <div style={{ display: "grid", gap: 12 }}>
              <Field label="نام کاربری" value={u} ltr autoFocus
                     onChange={(s) => { setU(s); setErr(""); }}
                     suffix={<IconUser size={16} color={v("inkFaint")} />} />
              <Field label="رمز عبور" value={p} ltr type={show ? "text" : "password"}
                     onChange={(s) => { setP(s); setErr(""); }}
                     suffix={
                       <Pressable onPress={() => setShow((x) => !x)} haptic={false} scale={0.88}
                         ariaLabel={show ? "پنهان کردن رمز" : "نمایش رمز"}
                         style={{ display: "grid", placeItems: "center", width: 40, height: 40,
                                  marginInlineEnd: -8, color: v("inkFaint") }}>
                         {show ? <IconEyeOff size={16} /> : <IconEye size={16} />}
                       </Pressable>
                     } />
            </div>

            <div style={{
              minHeight: 18, marginTop: 8, fontSize: 11.5, fontWeight: 700,
              color: v("crit"), textAlign: "center",
            }}>{err}</div>

            {/* دکمه از نوعِ submit است تا Enter هم کار کند — روی
                کیبوردِ گوشی «برو» همان کاری را بکند که انتظار می‌رود. */}
            <button type="submit" style={{ display: "none" }} aria-hidden />
            <Button onPress={() => void go()} tone="accent" disabled={busy}
                    style={{ marginTop: 2 }}>
              {busy ? "در حالِ ورود…" : "ورود به سیستم"}
            </Button>
          </form>
        </Fade>
      </div>

      {/* ── سه خطِ معرفی ────────────────────────────────────── */}
      <div style={{ paddingInline: PAD, marginTop: 22 }}>
        <div style={{ display: "grid", gap: 10 }}>
          {FACTS.map((f, i) => (
            <Fade key={f.fa} y={8} delay={200 + i * 70}>
              <div style={{ display: "flex", alignItems: "center", gap: 11 }}>
                <span style={{
                  width: 30, height: 30, borderRadius: 10, flex: "none",
                  display: "grid", placeItems: "center",
                  background: v("surfaceAlt"), color: v("inkMuted"), border: HAIR,
                }}>
                  <f.icon size={14} stroke={1.9} />
                </span>
                <span style={{ fontSize: 12, fontWeight: 600, color: v("inkMuted") }}>{f.fa}</span>
              </div>
            </Fade>
          ))}
        </div>
      </div>

      <div style={{ padding: "26px 0 30px", textAlign: "center",
                    fontSize: 10.5, fontWeight: 600, color: v("inkFaint") }}>
        نسخهٔ ۱٫۰٫۰ · medistock.ir
      </div>

      <style>{`@keyframes shakeX{
        0%,100%{transform:translate3d(0,0,0)}
        22%{transform:translate3d(-7px,0,0)}
        44%{transform:translate3d(6px,0,0)}
        68%{transform:translate3d(-4px,0,0)}
        86%{transform:translate3d(2px,0,0)}
      }`}</style>
    </div>
  );
}
