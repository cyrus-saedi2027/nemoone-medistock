/* ─────────────────────────────────────────────────────────────
 *  روتر — پشتهٔ جداگانه برای هر تب + سوایپِ برگشت
 *
 *  قانونِ جهت (تنها جای حساسِ RTL در روتر):
 *     ورودی: dx فیزیکی × DIR = پیشرفتِ منطقی
 *     رندر:  پیشرفت × عرض × DIR = جابه‌جاییِ فیزیکی
 *  هیچ‌وقت هر دو روی یک مقدار — وگرنه دوبار برعکس می‌شود.
 *
 *  در RTL صفحهٔ جدید از چپ می‌آید و ژستِ برگشت از لبهٔ راست
 *  شروع می‌شود؛ آینهٔ دقیقِ iOS.
 * ───────────────────────────────────────────────────────────── */

import * as React from "react";
import { Spring } from "@/system/motion/spring";
import { useSpringRef, useSpringBind } from "@/system/motion/useSpring";
import { useFrame } from "@/system/frame";
import { DIR, IS_RTL } from "@/system/dir";
import { MOTION, GESTURE, Z, EASE, SHADOW } from "@/system/tokens";
import { SELECT } from "@/system/haptics";
import { ST, type ScreenKey, type ScreenTheme } from "@/screens/screenThemes";

export type Entry = { key: ScreenKey; params?: any; id: number };

export type RouterApi = {
  push: (key: ScreenKey, params?: any) => void;
  pop: () => void;
  popTo: (key: ScreenKey) => void;
  reset: () => void;
  resetAll: () => void;
  goTab: (i: number) => void;
};

const ApiCtx = React.createContext<RouterApi | null>(null);
export const useNav = () => React.useContext(ApiCtx)!;

export type RouterState = { tab: number; stacks: Entry[][] };

export function useRouterState(tabs: number, onTabChange: (i: number) => void) {
  const [state, setState] = React.useState<RouterState>({
    tab: 0, stacks: Array.from({ length: tabs }, () => []),
  });
  const seq = React.useRef(1);
  const tabRef = React.useRef(0);
  tabRef.current = state.tab;

  const api = React.useMemo<RouterApi>(() => ({
    push(key, params) {
      SELECT();
      setState((s) => {
        const stacks = s.stacks.slice();
        stacks[s.tab] = [...stacks[s.tab], { key, params, id: seq.current++ }];
        return { ...s, stacks };
      });
    },
    pop() {
      setState((s) => {
        const stacks = s.stacks.slice();
        if (!stacks[s.tab].length) return s;
        stacks[s.tab] = stacks[s.tab].slice(0, -1);
        return { ...s, stacks };
      });
    },
    popTo(key) {
      setState((s) => {
        const stacks = s.stacks.slice();
        const at = stacks[s.tab].findIndex((e) => e.key === key);
        stacks[s.tab] = at < 0 ? [] : stacks[s.tab].slice(0, at + 1);
        return { ...s, stacks };
      });
    },
    reset() {
      setState((s) => {
        const stacks = s.stacks.slice();
        stacks[s.tab] = [];
        return { ...s, stacks };
      });
    },
    /** همه‌چیز به حالتِ اول — بعد از عوض‌شدنِ کاربر */
    resetAll() {
      setState((s) => ({ tab: 0, stacks: s.stacks.map(() => []) }));
    },
    /**
     * زدنِ هر تب در نوارِ پایین، پشتهٔ *همان* تب را خالی می‌کند.
     *
     * چرا همیشه، نه فقط وقتی تب فعال است: انباردار در «کالاها ← ویرایشِ
     * فلان کالا» بود، رفت «خانه»، بعد «کالاها» را زد — و به‌جای فهرستِ
     * کالاها، دوباره وسطِ همان ویرایش افتاد. برای کسی که با گوشی کار
     * می‌کند این یعنی «دکمه خراب است».
     *
     * پس نوارِ پایین یک قولِ ساده می‌دهد: هر آیکون = ریشهٔ همان بخش،
     * هر بار، حتی اگر ده صفحه رویش باز بوده باشد.
     */
    goTab(i) {
      setState((s) => {
        const same = s.tab === i;
        if (same && !s.stacks[i].length) return s;   // چیزی برای عوض‌کردن نیست
        const stacks = s.stacks.slice();
        stacks[i] = [];
        return { tab: i, stacks };
      });
      onTabChange(i);
    },
  }), [onTabChange]);

  return { state, api, ApiCtx };
}

/** تمِ پس‌زمینه = تمِ بالاترین صفحهٔ پشته، وگرنه تمِ خودِ تب */
export function activeTheme(state: RouterState, tabKeys: ScreenKey[]): ScreenTheme {
  const stack = state.stacks[state.tab];
  const top = stack[stack.length - 1];
  return ST[top ? top.key : tabKeys[state.tab]];
}

/* ── لایهٔ push با سوایپِ برگشت ─────────────────────────
 *
 *  چرا بازنویسی شد — «بزور کار می‌کند و خیلی جاها اصلاً نه»:
 *
 *  ۱) ژست فقط از یک نوارِ ۳۸ پیکسلیِ لبه شروع می‌شد. روی صفحهٔ ۳۹۰،
 *     یعنی باید انگشت را دقیقاً روی همان یک‌دهمِ لبه بگذاری.
 *  ۲) بعد از قفل‌شدن باید ۳۴٪ عرض کشیده می‌شد تا قطعی شود، آن هم از
 *     نو (`x0` صفر می‌شد) — روی هم نزدیک ۱۴۳ پیکسل.
 *  ۳) سرعت فقط از *دو نمونهٔ آخر* حساب می‌شد. انگشت موقعِ بلندشدن کُند
 *     می‌شود، پس یک فلیکِ تند هم اغلب سرعتِ نزدیکِ صفر می‌خواند و راهِ
 *     «فلیک» هیچ‌وقت باز نمی‌شد.
 *
 *  حالا: نوارِ لبه پهن‌تر، شروع از وسطِ صفحه هم مجاز (چون در این اپ
 *  هیچ ژستِ افقیِ دیگری روی ردیف‌ها نیست)، سرعت روی پنجرهٔ ۹۰ms، و
 *  آستانهٔ قطعی‌شدن پایین‌تر.
 *
 *  ساختار هم عوض شد: ظرفِ ژست ثابت می‌ماند و فقط *محتوا* حرکت می‌کند.
 *  قبلاً خودِ ظرف جابه‌جا می‌شد، پس وسطِ کشیدن ناحیهٔ لبه هم با آن
 *  می‌رفت. پشتش یک پردهٔ محو هم اضافه شد تا صفحهٔ زیرین حینِ برگشت
 *  روشن شود — همان چیزی که حرکت را «نرم» نشان می‌دهد، نه بریده.
 */
export function PushLayer({
  entry, depth, onPop, children,
}: {
  entry: Entry; depth: number; onPop: () => void; children: React.ReactNode;
}) {
  const { w } = useFrame();
  const p = useSpringRef(1, MOTION.swipe);      // ۱ = بیرون، ۰ = نشسته
  const drag = React.useRef<{
    x0: number; y0: number; p0: number;
    /** نمونه‌های اخیرِ اشاره‌گر برای سنجشِ سرعت روی یک پنجره */
    hist: { t: number; x: number }[];
    locked: boolean; fromEdge: boolean; blocked: boolean;
  } | null>(null);
  const dead = React.useRef(false);

  const layer = useSpringBind<HTMLDivElement>(p, (el, x) => {
    el.style.transform = `translate3d(${(x * w * DIR).toFixed(2)}px,0,0)`;
    el.style.boxShadow = x > 0.995 ? "none" : SHADOW.lifted;
  });

  /* پردهٔ پشتِ لایه: صفحهٔ زیرین وقتی این لایه نشسته کمی تیره است و
     همراهِ برگشت روشن می‌شود. عمق می‌دهد و مرزِ دو صفحه را نشان می‌دهد. */
  const veil = useSpringBind<HTMLDivElement>(p, (el, x) => {
    el.style.opacity = String(Math.max(0, (1 - x) * 0.22));
  });

  React.useEffect(() => { p.springTo(0); }, [p]);

  const inEdge = (clientX: number, rect: DOMRect) => {
    const x = clientX - rect.left;
    return IS_RTL ? x > rect.width - GESTURE.edgeInset : x < GESTURE.edgeInset;
  };

  /* نکتهٔ مهم: اشاره‌گر *فوراً* گرفته نمی‌شود.
     ناحیهٔ لبه دقیقاً روی دکمهٔ برگشتِ سرصفحه می‌افتد؛ اگر همان لحظهٔ
     pointerdown آن را بگیریم، کلیکِ دکمه هیچ‌وقت شلیک نمی‌شود و
     «برگشت» با لمس کار نمی‌کند. پس اول آستانهٔ حرکت، بعد گرفتن. */
  const onPointerDown = (e: React.PointerEvent) => {
    if (dead.current) return;
    /* موس با دکمهٔ راست/وسط ژست نیست */
    if (e.pointerType === "mouse" && e.button !== 0) return;
    const rect = (e.currentTarget as HTMLElement).getBoundingClientRect();
    const t = e.target as HTMLElement | null;
    const fromEdge = inEdge(e.clientX, rect);

    /* ── چه چیزی جلوی ژست را می‌گیرد، و کجا ──────────────────
     *
     * قبلاً این فهرست *همیشه* ژست را می‌کشت. نتیجه‌اش این بود که در
     * صفحه‌های پرِ فیلد — ورود، خروج، تعریفِ کالا، کاربرِ جدید،
     * انبارگردانی — تقریباً هرجا انگشت می‌گذاشتی روی یک ورودی بود و
     * «کشیدن از لبه» اصلاً جواب نمی‌داد. یعنی دقیقاً همان صفحه‌هایی که
     * بیشترین نیاز را به بستنِ سریع دارند.
     *
     * حالا فقط *شروع از وسطِ صفحه* را می‌گیرد. نوارِ لبه مالِ ژستِ
     * برگشت است و بس — همان قراردادی که iOS دارد: از لبه بکشی، صفحه
     * بسته می‌شود، حتی اگر زیرِ انگشتت یک فیلدِ متن باشد.
     *
     * `[data-noback]` تنها استثناست: جایی که *خودِ* عنصر یک ژستِ
     * افقیِ ضروری دارد و حتی از لبه هم نباید دزدیده شود. */
    const blocked = fromEdge
      ? !!t?.closest?.("[data-noback]")
      : !!t?.closest?.("[data-hstrip],[data-noback],input,textarea,select");

    drag.current = {
      x0: e.clientX, y0: e.clientY, p0: p.x,
      hist: [{ t: performance.now(), x: e.clientX }],
      locked: false, fromEdge, blocked,
    };
  };

  /** سرعت روی پنجرهٔ `velWindow` — واحد: نسبتِ عرض بر ثانیه، منطقی */
  const velocity = (d: NonNullable<typeof drag.current>) => {
    const now = performance.now();
    const cut = now - GESTURE.velWindow;
    const first = d.hist.find((s) => s.t >= cut) ?? d.hist[0];
    const last = d.hist[d.hist.length - 1];
    const dt = last.t - first.t;
    if (dt < 8) return 0;
    return (((last.x - first.x) * DIR) / dt / w) * 1000;
  };

  const onPointerMove = (e: React.PointerEvent) => {
    const d = drag.current;
    if (!d || d.blocked) return;

    if (!d.locked) {
      const dx = (e.clientX - d.x0) * DIR;          // مثبت = به سمتِ بسته‌شدن
      const ay = Math.abs(e.clientY - d.y0);
      /* از لبه: کمترین آستانه. از وسطِ صفحه: هم مسافتِ بیشتر لازم است
         هم باید به‌روشنی افقی باشد، وگرنه اسکرولِ عمودی را می‌دزدد. */
      const need = d.fromEdge ? GESTURE.tabLock : GESTURE.anywhereLock;
      /* حدِ صبر تا وقتی هنوز قفل نشده. از لبه سخاوتمندانه‌تر است چون
         شست همیشه قوس می‌خورد و آنجا رقیبی جز اسکرول نیست. */
      const bail = d.fromEdge ? GESTURE.edgeBail : GESTURE.anywhereBail;
      if (dx < need) {
        /* حرکتِ عمودیِ قاطع یعنی کاربر دارد اسکرول می‌کند — کنار بکش */
        if (ay > bail) d.blocked = true;
        return;
      }
      if (!d.fromEdge && Math.abs(dx) < ay * GESTURE.axisRatio) return;
      d.locked = true;
      d.x0 = e.clientX;                       // از همین‌جا صفر کن، بدونِ پرش
      (e.currentTarget as HTMLElement).setPointerCapture(e.pointerId);
    }

    const now = performance.now();
    d.hist.push({ t: now, x: e.clientX });
    if (d.hist.length > 12) d.hist.shift();
    const logical = (e.clientX - d.x0) * DIR;
    p.set(Math.max(0, Math.min(1, d.p0 + logical / w)));
  };

  const finish = () => {
    const d = drag.current;
    if (!d) return;
    drag.current = null;
    if (!d.locked) return;                    // فقط یک لمس بود — دست نزن
    const vel = velocity(d);
    const commit = p.x > GESTURE.backCommit || vel > GESTURE.backFlick;
    const cancel = vel < GESTURE.backCancelFlick;
    if (commit && !cancel) {
      dead.current = true;
      p.springTo(1, vel, onPop);
    } else {
      p.springTo(0, vel);
    }
  };

  return (
    <div
      onPointerDown={onPointerDown}
      onPointerMove={onPointerMove}
      onPointerUp={finish}
      onPointerCancel={finish}
      style={{
        position: "absolute", inset: 0, zIndex: Z.push + depth,
        touchAction: "pan-y",
      }}
    >
      <div ref={veil} aria-hidden style={{
        position: "absolute", inset: 0, background: "#000",
        opacity: 0, pointerEvents: "none",
      }} />
      <div ref={layer} style={{ position: "absolute", inset: 0, willChange: "transform" }}>
        {children}
      </div>
    </div>
  );
}

/* ── لایهٔ تب با انیمیشنِ ورود ────────────────────────── */
export function TabLayer({ index, children }: { index: number; children: React.ReactNode }) {
  return (
    <div key={index} style={{
      position: "absolute", inset: 0, zIndex: Z.tab,
      animation: `tabIn 400ms ${EASE.ios} both`,
    }}>
      {children}
    </div>
  );
}

export { ApiCtx };
export type { Spring };
