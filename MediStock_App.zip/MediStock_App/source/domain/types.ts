/* آینهٔ دقیقِ schema.prisma — تا mock و APIِ واقعی جای هم عوض شوند */

export type Role = "MANAGER" | "FOUNDER" | "KEEPER" | "TECHNICIAN";
export type MoveType = "IN" | "OUT" | "TRANSFER";
export type Health = "ok" | "warn" | "crit";

export type Product = {
  id: number;
  nameFa: string;
  nameLat: string | null;
  categoryId: number | null;
  unit: string;            // همیشه «عدد»
  minQty: number | null;
  isDeleted: boolean;
};

export type Batch = {
  id: number;
  productId: number;
  lotCode: string;         // خودکار
  supplierId: number | null;
  expiry: string | null;   // میلادی «YYYY-MM»
  /** «این کالا اصلاً انقضا ندارد» — با `expiry: null` فرق دارد:
      null یعنی «هنوز وارد نشده»، این یعنی «وجود ندارد». */
  noExpiry?: boolean;
  entryDate: string | null;// ISO — تاریخِ ورود به انبار
  purchasedAt?: string | null; // ISO — تاریخِ خرید از تأمین‌کننده
  warehouseId: number;
  qty: number;
};

export type Movement = {
  id: number;
  batchId: number;
  type: MoveType;
  qty: number;
  reason: string | null;
  fromWarehouseId: number | null;
  toWarehouseId: number | null;
  userId: number;
  note: string | null;
  createdAt: string;
};

/**
 * دفترِ تغییرات — هر کاری که «حرکت» نیست ولی باید ردش بماند.
 *
 * حرکت‌ها (ورود/خروج/انتقال) خودشان تاریخچه دارند. اما اگر کسی
 * حداقلِ موجودی را عوض کند، کالایی را پاک کند، یا نقشِ کاربری را
 * بالا ببرد، هیچ‌جا ثبت نمی‌شد. برای داروخانه‌ای با چند کاربر،
 * «چه کسی این را عوض کرد؟» سؤالی است که یک روز پرسیده می‌شود.
 */
export type AuditKind =
  | "product.add" | "product.edit" | "product.remove"
  | "batch.remove" | "batch.setQty" | "batch.setExpiry"
  | "warehouse.add" | "warehouse.edit" | "warehouse.remove"
  | "supplier.add" | "supplier.edit" | "supplier.remove"
  | "category.add" | "category.edit" | "category.remove"
  | "reason.add" | "reason.edit" | "reason.remove"
  | "user.add" | "user.edit" | "user.remove" | "user.active" | "user.password"
  | "import" | "restore" | "settings" | "archive";

export type AuditEntry = {
  id: number;
  kind: AuditKind;
  /** آنچه دست خورده — نامِ خواندنی، نه شناسه */
  target: string;
  /** «۱۲ → ۳۰» یا هر توضیحِ کوتاهِ دیگر */
  detail: string;
  userId: number;
  createdAt: string;
};

/**
 * یک اختلافِ انبارگردانی که منتظرِ تأییدِ مدیر مانده.
 *
 * فقط وقتی ساخته می‌شود که مدیر «تأییدِ اختلاف» را روشن کرده باشد و
 * اختلاف از آستانه بزرگ‌تر باشد. اختلافِ کوچک همان‌جا اعمال می‌شود —
 * وگرنه انباردار برای هر یکی-دوتا معطلِ مدیر می‌ماند و کلِ قابلیت
 * تبدیل می‌شود به چیزی که همه خاموشش می‌کنند.
 */
export type CountRequest = {
  id: number;
  batchId: number;
  /** عکسِ لحظه‌ای — پارت ممکن است تا زمانِ تأیید عوض شده باشد */
  from: number;
  to: number;
  userId: number;
  createdAt: string;
};

export type Warehouse = {
  id: number;
  name: string;
  parentId: number | null;
  isActive: boolean;
  sortOrder: number;
};

export type Category = { id: number; name: string };
export type Supplier = { id: number; name: string };

export type User = {
  id: number;
  username: string;
  role: Role;
  fullName: string | null;
  initials: string;
  isActive: boolean;
};

/** ردیفِ فشردهٔ کاتالوگ — آرایه‌ای، نه شیء، برای حجمِ کمتر */
export type CatalogRow = {
  i: number;      // id
  n: string;      // nameFa
  l: string;      // nameLat
  c: string;      // category
  q: number;      // موجودی (مشتق)
  s: Health;      // وضعیت
  k: string;      // کلیدِ جست‌وجویِ نرمال‌شده
  /** حداقلِ موجودی — کارفرما گفت دستی وارد می‌شود. null یعنی تعیین‌نشده. */
  m: number | null;
  /**
   * کدِ کالا — چهار رقمِ صفرپیشوند («0001»).
   *
   * کارفرما در فهرستِ خواسته‌هایش نوشت «کد دارو … که اگر دو داروی
   * یکسان تاریخ انقضاشون فرق داشت بتونیم تفکیک کنیم». همین کد است که
   * روی برچسبِ QR چاپ می‌شود و با دوربین اسکن می‌شود.
   */
  d: string;
  /** توضیحاتِ کالا — اختیاری */
  n2?: string;
};

/** بارِ QRِ برچسب — پیشوند دارد تا با QRهای دیگرِ دنیا اشتباه نشود */
export const qrPayload = (code: string) => `MS-${code}`;

/** «MS-0042» یا «0042» → «0042». هرچه نخواند `null`. */
export function codeFromScan(raw: string): string | null {
  const s = raw.trim().toUpperCase();
  const m = /^(?:MS-)?(\d{1,6})$/.exec(s);
  return m ? m[1].padStart(4, "0") : null;
}
