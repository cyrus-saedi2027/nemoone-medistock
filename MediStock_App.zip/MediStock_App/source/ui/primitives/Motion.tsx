/* ورودهای کوچک — فقط transform/opacity، همه روی GPU */

import * as React from "react";
import { EASE } from "@/system/tokens";

/** محو + بالا آمدن؛ با key عوض‌شونده دوباره اجرا می‌شود */
export function Fade({
  children, y = 6, dur = 300, delay = 0, style,
}: { children: React.ReactNode; y?: number; dur?: number; delay?: number; style?: React.CSSProperties }) {
  const [on, setOn] = React.useState(false);
  React.useEffect(() => {
    const id = requestAnimationFrame(() => setOn(true));
    return () => cancelAnimationFrame(id);
  }, []);
  return (
    <div style={{
      opacity: on ? 1 : 0,
      transform: on ? "none" : `translate3d(0,${y}px,0)`,
      transition: `opacity ${dur}ms ${EASE.out} ${delay}ms, transform ${dur}ms ${EASE.out} ${delay}ms`,
      ...style,
    }}>{children}</div>
  );
}

/**
 * ورودِ پلکانی برای فهرست‌های کوتاه.
 * عمداً دورِ ردیف‌های لیستِ مجازی نمی‌پیچد — آنجا هر بار که ردیف
 * وارد دید می‌شود دوباره اجرا می‌شد و اسکرول را می‌لرزاند.
 */
export function Reveal({
  children, i = 0, step = 42, y = 10, style,
}: { children: React.ReactNode; i?: number; step?: number; y?: number; style?: React.CSSProperties }) {
  return (
    <div style={{
      animation: `revealIn 420ms ${EASE.out} ${Math.min(i * step, 380)}ms both`,
      ["--rv-y" as any]: `${y}px`,
      ...style,
    }}>{children}</div>
  );
}
