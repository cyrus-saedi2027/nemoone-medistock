import * as React from "react";
import { EASE } from "@/system/tokens";
import { TAP } from "@/system/haptics";

type Props = {
  children: React.ReactNode;
  onPress?: () => void;
  scale?: number;
  haptic?: boolean;
  disabled?: boolean;
  style?: React.CSSProperties;
  as?: "button" | "div";
  ariaLabel?: string;
  /** برای تبِ فعال — بدونِ این، صفحه‌خوان نمی‌فهمد کجاییم */
  ariaCurrent?: "page" | "step" | "true";
  /** برای کلیدِ روشن/خاموش — بدونِ این، حالتش فقط رنگ است */
  role?: string;
  ariaChecked?: boolean;
};

/**
 * نکتهٔ باربر: شنوندهٔ pointerup روی window.
 * وقتی والد (پنِ تب یا سوایپِ ردیف) اشاره‌گر را می‌قاپد، فرزند
 * هیچ‌وقت pointerup خودش را نمی‌گیرد و در حالتِ فشرده گیر می‌کند.
 */
export function Pressable({
  children, onPress, scale = 0.955, haptic = true, disabled, style, as = "button",
  ariaLabel, ariaCurrent, role, ariaChecked,
}: Props) {
  const [down, setDown] = React.useState(false);

  React.useEffect(() => {
    if (!down) return;
    const up = () => setDown(false);
    window.addEventListener("pointerup", up);
    window.addEventListener("pointercancel", up);
    return () => {
      window.removeEventListener("pointerup", up);
      window.removeEventListener("pointercancel", up);
    };
  }, [down]);

  const Tag = as as any;
  return (
    <Tag
      type={as === "button" ? "button" : undefined}
      aria-label={ariaLabel}
      aria-current={ariaCurrent}
      role={role}
      aria-checked={ariaChecked}
      disabled={disabled}
      onPointerDown={() => { if (disabled) return; setDown(true); if (haptic) TAP(); }}
      onClick={() => { if (!disabled) onPress?.(); }}
      style={{
        appearance: "none", border: 0, background: "none", padding: 0, margin: 0,
        font: "inherit", color: "inherit", cursor: disabled ? "default" : "pointer",
        textAlign: "start", WebkitTapHighlightColor: "transparent",
        transform: down ? `scale(${scale})` : "none",
        transition: `transform 280ms ${EASE.out}`,
        opacity: disabled ? 0.45 : 1,
        ...style,
      }}
    >
      {children}
    </Tag>
  );
}
