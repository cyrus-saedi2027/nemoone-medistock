/* آیکون‌های درون‌خطی — بدونِ وابستگی، بدونِ درخواستِ شبکه.
 * جهتِ chevron یک‌بار از DIR حل می‌شود. */

import * as React from "react";
import { IS_RTL } from "@/system/dir";

type P = { size?: number; stroke?: number; color?: string; style?: React.CSSProperties };
const S = ({ size = 20, stroke = 1.9, color, style, d }: P & { d: React.ReactNode }) => (
  <svg width={size} height={size} viewBox="0 0 24 24" fill="none" stroke={color ?? "currentColor"}
       strokeWidth={stroke} strokeLinecap="round" strokeLinejoin="round"
       style={{ flex: "none", ...style }}>{d}</svg>
);

export const IconHome = (p: P) => <S {...p} d={<><path d="M3 10.2 12 3l9 7.2V20a1.5 1.5 0 0 1-1.5 1.5h-15A1.5 1.5 0 0 1 3 20z"/><path d="M9 21.5V13h6v8.5"/></>} />;
export const IconGrid = (p: P) => <S {...p} d={<><rect x="3" y="3" width="7.5" height="7.5" rx="2"/><rect x="13.5" y="3" width="7.5" height="7.5" rx="2"/><rect x="3" y="13.5" width="7.5" height="7.5" rx="2"/><rect x="13.5" y="13.5" width="7.5" height="7.5" rx="2"/></>} />;
export const IconBox = (p: P) => <S {...p} d={<><rect x="3" y="7" width="18" height="14" rx="2"/><path d="M3 11h18M2 4h20v3H2z"/></>} />;
export const IconBell = (p: P) => <S {...p} d={<><path d="M18 8a6 6 0 1 0-12 0c0 6-3 7-3 7h18s-3-1-3-7"/><path d="M13.7 21a2 2 0 0 1-3.4 0"/></>} />;
export const IconUser = (p: P) => <S {...p} d={<><circle cx="12" cy="8" r="4"/><path d="M4.5 21a7.5 7.5 0 0 1 15 0"/></>} />;
export const IconPlus = (p: P) => <S {...p} d={<path d="M12 5v14M5 12h14"/>} />;
export const IconSearch = (p: P) => <S {...p} d={<><circle cx="11" cy="11" r="7"/><path d="m20 20-3.6-3.6"/></>} />;
export const IconFilter = (p: P) => <S {...p} d={<path d="M4 6h16M7 12h10M10 18h4"/>} />;
export const IconIn = (p: P) => <S {...p} d={<><path d="M12 3v11"/><path d="m7.5 9.5 4.5 4.5 4.5-4.5"/><path d="M4 17v2.5A1.5 1.5 0 0 0 5.5 21h13a1.5 1.5 0 0 0 1.5-1.5V17"/></>} />;
export const IconOut = (p: P) => <S {...p} d={<><path d="M12 14V3"/><path d="m7.5 7.5 4.5-4.5 4.5 4.5"/><path d="M4 17v2.5A1.5 1.5 0 0 0 5.5 21h13a1.5 1.5 0 0 0 1.5-1.5V17"/></>} />;
export const IconSwap = (p: P) => <S {...p} d={<path d="M4 8h13l-3.5-3.5M20 16H7l3.5 3.5"/>} />;
export const IconWarn = (p: P) => <S {...p} d={<><path d="M12 3.5 22 20H2z"/><path d="M12 10v4M12 17.2v.1"/></>} />;
export const IconClock = (p: P) => <S {...p} d={<><circle cx="12" cy="12" r="9"/><path d="M12 7v5.2l3.2 2"/></>} />;
export const IconPill = (p: P) => <S {...p} d={<><rect x="2.5" y="8" width="19" height="8" rx="4"/><path d="M12 8v8"/></>} />;
export const IconMortar = (p: P) => <S {...p} d={<><path d="M5 9h14l-1.6 9.2a2 2 0 0 1-2 1.8H8.6a2 2 0 0 1-2-1.8z"/><path d="M4 6h16M12 3v3"/></>} />;
export const IconShelf = (p: P) => <S {...p} d={<><rect x="3" y="3" width="18" height="18" rx="2.5"/><path d="M3 9h18M3 15h18"/></>} />;
export const IconTruck = (p: P) => <S {...p} d={<><path d="M2 7h11v9H2zM13 10h4l3 3v3h-7"/><circle cx="6" cy="18.5" r="1.8"/><circle cx="17" cy="18.5" r="1.8"/></>} />;
export const IconChart = (p: P) => <S {...p} d={<path d="M5 20V11M12 20V4M19 20v-6"/>} />;
export const IconCloud = (p: P) => <S {...p} d={<><path d="M6.5 18a4 4 0 0 1 .3-8 5.5 5.5 0 0 1 10.5 1.4A3.6 3.6 0 0 1 17.5 18z"/><path d="M12 12v5M9.8 14.8 12 17l2.2-2.2"/></>} />;
export const IconFile = (p: P) => <S {...p} d={<><path d="M14 3H7a2 2 0 0 0-2 2v14a2 2 0 0 0 2 2h10a2 2 0 0 0 2-2V8z"/><path d="M14 3v5h5"/></>} />;
export const IconGear = (p: P) => <S {...p} d={<><circle cx="12" cy="12" r="3"/><path d="M19.4 14.5a1.7 1.7 0 0 0 .34 1.87l.06.06a2 2 0 1 1-2.83 2.83l-.06-.06a1.7 1.7 0 0 0-1.87-.34 1.7 1.7 0 0 0-1.03 1.56V21a2 2 0 1 1-4 0v-.1a1.7 1.7 0 0 0-1.11-1.56 1.7 1.7 0 0 0-1.87.34l-.06.06a2 2 0 1 1-2.83-2.83l.06-.06a1.7 1.7 0 0 0 .34-1.87 1.7 1.7 0 0 0-1.56-1.03H3a2 2 0 1 1 0-4h.1a1.7 1.7 0 0 0 1.56-1.11 1.7 1.7 0 0 0-.34-1.87l-.06-.06a2 2 0 1 1 2.83-2.83l.06.06a1.7 1.7 0 0 0 1.87.34H9a1.7 1.7 0 0 0 1.03-1.56V3a2 2 0 1 1 4 0v.1a1.7 1.7 0 0 0 1.03 1.56 1.7 1.7 0 0 0 1.87-.34l.06-.06a2 2 0 1 1 2.83 2.83l-.06.06a1.7 1.7 0 0 0-.34 1.87V9a1.7 1.7 0 0 0 1.56 1.03H21a2 2 0 1 1 0 4h-.1a1.7 1.7 0 0 0-1.5 1.03z"/></>} />;
export const IconList = (p: P) => <S {...p} d={<path d="M8 6h13M8 12h13M8 18h13M3.5 6h.01M3.5 12h.01M3.5 18h.01"/>} />;
export const IconCheck = (p: P) => <S {...p} stroke={2.5} d={<path d="m4 12.5 5.2 5.5L20 6.5"/>} />;
export const IconX = (p: P) => <S {...p} d={<path d="M18 6 6 18M6 6l12 12"/>} />;

export const IconEdit = (p: P) => <S {...p} d={<><path d="M4 20h4l10.5-10.5a2.1 2.1 0 0 0-3-3L5 17z"/><path d="M14.5 6.5l3 3"/></>} />;
export const IconTrash = (p: P) => <S {...p} d={<><path d="M4 7h16M9 7V5h6v2M6 7l1 13h10l1-13"/><path d="M10 11v6M14 11v6"/></>} />;
export const IconMore = (p: P) => <S {...p} stroke={2.4} d={<path d="M5 12h.01M12 12h.01M19 12h.01"/>} />;
export const IconCal = (p: P) => <S {...p} d={<><rect x="3" y="5" width="18" height="16" rx="2.5"/><path d="M3 10h18M8 3v4M16 3v4"/></>} />;
export const IconTag = (p: P) => <S {...p} d={<><path d="M3 12.5V4h8.5L21 13.5 12.5 22z"/><circle cx="7.5" cy="8" r="1.4"/></>} />;
export const IconShield = (p: P) => <S {...p} d={<><path d="M12 3l7.5 3v6c0 4.5-3 7.7-7.5 9.5C7.5 19.7 4.5 16.5 4.5 12V6z"/><path d="m9 12 2.2 2.2L15.5 10"/></>} />;
export const IconLogout = (p: P) => <S {...p} d={<><path d="M14 4h4.5A1.5 1.5 0 0 1 20 5.5v13a1.5 1.5 0 0 1-1.5 1.5H14"/><path d="M10 8 6 12l4 4M6 12h9"/></>} />;
export const IconUsers = (p: P) => <S {...p} d={<><circle cx="9" cy="8" r="3.4"/><path d="M2.8 20a6.2 6.2 0 0 1 12.4 0"/><path d="M16 5.2a3.4 3.4 0 0 1 0 6.6M17.4 14.4A6.2 6.2 0 0 1 21.2 20"/></>} />;
export const IconBuilding = (p: P) => <S {...p} d={<><rect x="4" y="3" width="16" height="18" rx="2"/><path d="M9 7h.01M15 7h.01M9 11h.01M15 11h.01M9 15h.01M15 15h.01"/></>} />;
export const IconRefresh = (p: P) => <S {...p} d={<><path d="M20 12a8 8 0 1 1-2.6-5.9"/><path d="M20 4v4.5h-4.5"/></>} />;
export const IconMinus = (p: P) => <S {...p} stroke={2.2} d={<path d="M5 12h14"/>} />;
export const IconInfo = (p: P) => <S {...p} d={<><circle cx="12" cy="12" r="9"/><path d="M12 11v5.5M12 7.8v.1"/></>} />;
export const IconSend = (p: P) => <S {...p} d={<><path d="M21 3 10.5 13.5"/><path d="M21 3 14.5 21 10.5 13.5 3 9.5z"/></>} />;
export const IconEye = (p: P) => <S {...p} d={<><path d="M2.5 12S6 5.5 12 5.5 21.5 12 21.5 12 18 18.5 12 18.5 2.5 12 2.5 12"/><circle cx="12" cy="12" r="3"/></>} />;
export const IconEyeOff = (p: P) => <S {...p} d={<><path d="M4 4l16 16"/><path d="M9.5 9.6A3 3 0 0 0 12 15a3 3 0 0 0 2.4-1.2"/><path d="M6.3 6.5C3.9 8.1 2.5 12 2.5 12s3.5 6.5 9.5 6.5c1.5 0 2.8-.4 3.9-1M17.4 16C19.9 14.4 21.5 12 21.5 12S18 5.5 12 5.5c-.8 0-1.5.1-2.2.3"/></>} />;
export const IconLock = (p: P) => <S {...p} d={<><rect x="4.5" y="10" width="15" height="11" rx="2.5"/><path d="M8 10V7.5a4 4 0 0 1 8 0V10"/></>} />;
export const IconPalette = (p: P) => <S {...p} d={<><path d="M12 3a9 9 0 1 0 0 18c1.2 0 1.8-.9 1.8-1.8 0-1.5-1.3-1.8-1.3-3 0-.9.8-1.6 1.8-1.6H17a4 4 0 0 0 4-4c0-4.2-4-7.6-9-7.6"/><circle cx="7.5" cy="11" r="1.2"/><circle cx="10" cy="7" r="1.2"/><circle cx="15" cy="7.6" r="1.2"/></>} />;
export const IconDownload = (p: P) => <S {...p} d={<><path d="M12 3v11"/><path d="m7.5 9.5 4.5 4.5 4.5-4.5"/><path d="M4 18.5v1A1.5 1.5 0 0 0 5.5 21h13a1.5 1.5 0 0 0 1.5-1.5v-1"/></>} />;
export const IconUpload = (p: P) => <S {...p} d={<><path d="M12 15V4"/><path d="m7.5 8.5 4.5-4.5 4.5 4.5"/><path d="M4 18.5v1A1.5 1.5 0 0 0 5.5 21h13a1.5 1.5 0 0 0 1.5-1.5v-1"/></>} />;
/** بارکدِ دوبعدی — سه چشمِ گوشه، همان چیزی که روی برچسب است */
export const IconQr = (p: P) => <S {...p} d={<><rect x="3" y="3" width="7" height="7" rx="1.5"/><rect x="14" y="3" width="7" height="7" rx="1.5"/><rect x="3" y="14" width="7" height="7" rx="1.5"/><path d="M14 14h3v3h-3zM18 18h3v3h-3zM14 21h1M21 14h.01"/></>} />;
export const IconPrint = (p: P) => <S {...p} d={<><path d="M7 8V3h10v5"/><rect x="3" y="8" width="18" height="8" rx="2"/><path d="M7 14h10v7H7z"/></>} />;
export const IconHistory = (p: P) => <S {...p} d={<><path d="M3.5 12a8.5 8.5 0 1 0 2.6-6.1"/><path d="M3.5 4.5V9H8"/><path d="M12 7.5V12l3 1.8"/></>} />;
export const IconSort = (p: P) => <S {...p} d={<path d="M7 4v16m0 0-3-3m3 3 3-3M17 20V4m0 0-3 3m3-3 3 3"/>} />;
export const IconCopy = (p: P) => <S {...p} d={<><rect x="8" y="8" width="12" height="12" rx="2.5"/><path d="M16 8V6a2 2 0 0 0-2-2H6a2 2 0 0 0-2 2v8a2 2 0 0 0 2 2h2"/></>} />;

const Left = (p: P) => <S {...p} d={<path d="m14 6-6 6 6 6"/>} />;
const Right = (p: P) => <S {...p} d={<path d="m10 6 6 6-6 6"/>} />;

/** «برگشت» — در RTL فلش به راست */
export const IconBack = IS_RTL ? Right : Left;
/** «جلو / باز کردن» — در RTL فلش به چپ */
export const IconForward = IS_RTL ? Left : Right;
