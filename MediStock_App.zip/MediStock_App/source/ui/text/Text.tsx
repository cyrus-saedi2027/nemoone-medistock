/* ─────────────────────────────────────────────────────────────
 *  دیوارِ آتشِ تایپوگرافی
 *
 *  رفرنس ۴۹ جا letterSpacing روی برچسب‌های ریزِ انگلیسیِ حروف‌بزرگ
 *  داشت. در فارسی این دستگاهِ بصری وجود ندارد: فاصله‌گذاریِ حروف،
 *  اتصالِ خطِ فارسی را می‌شکند و «حروف بزرگ» هم نداریم.
 *
 *  پس letterSpacing از کلِ کدبیس حذف شده و هر متنی از اینجا رد
 *  می‌شود. جای آن، «برچسبِ ریز» با نقطهٔ رنگیِ کوچک و رنگِ محو
 *  ساخته می‌شود — و دستگاهِ اصلیِ رفرنس به نامِ لاتینِ داروها
 *  واگذار شده که آنجا درست و طبیعی است (<Lat>).
 * ───────────────────────────────────────────────────────────── */

import * as React from "react";
import { v } from "@/system/theme/ThemeProvider";
import { toFa } from "@/system/i18n/digits";

type Common = { children?: React.ReactNode; style?: React.CSSProperties; className?: string };

export const Title = ({ children, style, ...r }: Common) => (
  <div {...r} style={{ fontSize: 21, fontWeight: 800, lineHeight: 1.45, letterSpacing: 0,
                       color: v("ink"), ...style }}>{children}</div>
);

export const Head = ({ children, style, ...r }: Common) => (
  <div {...r} style={{ fontSize: 16, fontWeight: 800, lineHeight: 1.5, letterSpacing: 0,
                       color: v("ink"), ...style }}>{children}</div>
);

export const Body = ({ children, style, ...r }: Common) => (
  <div {...r} style={{ fontSize: 13.5, fontWeight: 500, lineHeight: 1.75, letterSpacing: 0,
                       color: v("inkMuted"), ...style }}>{children}</div>
);

/** برچسبِ ریز — جایگزینِ فارسیِ «eyebrow»ِ حروف‌بزرگِ رفرنس */
export const Cap = ({ children, dot, style, ...r }: Common & { dot?: string }) => (
  <div {...r} style={{ display: "inline-flex", alignItems: "center", gap: 6,
                       fontSize: 10.5, fontWeight: 700, letterSpacing: 0,
                       color: v("inkFaint"), ...style }}>
    {dot && <i style={{ width: 5, height: 5, borderRadius: 99, background: dot, flex: "none" }} />}
    {children}
  </div>
);

/**
 * نامِ لاتین / کدِ پارت / نام‌کاربری.
 * اینجا letterSpacing زنده می‌ماند — دستگاهِ بصریِ رفرنس گم نشده،
 * فقط به جایی منتقل شده که واقعاً لاتین است.
 */
export const Lat = ({ children, style, ...r }: Common) => (
  <bdi {...r} dir="ltr" style={{ unicodeBidi: "isolate", fontSize: 11.5, fontWeight: 700,
                                 letterSpacing: "0.06em", color: v("inkFaint"),
                                 ...style }}>{children}</bdi>
);

/**
 * کدِ کالا — همیشه با `#` و همیشه لاتین.
 *
 * چرا کامپوننتِ جدا و نه یک رشتهٔ دستی در هر صفحه: کد در هفت جای
 * مختلف نوشته می‌شود (صفحهٔ کالا، فهرست، برچسب، اکسل، ثبتِ گروهی،
 * انبارگردانی، دفترِ تغییرات). هر جا که یادمان برود، کاربر یک نمایشِ
 * دیگر می‌بیند و فکر می‌کند دو چیزِ متفاوت است.
 *
 * `#` عمداً *بیرونِ* رقم‌هاست ولی داخلِ همان `bdi`: اگر بیرون بماند،
 * موتورِ دوجهته در متنِ فارسی آن را به سمتِ دیگرِ عدد پرت می‌کند.
 * ارقام هم عمداً لاتین می‌مانند نه فارسی — کد شناسه است، نه کمیت؛
 * همان چیزی که روی برچسب چاپ و با دوربین اسکن می‌شود.
 */
export const Code = ({ code, style, ...r }: Common & { code: string | number }) => (
  <bdi {...r} dir="ltr" style={{ unicodeBidi: "isolate", fontSize: 11.5, fontWeight: 800,
                                 letterSpacing: "0.04em", fontVariantNumeric: "tabular-nums",
                                 color: v("inkMuted"), ...style }}>
    {codeText(code)}
  </bdi>
);

/** همان کد به‌صورتِ رشتهٔ ساده — برای اکسل، برچسب، و متنِ لاگ */
export const codeText = (code: string | number) => `#${code}`;

/**
 * عدد — رقمِ فارسی، عرضِ ثابت، و همیشه داخل bdi.
 * نمونهٔ قبلی اثبات کرد که بدونِ bdi، «‎+۱۰» به‌صورتِ «۱۰+» رندر می‌شود.
 */
export const Num = ({
  value, group = true, style, ...r
}: Common & { value: number | string; group?: boolean }) => (
  <bdi {...r} style={{ unicodeBidi: "isolate", fontVariantNumeric: "tabular-nums",
                       fontWeight: 800, letterSpacing: 0, ...style }}>
    {toFa(value, group)}
  </bdi>
);
