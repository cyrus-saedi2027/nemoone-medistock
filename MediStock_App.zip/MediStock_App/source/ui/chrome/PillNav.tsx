/* ─────────────────────────────────────────────────────────────
 *  نوارِ قرصیِ شناور — برداشته از نمونهٔ اولیه (04- Design/prototype)
 *
 *  یک قرصِ تیره وسطِ پایینِ صفحه. آیتمِ غیرفعال فقط آیکون است؛
 *  آیتمِ فعال باز می‌شود، پس‌زمینهٔ سفید می‌گیرد و برچسبش را نشان
 *  می‌دهد.
 *
 *  ترفندِ باز شدن: عرضِ برچسب با `grid-template-columns: 0fr → 1fr`
 *  انیمیت می‌شود. این تنها راهِ انیمیت‌کردنِ «از هیچ تا اندازهٔ محتوا»
 *  است؛ `width: auto` قابلِ transition نیست و با `max-width` حرکت
 *  کش‌دار و بدریتم می‌شود.
 * ───────────────────────────────────────────────────────────── */

import * as React from "react";
import { v } from "@/system/theme/ThemeProvider";
import { EASE, Z, SHADOW } from "@/system/tokens";
import { Pressable } from "@/ui/primitives/Pressable";
import { SELECT } from "@/system/haptics";
import { NAV } from "@/system/geometry/backdrop";

export type NavItem = { key: string; fa: string; Icon: React.ComponentType<any> };

/** فنرِ نرم برای باز شدنِ آیتم — همان حسِ نمونه */
const SPRING = "cubic-bezier(.34,1.56,.64,1)";

export function PillNav({
  items, index, onSelect,
}: {
  items: NavItem[]; index: number; onSelect: (i: number) => void;
}) {
  return (
    <div style={{
      /* `NAV.gap` و `NAV.pillH` جای دیگری هم خوانده می‌شوند (مرزِ محو).
         عددِ درون‌خطی اینجا یعنی آن مرز بی‌صدا از قرص جدا می‌افتد. */
      position: "absolute", insetInline: 0, bottom: NAV.gap, zIndex: Z.nav,
      display: "flex", justifyContent: "center", pointerEvents: "none",
    }}>
      <div style={{
        pointerEvents: "auto", display: "flex", alignItems: "center", gap: 2,
        background: v("deepGrad"), border: `1px solid ${v("navEdge")}`,
        borderRadius: 999, padding: 6, boxShadow: SHADOW.nav,
        maxWidth: "calc(100% - 24px)",
      }}>
        {items.map((it, i) => {
          const on = i === index;
          return (
            <Pressable
              key={it.key}
              onPress={() => { if (!on) SELECT(); onSelect(i); }}
              haptic={false}
              scale={0.93}
              ariaLabel={it.fa}
              ariaCurrent={on ? "page" : undefined}
              style={{
                display: "flex", flexDirection: "row", alignItems: "center", gap: on ? 6 : 0,
                minHeight: 42, paddingBlock: 11,
                paddingInline: on ? 15 : 10,
                borderRadius: 999, whiteSpace: "nowrap",
                background: on ? v("card") : "transparent",
                color: on ? v("ink") : v("navInk"),
                transition:
                  `background 380ms ${SPRING}, color 260ms ${EASE.out}, ` +
                  `padding 340ms ${SPRING}, gap 340ms ${SPRING}`,
              }}
            >
              <it.Icon size={19} stroke={2.05} />
              <span style={{
                display: "grid",
                gridTemplateColumns: on ? "1fr" : "0fr",
                overflow: "hidden",
                fontSize: 11.5, fontWeight: 900,
                opacity: on ? 1 : 0,
                transition: `grid-template-columns 380ms ${SPRING}, opacity 260ms ${EASE.out}`,
              }}>
                <span style={{ minWidth: 0, overflow: "hidden" }}>{it.fa}</span>
              </span>
            </Pressable>
          );
        })}
      </div>
    </div>
  );
}
