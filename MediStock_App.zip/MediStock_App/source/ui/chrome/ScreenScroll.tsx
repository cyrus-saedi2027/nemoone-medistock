/* ─────────────────────────────────────────────────────────────
 *  ظرفِ اسکرولِ صفحه
 *
 *  دو کار می‌کند:
 *   ۱) کششِ الاستیک در دو سر (مرورگر در PWA چیزی نمی‌دهد).
 *   ۲) کشیدن به پایین = تازه‌سازی.
 *
 *  دیگر ماسک نمی‌زند: محتوا زیرِ نوار *بریده* نمی‌شود، فقط با
 *  `NavScrim` کمی عقب می‌نشیند.
 *
 *  جابه‌جاییِ کشش مستقیم روی DOM نوشته می‌شود — صفر رندر.
 * ───────────────────────────────────────────────────────────── */

import * as React from "react";
import { useSpringRef, useSpringBind } from "@/system/motion/useSpring";
import { useFrame } from "@/system/frame";
import { contentBottom } from "@/system/geometry/backdrop";
import { MOTION, GESTURE } from "@/system/tokens";
import { IMPACT } from "@/system/haptics";
import { v } from "@/system/theme/ThemeProvider";

export const ScrollTopCtx = React.createContext(0);

export function ScreenScroll({
  children, onRefresh, padTop = 0,
}: {
  children: React.ReactNode;
  onRefresh?: () => void;
  padTop?: number;
}) {
  const { h } = useFrame();
  const scroller = React.useRef<HTMLDivElement>(null);
  const [busy, setBusy] = React.useState(false);
  const bounce = useSpringRef(0, MOTION.bounce);

  const inner = useSpringBind<HTMLDivElement>(bounce, (el, x) => {
    el.style.transform = `translate3d(0,${x.toFixed(2)}px,0)`;
  });

  const touch = React.useRef<
    { y: number; y0: number; x0: number; at: "top" | "bottom" | null; axis: "" | "x" | "y" } | null
  >(null);
  const relax = React.useRef<number | undefined>(undefined);

  const ends = (el: HTMLElement) => ({
    top: el.scrollTop <= 0,
    bottom: el.scrollTop + el.clientHeight >= el.scrollHeight - 1,
  });

  const settle = React.useCallback(() => {
    window.clearTimeout(relax.current);
    relax.current = window.setTimeout(() => {
      if (onRefresh && bounce.x > 66 && !busy) {
        IMPACT();
        setBusy(true);
        bounce.springTo(48);
        window.setTimeout(() => {
          setBusy(false);
          bounce.springTo(0);
          onRefresh();
        }, 780);
        return;
      }
      bounce.springTo(0);
    }, 70);
  }, [bounce, busy, onRefresh]);

  const onTouchStart = (e: React.TouchEvent) => {
    const el = e.currentTarget as HTMLElement;
    const { top, bottom } = ends(el);
    const p = e.touches[0];
    /* اگر انگشت داخلِ یک نوارِ افقی پایین آمده، از همان اول محورش را
       «x» می‌گیریم. بدونِ این، اولین چند پیکسلِ حرکت — که همیشه کمی
       عمودی هم هست — کششِ الاستیک را روشن می‌کرد و کلِ صفحه یک تکان
       می‌خورد. همان «یهو می‌پره». */
    const inStrip = !!(p.target as HTMLElement | null)?.closest?.("[data-hstrip]");
    touch.current = {
      y: p.clientY, y0: p.clientY, x0: p.clientX,
      at: top ? "top" : bottom ? "bottom" : null,
      axis: inStrip ? "x" : "",
    };
  };

  const onTouchMove = (e: React.TouchEvent) => {
    const t = touch.current;
    if (!t) return;
    const el = e.currentTarget as HTMLElement;
    const p = e.touches[0];

    /* محورِ غالب یک‌بار قفل می‌شود و تا آخرِ ژست عوض نمی‌شود.
       آستانهٔ ۸ پیکسل: کمتر از این، لرزشِ انگشت محور را تعیین می‌کند. */
    if (!t.axis) {
      const ax = Math.abs(p.clientX - t.x0);
      const ay = Math.abs(p.clientY - t.y0);
      if (Math.max(ax, ay) > 8) t.axis = ax > ay ? "x" : "y";
    }
    if (t.axis === "x") {
      if (bounce.x !== 0) bounce.springTo(0);
      t.y = p.clientY;
      return;
    }

    const dy = p.clientY - t.y;
    const { top, bottom } = ends(el);
    const pulling = (top && dy > 0) || (bottom && dy < 0);
    if (!pulling) {
      if (bounce.x !== 0) bounce.springTo(0);
      t.at = top ? "top" : bottom ? "bottom" : null;
      t.y = p.clientY;
      return;
    }
    bounce.set(dy * GESTURE.rubber);
  };

  const onTouchEnd = () => { touch.current = null; settle(); };

  const onWheel = (e: React.WheelEvent) => {
    const el = e.currentTarget as HTMLElement;
    const { top, bottom } = ends(el);
    if ((top && e.deltaY < 0) || (bottom && e.deltaY > 0)) {
      bounce.set(bounce.x - e.deltaY * 0.22);
      settle();
    }
  };

  return (
    <div
      ref={scroller}
      onTouchStart={onTouchStart}
      onTouchMove={onTouchMove}
      onTouchEnd={onTouchEnd}
      onTouchCancel={onTouchEnd}
      onWheel={onWheel}
      style={{
        position: "absolute", inset: 0, overflowY: "auto", overflowX: "hidden",
        WebkitOverflowScrolling: "touch", overscrollBehavior: "contain",
      }}
    >
      {/* نشانگرِ تازه‌سازی — پشتِ محتوا، فقط وقتی کشیده شده دیده می‌شود */}
      {onRefresh && (
        <div style={{
          position: "absolute", insetInlineStart: 0, insetInlineEnd: 0, top: 10,
          display: "grid", placeItems: "center", pointerEvents: "none",
        }}>
          <div style={{
            width: 22, height: 22, borderRadius: 99,
            border: `2px solid ${v("inkFaint")}`, borderTopColor: "transparent",
            opacity: busy ? 1 : 0,
            animation: busy ? "spin 700ms linear infinite" : "none",
            transition: "opacity 180ms",
          }} />
        </div>
      )}
      <div ref={inner} style={{ paddingTop: padTop, paddingBottom: contentBottom(h), willChange: "transform" }}>
        {children}
      </div>
    </div>
  );
}
