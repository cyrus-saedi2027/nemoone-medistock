/* ─────────────────────────────────────────────────────────────
 *  نوارِ هشدارِ آفلاین
 *
 *  محمد خواست لحنش *هشدار* باشد: «آفلاینی، کار نکن» — نه توضیحِ
 *  فنیِ اینکه بعداً همگام می‌شود. صف پشتِ صحنه کارش را می‌کند؛
 *  کاربر لازم نیست به آن اتکا کند.
 *
 *  بالای همه‌چیز می‌نشیند ولی جای محتوا را نمی‌گیرد — سرصفحه‌ها
 *  `paddingTop` دارند و یک نوارِ ۳۴پیکسلی رویشان می‌نشیند.
 * ───────────────────────────────────────────────────────────── */

import * as React from "react";
import { v } from "@/system/theme/ThemeProvider";
import { Z, EASE } from "@/system/tokens";
import { IconWarn } from "@/ui/icons";
import { useOnline } from "@/system/online";
import { onSync, type SyncState } from "@/store/sync";
import { onPersistError } from "@/store/persist";
import { Num } from "@/ui/text/Text";
import { PendingSheet } from "@/ui/chrome/PendingSheet";

export function OfflineBar() {
  const online = useOnline();
  const [sync, setSync] = React.useState<SyncState | null>(null);
  React.useEffect(() => onSync(setSync), []);
  /* حافظهٔ گوشی پر شده و دیگر چیزی روی دیسک نمی‌نشیند. تا امروز این
     بی‌صدا بود: کاربر ثبت می‌کرد، اپ را می‌بست، و ثبتش نبود. */
  const [store, setStore] = React.useState<"quota" | "blocked" | null>(null);
  React.useEffect(() => onPersistError(setStore), []);
  const queued = sync?.queued ?? 0;
  /* A dead session looks exactly like a stuck queue from the outside,
     and for eight days that is all the pharmacy was told: a number
     that went up and never came down. It needs its own sentence and
     it needs to say what to do about it. */
  const expired = !!sync?.authExpired;
  const [list, setList] = React.useState(false);

  /* وقتی اتصال برگشت ولی صف هنوز خالی نشده، نوار می‌ماند — با لحنِ
     آرام‌تر. ناپدیدشدنش در حالی که چیزی ثبت‌نشده مانده، دروغ است. */
  const show = !online || queued > 0 || !!store || expired;
  if (!show) return null;

  const warn = !online || !!store || expired;
  /* Tapping the bar opens what is actually waiting. A bare count is
     not something the owner of the stock can check against a shelf. */
  const canOpen = queued > 0;
  return (
    <>
    <div
      role={canOpen ? "button" : "status"}
      onClick={canOpen ? () => setList(true) : undefined}
      tabIndex={canOpen ? 0 : undefined}
      style={{
        cursor: canOpen ? "pointer" : undefined,
        position: "absolute", insetInline: 0, top: 0, zIndex: Z.toast,
        display: "flex", alignItems: "center", justifyContent: "center", gap: 7,
        minHeight: 34, paddingInline: 14,
        background: warn ? v("crit") : v("warn"),
        color: "#fff", fontSize: 11.5, fontWeight: 800, lineHeight: 1.6,
        textAlign: "center",
        animation: `toastIn 260ms ${EASE.out} both`,
        boxShadow: "0 6px 18px -10px rgba(0,0,0,.6)",
      }}
    >
      <IconWarn size={14} stroke={2.3} />
      {store
        ? <span>حافظهٔ گوشی پر است — ثبت‌ها روی دستگاه ذخیره نمی‌شوند</span>
        : expired
        ? (queued > 0
            ? <span>
                از حساب خارج شده‌اید — <Num value={queued} /> ثبت محفوظ است
                و با ورودِ دوباره فرستاده می‌شود
              </span>
            : <span>از حساب خارج شده‌اید — دوباره وارد شوید</span>)
        : !online
        ? <span>اینترنت قطع است — تا وصل‌شدن، ثبتِ جدید انجام ندهید</span>
        : <span><Num value={queued} /> ثبت هنوز روی سرور ننشسته</span>}
      {canOpen && (
        <span style={{ fontSize: 10.5, fontWeight: 700, opacity: .85 }}>
          — دیدن
        </span>
      )}
    </div>
    <PendingSheet open={list} onClose={() => setList(false)} />
    </>
  );
}
