/* سرصفحهٔ صفحه — روی ناحیهٔ بالای پس‌زمینه می‌نشیند، پس جوهرش
   از تمِ صفحه می‌آید نه از یک رنگِ ثابت. */

import * as React from "react";
import { v } from "@/system/theme/ThemeProvider";
import { Pressable } from "@/ui/primitives/Pressable";
import { IconBack } from "@/ui/icons";
import { PAD } from "@/ui/kit";
import type { ScreenTheme } from "@/screens/screenThemes";

export const inkOf = (t: ScreenTheme) => v(t.ink);
export const inkSoftOf = (t: ScreenTheme) =>
  t.ink === "deepInk" ? v("deepInkMuted")
  : t.ink === "accentSurfaceInk" ? v("accentSurfaceInkSoft")
  : v("inkMuted");

/** پس‌زمینهٔ دکمه‌های روی ناحیهٔ بالا — روی سفید باید تیره‌تر باشد،
    وگرنه سفیدِ نیمه‌شفاف روی سفید اصلاً دیده نمی‌شود. */
export const chipBgOf = (t: ScreenTheme) =>
  t.up === "deep" ? v("cardDarkAlt")
  : t.up === "accent" ? v("cardAlt")
  : v("surfaceAlt");

export function Header({
  theme, title, sub, onBack, right, big = true, fullTitle = false,
}: {
  theme: ScreenTheme;
  title: React.ReactNode;
  sub?: React.ReactNode;
  onBack?: () => void;
  right?: React.ReactNode;
  big?: boolean;
  /** عنوان را کوتاه نکن — برای صفحهٔ خودِ کالا که نامِ کامل لازم است */
  fullTitle?: boolean;
}) {
  const ink = inkOf(theme);
  const soft = inkSoftOf(theme);
  return (
    <div style={{ paddingInline: PAD, paddingTop: 20 }}>
      <div style={{ display: "flex", alignItems: "center", gap: 10, minHeight: 40 }}>
        {onBack && (
          <Pressable onPress={onBack} scale={0.88} ariaLabel="بازگشت"
            style={{
              width: 38, height: 38, borderRadius: 13, flex: "none",
              display: "grid", placeItems: "center",
              background: chipBgOf(theme), color: ink,
            }}>
            <IconBack size={17} stroke={2.1} />
          </Pressable>
        )}
        <div style={{ flex: 1, minWidth: 0 }}>
          {sub && <div style={{ fontSize: 10.5, fontWeight: 700, color: soft }}>{sub}</div>}
          {!big && (
            <div style={{ fontSize: 15, fontWeight: 800, color: ink,
                          whiteSpace: "nowrap", overflow: "hidden", textOverflow: "ellipsis" }}>{title}</div>
          )}
        </div>
        {right}
      </div>
      {big && (
        /* پیش‌فرض حداکثر دو خط — عنوانِ بلند از منحنیِ پس‌زمینه می‌زند بیرون.
           در صفحهٔ خودِ کالا با fullTitle کامل نشان داده می‌شود و فونتش
           کمی کوچک‌تر می‌شود تا جا بگیرد. */
        <div style={{
          marginTop: 8, fontWeight: 800, lineHeight: 1.4, color: ink,
          fontSize: fullTitle ? 21 : 25,
          ...(fullTitle ? {} : {
            display: "-webkit-box", WebkitLineClamp: 2,
            WebkitBoxOrient: "vertical" as const, overflow: "hidden",
          }),
        }}>
          {title}
        </div>
      )}
    </div>
  );
}
