import * as React from "react";
import { SheetScrim } from "@/ui/overlays/SheetScrim";
import { v } from "@/system/theme/ThemeProvider";
import { FrameCtx, FRAME_FALLBACK, type FrameSize } from "@/system/frame";

/** شناسهٔ لایهٔ روپوش — شیت‌ها و توست‌ها اینجا پورتال می‌شوند */
export const OVERLAY_ID = "ms-overlay";

/**
 * روی گوشی تمام‌صفحه، روی دسکتاپ قابِ گوشی.
 * قاب اندازهٔ خودش را می‌سنجد و به همه اعلام می‌کند — هیچ عددِ ثابتی
 * در هندسه نمی‌ماند، و ریسپانسیو از همین‌جا درست می‌شود.
 */
export function PhoneFrame({ children }: { children: React.ReactNode }) {
  const box = React.useRef<HTMLDivElement>(null);
  const [size, setSize] = React.useState<FrameSize>(FRAME_FALLBACK);
  const [desk, setDesk] = React.useState(false);

  React.useLayoutEffect(() => {
    const syncMode = () =>
      setDesk(window.innerWidth >= 700 && window.innerHeight >= 720);
    syncMode();
    window.addEventListener("resize", syncMode);

    const measure = () => {
      const el = box.current;
      if (!el) return;
      const w = Math.round(el.clientWidth);
      const h = Math.round(el.clientHeight);
      if (w > 0 && h > 0) {
        setSize((p) => (p.w === w && p.h === h ? p : { w, h }));
      }
    };
    measure();
    const ro = new ResizeObserver(measure);
    if (box.current) ro.observe(box.current);
    return () => {
      window.removeEventListener("resize", syncMode);
      ro.disconnect();
    };
  }, []);

  return (
    <div
      style={{
        position: "fixed", inset: 0, display: "grid", placeItems: "center",
        background: desk ? "#161310" : v("canvas"), overflow: "hidden",
      }}
    >
      <div
        ref={box}
        style={{
          position: "relative", overflow: "hidden",
          width: desk ? 390 : "100%",
          height: desk ? "min(844px, calc(100dvh - 48px))" : "100%",
          background: v("canvas"),
          borderRadius: desk ? 46 : 0,
          border: desk ? "10px solid #0B0A09" : "none",
          boxShadow: desk ? "0 45px 80px -35px rgba(60,45,30,.75)" : "none",
          /* ریست فونت‌سایز مبنا تا صفحه‌های بزرگ چیزی را کش ندهند */
          isolation: "isolate",
        }}
      >
        <FrameCtx.Provider value={size}>
          {children}
          {/* مقصدِ پورتالِ روپوش‌ها.
              شیت باید از بافتِ چیدمانِ لایهٔ push بیرون بزند: آن لایه
              z-indexِ ۱۰ دارد و نوارِ پایین ۴۰، پس شیتِ داخلِ لایه هرچه
              z بگیرد باز زیرِ نوار می‌ماند و دکمه‌هایش کلیک نمی‌شوند. */}
          <div id={OVERLAY_ID} style={{ position: "absolute", inset: 0, zIndex: 60,
                                        pointerEvents: "none" }}>
            {/* پرده اینجاست نه داخلِ هر شیت — تا وقتی یک شیت جای شیتِ
                دیگری را می‌گیرد، پس‌زمینه پلک نزند. */}
            <SheetScrim />
          </div>
        </FrameCtx.Provider>
      </div>
    </div>
  );
}
