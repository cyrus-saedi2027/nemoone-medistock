/* ─────────────────────────────────────────────────────────────
 *  «چه چیزی هنوز نرفته»
 *
 *  Asked for after the pharmacy spent eight days watching a counter
 *  climb. "29 records pending" is not something the owner of the
 *  stock can act on: they need the drug, the quantity and the
 *  direction, so they can check it against the shelf and know
 *  exactly what is at risk before they trust the figure again.
 *
 *  Read-only on purpose. Nothing here edits or drops a queued entry
 *  -- those are real stock movements and the only thing that should
 *  ever remove one is the server accepting it.
 * ───────────────────────────────────────────────────────────── */

import * as React from "react";
import { Sheet } from "@/ui/overlays/Sheet";
import { v } from "@/system/theme/ThemeProvider";
import { R } from "@/system/tokens";
import { Num } from "@/ui/text/Text";
import { queuedOps } from "@/store/sync";
import { useData } from "@/store/StoreProvider";
import { fmtJalali, toJalali, expiryLabel } from "@/system/i18n/jalali";
import { toFa } from "@/system/i18n/digits";

/** What each operation is called in the pharmacy's own words. */
const KIND_FA: Record<string, string> = {
  "move": "حرکت",
  "move.undo": "لغوِ ثبت",
  "batch.add": "پارتِ تازه",
  "batch.setQty": "اصلاحِ شمارش",
  "batch.setExpiry": "اصلاحِ انقضا",
  "batch.remove": "حذفِ پارت",
  "counts.apply": "انبارگردانی",
  "counts.approve": "تأییدِ اختلاف",
  "counts.reject": "ردِ اختلاف",
  "product.add": "کالای تازه",
  "product.update": "ویرایشِ کالا",
  "product.remove": "حذفِ کالا",
  "import": "ورودِ گروهی",
  "warehouse.add": "انبارِ تازه",
  "warehouse.rename": "تغییرِ نامِ انبار",
  "warehouse.remove": "حذفِ انبار",
  "supplier.add": "تأمین‌کنندهٔ تازه",
  "supplier.rename": "تغییرِ نامِ تأمین‌کننده",
  "supplier.remove": "حذفِ تأمین‌کننده",
  "category.add": "دستهٔ تازه",
  "category.rename": "تغییرِ نامِ دسته",
  "category.remove": "حذفِ دسته",
  "reason.add": "علتِ تازه",
  "reason.rename": "تغییرِ علت",
  "reason.remove": "حذفِ علت",
  "policy.set": "تنظیمات",
  "month.close": "بستنِ ماه",
  "audit.log": "ثبت در دفتر",
  "notifs.read": "خواندنِ اعلان‌ها",
};

const MOVE_FA: Record<string, string> = {
  IN: "ورود", OUT: "خروج", TRANSFER: "انتقال",
};

export function PendingSheet({ open, onClose }: { open: boolean; onClose: () => void }) {
  const data = useData();

  /* Read once per opening: the queue can drain underneath us and a
     list that reshuffles while someone is reading it is worse than
     one that is a few seconds old. */
  const rows = React.useMemo(() => {
    if (!open) return [];
    const byProduct = new Map(data.catalog.map((c) => [c.i, c] as const));
    const byBatch = new Map(data.batches.map((b) => [b.id, b] as const));
    const byWarehouse = new Map(data.warehouses.map((w) => [w.id, w.name] as const));

    /** Name of whatever this operation is about. */
    const subject = (kind: string, p: any): string => {
      if (p?.productId != null) return byProduct.get(p.productId)?.n ?? `کالا #${toFa(p.productId, false)}`;
      if (p?.batchId != null) {
        const b = byBatch.get(p.batchId);
        const prod = b ? byProduct.get(b.productId) : null;
        return prod?.n ?? (b ? b.lotCode : `پارت #${toFa(p.batchId, false)}`);
      }
      if (p?.nameFa) return String(p.nameFa);
      if (p?.name) return String(p.name);
      if (p?.from) return String(p.from);
      if (p?.target) return String(p.target);
      if (kind === "counts.apply" && Array.isArray(p?.rows))
        return `${toFa(p.rows.length)} پارت`;
      if (kind === "import" && Array.isArray(p?.rows))
        return `${toFa(p.rows.length)} ردیف`;
      return "—";
    };

    /** The part that matters when checking against the shelf. */
    const detail = (kind: string, p: any): string => {
      const bits: string[] = [];
      if (kind === "move") {
        bits.push(MOVE_FA[p?.type] ?? String(p?.type ?? ""));
        if (p?.qty != null) bits.push(`${toFa(p.qty)} عدد`);
        if (p?.toWarehouseId != null)
          bits.push(`به ${byWarehouse.get(p.toWarehouseId) ?? "انبار"}`);
        if (p?.reason) bits.push(String(p.reason));
      } else if (kind === "batch.add") {
        if (p?.qty != null) bits.push(`${toFa(p.qty)} عدد`);
        if (p?.expiry) bits.push(`انقضا ${expiryLabel(String(p.expiry))}`);
        if (p?.warehouseId != null)
          bits.push(byWarehouse.get(p.warehouseId) ?? "انبار");
      } else if (kind === "batch.setQty") {
        if (p?.qty != null) bits.push(`به ${toFa(p.qty)} عدد`);
      } else if (kind === "batch.setExpiry") {
        bits.push(p?.expiry ? `انقضا ${expiryLabel(String(p.expiry))}` : p?.noExpiry ? "بدون انقضا" : "نامشخص");
      } else if (kind === "product.add") {
        if (p?.nameLat) bits.push(String(p.nameLat));
        if (p?.category) bits.push(String(p.category));
      } else if (kind === "warehouse.rename" || kind === "supplier.rename"
              || kind === "category.rename" || kind === "reason.rename") {
        if (p?.to) bits.push(`→ ${p.to}`);
        if (p?.name) bits.push(`→ ${p.name}`);
      }
      return bits.filter(Boolean).join(" · ");
    };

    return queuedOps().map((q) => {
      const p = q.payload as any;
      return {
        cid: q.cid,
        what: KIND_FA[q.kind] ?? q.kind,
        subject: subject(q.kind, p),
        detail: detail(q.kind, p),
        at: q.at,
      };
    });
  }, [open, data.catalog, data.batches, data.warehouses]);

  return (
    <Sheet open={open} onClose={onClose} title="ثبت‌هایی که هنوز نرفته‌اند">
      <div style={{ display: "grid", gap: 8, paddingBottom: 8 }}>
        <p style={{
          margin: 0, fontSize: 12, lineHeight: 1.9, color: v("inkMuted"),
        }}>
          این‌ها روی همین گوشی محفوظ‌اند و به‌محضِ وصل‌شدن به سرور
          فرستاده می‌شوند. چیزی پاک نمی‌شود.
        </p>

        {rows.length === 0 && (
          <div style={{
            padding: "18px 0", textAlign: "center",
            fontSize: 13, fontWeight: 700, color: v("inkMuted"),
          }}>
            چیزی در صف نیست
          </div>
        )}

        {rows.map((r, i) => (
          <div
            key={r.cid}
            style={{
              display: "flex", alignItems: "flex-start", gap: 10,
              padding: "10px 12px", borderRadius: R.card,
              background: v("card"), border: `1px solid ${v("divider")}`,
            }}
          >
            <span style={{
              minWidth: 22, fontSize: 11, fontWeight: 800, color: v("inkMuted"),
              lineHeight: 1.8,
            }}>
              <Num value={i + 1} />
            </span>
            <div style={{ flex: 1, minWidth: 0 }}>
              <div style={{ fontSize: 13, fontWeight: 800, lineHeight: 1.7 }}>
                {r.subject}
              </div>
              <div style={{
                fontSize: 11.5, fontWeight: 600, color: v("inkMuted"), lineHeight: 1.8,
              }}>
                {r.what}{r.detail ? ` · ${r.detail}` : ""}
              </div>
            </div>
            <span style={{
              fontSize: 10.5, fontWeight: 700, color: v("inkMuted"),
              whiteSpace: "nowrap", lineHeight: 2,
            }}>
              {fmtJalali(toJalali(new Date(r.at)))}
            </span>
          </div>
        ))}
      </div>
    </Sheet>
  );
}
