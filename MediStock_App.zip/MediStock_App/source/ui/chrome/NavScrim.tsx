/* ─────────────────────────────────────────────────────────────
 *  محوِ زیرِ نوارِ پایین
 *
 *  قبلاً محتوا با یک ماسک از `h − ۱۰۰` به بعد کاملاً *بریده* می‌شد:
 *  ردیفی که پایین‌تر می‌رفت ناپدید می‌شد، و خطِ ناپدیدشدن هم ۲۴px
 *  بالاتر از خودِ قرص بود، یعنی یک نوارِ خالیِ بی‌دلیل.
 *
 *  حالا هیچ‌چیز بریده نمی‌شود. از *خطِ بالای قرص* به پایین، یک لایهٔ
 *  خیلی ملایم می‌نشیند تا مرز پیدا باشد ولی زیرش هم خوانده شود.
 *
 *  دو نکتهٔ سرعتی:
 *   ۱) بلور فقط ۳px و فقط روی نوارِ ۷۶پیکسلیِ پایین — نه کلِ صفحه.
 *      ناحیه ثابت است، پس مرورگر لایه را یک‌بار می‌سازد.
 *   ۲) اگر مرورگر `backdrop-filter` نداشته باشد (اندرویدِ قدیمی)،
 *      فقط گرادیانِ ملایم می‌ماند — هیچ‌چیز نمی‌شکند.
 * ───────────────────────────────────────────────────────────── */

import * as React from "react";
import { v } from "@/system/theme/ThemeProvider";
import { Z } from "@/system/tokens";
import { useFrame } from "@/system/frame";
import { navTop } from "@/system/geometry/backdrop";

/** درازای رمپِ ورودِ محو — با کمتر از این، مرز مثل تیغ می‌بُرد */
const RAMP = 14;

export function NavScrim() {
  const { h } = useFrame();
  const top = navTop(h);

  return (
    <div
      aria-hidden
      style={{
        position: "absolute", insetInline: 0, top, bottom: 0,
        zIndex: Z.nav - 1, pointerEvents: "none",
        backdropFilter: "blur(3px)",
        WebkitBackdropFilter: "blur(3px)",
        background: `linear-gradient(to bottom, ${v("scrimTop")}, ${v("scrimBottom")})`,
        /* رمپ روی *خودِ لایه* اعمال می‌شود تا بلور هم مثل رنگ کم‌کم
           بیاید. بدونِ این، بالای نوار یک خطِ تیزِ بلور می‌ماند. */
        maskImage: `linear-gradient(to bottom, transparent 0, #000 ${RAMP}px)`,
        WebkitMaskImage: `linear-gradient(to bottom, transparent 0, #000 ${RAMP}px)`,
      }}
    />
  );
}
