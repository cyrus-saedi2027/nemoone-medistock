/* ─────────────────────────────────────────────────────────────
 *  کیتِ رابط — پورتِ اجزای رفرنس
 *
 *  همان سلسله‌مراتب: مربعِ آیکون، ردیفِ روشن/تیره، برچسبِ بخش با
 *  بجِ شمارش، بلوکِ آمار، کارت، و کنترل‌ها.
 *  همه‌جا پراپرتیِ *منطقی* (Inline/Start/End) استفاده شده تا RTL
 *  بدون یک خط کدِ جهت‌دار درست باشد.
 * ───────────────────────────────────────────────────────────── */

import * as React from "react";
import { v } from "@/system/theme/ThemeProvider";
import { R, EASE, SHADOW } from "@/system/tokens";
import { Pressable } from "@/ui/primitives/Pressable";
import { Num } from "@/ui/text/Text";
import { IconForward, IconCheck } from "@/ui/icons";
import { TAP, SELECT } from "@/system/haptics";
import { toEn } from "@/system/i18n/digits";

/**
 * ref که به‌محضِ سوارشدنِ ورودی، کلِ متنش را انتخاب می‌کند.
 *
 * برای فیلدهای عددی: کاربر روی عدد می‌زند چون می‌خواهد عددِ *دیگری*
 * بگذارد، نه اینکه رقمی به همین اضافه کند. اگر انتخاب نشود، اول باید
 * با backspace پاکش کند — روی گوشی یعنی چند لمسِ اضافه در هر ردیف.
 *
 * `requestAnimationFrame` لازم است: بعضی مرورگرهای موبایل فوکوسِ
 * خودشان را بعد از mount اعمال می‌کنند و انتخابِ هم‌زمان را می‌بلعند.
 */
export const selectAll = (el: HTMLInputElement | null) => {
  if (!el) return;
  requestAnimationFrame(() => {
    try { el.select(); } catch { /* type=number انتخاب را نمی‌پذیرد */ }
  });
};

/* ── مربعِ آیکون ───────────────────────────────────────── */
export function IconSquare({
  icon: Icon, size = 34, radius = 11, iconSize = 15, tone = "light", color,
}: {
  icon: React.ComponentType<any>; size?: number; radius?: number;
  iconSize?: number; tone?: "light" | "dark" | "accent" | "wash"; color?: string;
}) {
  const bg =
    tone === "dark" ? v("cardDark")
    : tone === "accent" ? v("accentSurface")
    : tone === "wash" ? v("surfaceAlt")
    : v("surfaceAlt");
  const ink =
    color ?? (tone === "dark" ? v("deepInk") : tone === "accent" ? v("accentSurfaceInk") : v("inkMuted"));
  return (
    <div style={{
      width: size, height: size, borderRadius: radius, background: bg,
      display: "grid", placeItems: "center", flex: "none",
    }}>
      <Icon size={iconSize} stroke={1.9} color={ink} />
    </div>
  );
}

/* ── ردیف‌ها ───────────────────────────────────────────── */
type RowProps = {
  children: React.ReactNode;
  onPress?: () => void;
  height?: number;
  scale?: number;
  style?: React.CSSProperties;
};

/**
 * خطِ موییِ دورِ هر سطح.
 *
 * محمد گفت پس‌زمینه‌ها «خیلی خیلی کم‌رنگ»اند. علتش این بود که کارتِ
 * سفید روی زمینهٔ تقریباً سفید فقط با سایه از هم جدا می‌شد، و سایهٔ
 * ملایم روی گوشی در نورِ روز عملاً دیده نمی‌شود. راهِ حل سایهٔ
 * سنگین‌تر *نبود*: ۲۳ ردیف هم‌زمان روی صفحه‌اند و بلورِ بزرگ p95 را
 * از ۳۳ به ۵۰ms می‌بَرد. یک خطِ یک‌پیکسلی هزینهٔ رنگ‌آمیزیِ اضافه ندارد.
 */
export const HAIR = `1px solid ${v("hair")}`;

export function LightRow({ children, onPress, height = 62, scale = 0.985, style }: RowProps) {
  return (
    <Pressable
      as={onPress ? "button" : "div"}
      onPress={onPress}
      haptic={!!onPress}
      scale={onPress ? scale : 1}
      style={{
        /* overflow:hidden لازم است — دکمه به‌عنوان فلکس‌کانتینر، متنِ
           بلندِ nowrap را از خودش بیرون می‌دهد و ردیف از قاب می‌زند. */
        display: "flex", alignItems: "center", width: "100%",
        minHeight: height, paddingInline: 14, gap: 0, overflow: "hidden",
        borderRadius: R.row, background: v("card"), border: HAIR,
        boxShadow: SHADOW.soft,
        ...style,
      }}
    >
      {children}
    </Pressable>
  );
}

export function DarkRow({ children, onPress, height = 62, scale = 0.985, style }: RowProps) {
  return (
    <Pressable
      as={onPress ? "button" : "div"}
      onPress={onPress}
      haptic={!!onPress}
      scale={onPress ? scale : 1}
      style={{
        display: "flex", alignItems: "center", width: "100%",
        minHeight: height, paddingInline: 14, overflow: "hidden",
        borderRadius: R.row, background: v("cardDark"), border: HAIR,
        ...style,
      }}
    >
      {children}
    </Pressable>
  );
}

/* ── برچسبِ بخش ───────────────────────────────────────── */
export function SectionLabel({
  children, count, tone = "light", action, onAction, style,
}: {
  children: React.ReactNode; count?: number;
  tone?: "light" | "dark" | "onAccent";
  action?: string; onAction?: () => void; style?: React.CSSProperties;
}) {
  /* عمداً inkMuted نه inkFaint: با اسکرول، برچسب از مرزِ منحنی رد
     می‌شود و روی ناحیهٔ زرد/تیره می‌افتد. این تُن روی هر دو خواناست. */
  const ink =
    tone === "dark" ? v("deepInkMuted")
    : tone === "onAccent" ? v("accentSurfaceInkSoft")
    : v("inkMuted");
  const badgeBg =
    tone === "dark" ? v("cardDarkAlt")
    : tone === "onAccent" ? v("cardAlt")
    : v("surfaceAlt");
  const badgeInk = tone === "dark" ? v("deepInk") : tone === "onAccent" ? v("accentSurfaceInk") : v("inkMuted");

  return (
    <div style={{ display: "flex", alignItems: "center", gap: 8, minHeight: 24, ...style }}>
      <span style={{ fontSize: 11, fontWeight: 800, color: ink }}>{children}</span>
      {count != null && (
        <span style={{
          minWidth: 20, height: 18, paddingInline: 6, borderRadius: R.badge,
          background: badgeBg, color: badgeInk,
          fontSize: 10, fontWeight: 800,
          display: "grid", placeItems: "center",
        }}>
          <Num value={count} />
        </span>
      )}
      <i style={{ flex: 1 }} />
      {action && (
        <Pressable onPress={onAction} scale={0.94}
          style={{ fontSize: 11, fontWeight: 800, color: tone === "dark" ? v("accentStrong") : v("inkMuted"),
                   display: "flex", alignItems: "center", gap: 3,
                   minHeight: 40, paddingInline: 6, marginInlineEnd: -6 }}>
          {action}
          <IconForward size={13} stroke={2.2} />
        </Pressable>
      )}
    </div>
  );
}

/* ── بلوکِ آمار ───────────────────────────────────────── */
export function StatBlock({
  label, value, tone = "light", tint, onPress,
}: {
  label: string; value: React.ReactNode;
  tone?: "light" | "dark" | "accent"; tint?: string; onPress?: () => void;
}) {
  const dark = tone === "dark";
  /* `accent` قبلاً `rgba(255,255,255,.55)` بود — یعنی سفیدِ نیمه‌شفاف.
     وقتی پس‌زمینهٔ اپ هم سفید شد، این کارت‌ها عملاً ناپدید شدند؛ همان
     چیزی که محمد در بالای صفحهٔ خانه دید. حالا رنگِ توپُر است. */
  const bg = dark ? v("cardDark") : tone === "accent" ? v("accentSurface") : v("card");
  const lab = dark ? v("deepInkMuted") : tone === "accent" ? v("accentSurfaceInkSoft") : v("inkMuted");
  const val = tint ?? (dark ? v("deepInk") : tone === "accent" ? v("accentSurfaceInk") : v("ink"));
  return (
    <Pressable as={onPress ? "button" : "div"} onPress={onPress} haptic={!!onPress}
      scale={onPress ? 0.97 : 1}
      style={{ flex: 1, minWidth: 0, padding: "11px 13px", borderRadius: R.row,
               background: bg, border: HAIR, boxShadow: SHADOW.soft }}>
      <div style={{ fontSize: 10, fontWeight: 700, color: lab, whiteSpace: "nowrap",
                    overflow: "hidden", textOverflow: "ellipsis" }}>{label}</div>
      <div style={{ marginTop: 4, fontSize: 16, fontWeight: 800, color: val }}>{value}</div>
    </Pressable>
  );
}

/* ── کارت ─────────────────────────────────────────────── */
export function Card({
  children, tone = "light", style, onPress, pad = 16,
}: {
  children: React.ReactNode; tone?: "light" | "dark" | "accent";
  style?: React.CSSProperties; onPress?: () => void; pad?: number;
}) {
  /* «dark» یعنی کارت *روی ورقهٔ سیاه* نشسته: سطحِ شفافِ روشن، نه
     مستطیلِ مشکی. همان کاری که نمونه با ردیف‌های زیرِ منحنی می‌کند. */
  const bg = tone === "dark" ? v("cardDark") : tone === "accent" ? v("accentSurface") : v("card");
  const shadow = tone === "dark" ? "none" : tone === "accent" ? SHADOW.accentCard : SHADOW.cardWhite;
  return (
    <Pressable as={onPress ? "button" : "div"} onPress={onPress} haptic={!!onPress}
      scale={onPress ? 0.985 : 1}
      style={{ display: "block", width: "100%", borderRadius: R.card, background: bg,
               border: HAIR, boxShadow: shadow, padding: pad, ...style }}>
      {children}
    </Pressable>
  );
}

/* ── تراشه (فیلترِ افقی) ──────────────────────────────── */
export function Chip({
  children, on, onPress, tone = "light",
}: { children: React.ReactNode; on?: boolean; onPress?: () => void; tone?: "light" | "dark" }) {
  const dark = tone === "dark";
  return (
    <Pressable onPress={onPress} scale={0.94}
      style={{
        height: 38, paddingInline: 14, borderRadius: 999, flex: "none",
        display: "inline-flex", alignItems: "center", gap: 5,
        fontSize: 11.5, fontWeight: 700,
        background: on ? v("accentStrong") : dark ? v("cardDark") : v("card"),
        color: on ? v("accentStrongInk") : dark ? v("deepInk") : v("inkMuted"),
        boxShadow: on ? SHADOW.pill : "none",
        border: on ? "none" : `1px solid ${dark ? v("cardDarkAlt") : v("divider")}`,
        transition: `background 200ms ${EASE.out}, color 200ms ${EASE.out}`,
      }}>
      {children}
    </Pressable>
  );
}

/* ── سگمنت ────────────────────────────────────────────── */
export function Segmented({
  items, index, onChange, tone = "light",
}: { items: string[]; index: number; onChange: (i: number) => void; tone?: "light" | "dark" }) {
  const dark = tone === "dark";
  return (
    <div style={{
      display: "grid", gridAutoFlow: "column", gridAutoColumns: "1fr",
      padding: 3, borderRadius: 999, position: "relative",
      background: dark ? v("cardDark") : v("surfaceAlt"),
    }}>
      <div style={{
        position: "absolute", top: 3, bottom: 3,
        insetInlineStart: 3, width: `calc((100% - 6px) / ${items.length})`,
        borderRadius: 999, background: dark ? v("accentStrong") : v("card"),
        boxShadow: SHADOW.pill,
        transform: `translate3d(calc(var(--seg-dir) * ${index} * 100%),0,0)`,
        transition: `transform 380ms ${EASE.ios}`,
      }} />
      {items.map((it, i) => (
        <Pressable key={it} onPress={() => { SELECT(); onChange(i); }} scale={0.97}
          style={{
            position: "relative", height: 40, display: "grid", placeItems: "center",
            fontSize: 11.5, fontWeight: 800,
            color: i === index
              ? (dark ? v("accentStrongInk") : v("ink"))
              : (dark ? v("deepInkMuted") : v("inkMuted")),
            transition: `color 220ms ${EASE.out}`,
          }}>
          {it}
        </Pressable>
      ))}
    </div>
  );
}

/* ── کلید ─────────────────────────────────────────────── */
export function Switch({
  on, onChange, label,
}: { on: boolean; onChange: (v: boolean) => void; label?: string }) {
  /* ناحیهٔ لمس ۴۰px است ولی خودِ کلید ۲۶px — هدفِ انگشت بزرگ، ظاهر ریز */
  return (
    <Pressable onPress={() => { SELECT(); onChange(!on); }} scale={0.94} ariaLabel={label}
      role="switch" ariaChecked={on}
      style={{
        width: 56, height: 40, flex: "none", display: "grid", placeItems: "center",
        marginInlineEnd: -6,
      }}>
      <span style={{
        width: 44, height: 26, borderRadius: 999, padding: 3, display: "flex", alignItems: "center",
        background: on ? v("accentStrong") : v("ringTrack"),
        transition: `background 260ms ${EASE.out}`,
      }}>
        {/* دستهٔ کلید توکنِ خودش را دارد: در تمِ شب ریلِ روشن است و
            دستهٔ سفید رویش گم می‌شد. */}
        <i style={{
          width: 20, height: 20, borderRadius: 999, background: v("knob"), flex: "none",
          boxShadow: "0 1px 3px rgba(0,0,0,.25)",
          transform: `translate3d(calc(var(--seg-dir) * ${on ? 18 : 0}px),0,0)`,
          transition: `transform 300ms ${EASE.ios}`,
        }} />
      </span>
    </Pressable>
  );
}

/* ── ورودیِ متن ───────────────────────────────────────── */
export function Field({
  label, value, onChange, type = "text", placeholder, ltr, suffix, autoFocus, inputMode,
  tone = "light",
}: {
  label?: string; value: string; onChange: (s: string) => void;
  type?: string; placeholder?: string; ltr?: boolean; suffix?: React.ReactNode;
  autoFocus?: boolean; inputMode?: "text" | "numeric" | "decimal";
  tone?: "light" | "dark";
}) {
  const [focus, setFocus] = React.useState(false);
  const dark = tone === "dark";
  return (
    <div>
      {label && (
        <div style={{ fontSize: 10.5, fontWeight: 800, marginBottom: 6,
                      color: dark ? v("deepInkMuted") : v("inkFaint") }}>{label}</div>
      )}
      <div style={{
        display: "flex", alignItems: "center", gap: 8,
        height: 46, borderRadius: R.field, paddingInline: 13,
        background: dark ? v("cardDark") : v("card"),
        /* حلقهٔ فوکوس با `ring` است نه `accentSurface`: در تمِ دیفالت
           سطحِ تأکید خاکستریِ روشن است و فرقش با خطِ عادی دیده نمی‌شد. */
        border: `1.5px solid ${focus ? v("ring") : v("divider")}`,
        transition: `border-color 200ms ${EASE.out}`,
      }}>
        <input
          value={value}
          onChange={(e) => onChange(e.target.value)}
          /* فیلدِ عددی با فوکوس کاملاً انتخاب می‌شود — همان قانونِ Stepper */
          onFocus={(e) => { setFocus(true); if (inputMode === "numeric") e.currentTarget.select(); }}
          onBlur={() => setFocus(false)}
          type={type}
          inputMode={inputMode}
          placeholder={placeholder}
          autoFocus={autoFocus}
          dir={ltr ? "ltr" : undefined}
          style={{
            /* ارتفاعِ کامل: هدفِ لمس باید کلِ کادر باشد، نه فقط خطِ متن */
            flex: 1, minWidth: 0, alignSelf: "stretch", height: "100%",
            border: "none", outline: "none", background: "none", padding: 0,
            fontSize: 14, fontWeight: 600, fontFamily: "inherit",
            color: dark ? v("deepInk") : v("ink"),
            textAlign: ltr ? "left" : "start",
          }}
        />
        {suffix}
      </div>
    </div>
  );
}

/* ── شمارنده ──────────────────────────────────────────── */
export function Stepper({
  value, onChange, min = 0, max = 999999, step = 1, tone = "light",
}: {
  value: number; onChange: (n: number) => void;
  min?: number; max?: number; step?: number; tone?: "light" | "dark";
}) {
  const dark = tone === "dark";
  const bump = (d: number) => {
    const next = Math.min(max, Math.max(min, value + d));
    if (next !== value) { TAP(); onChange(next); }
  };
  const btn = (label: string, d: number, disabled: boolean, aria: string) => (
    <Pressable onPress={() => bump(d)} disabled={disabled} scale={0.9} ariaLabel={aria}
      style={{ width: 44, height: 44, borderRadius: 14, display: "grid", placeItems: "center",
               background: dark ? v("cardDarkAlt") : v("surfaceAlt"),
               color: dark ? v("deepInk") : v("ink"), fontSize: 20, fontWeight: 700 }}>
      {label}
    </Pressable>
  );

  /* عدد خودش ورودی است: یکی‌یکی با +/− یا مستقیم تایپ.
     برای محموله‌های بزرگ، ۲۴۰ بار زدنِ «+» مسخره است. */
  const [typing, setTyping] = React.useState(false);
  const [draft, setDraft] = React.useState("");

  const commit = () => {
    setTyping(false);
    const n = Number(toEn(draft).replace(/[^\d]/g, ""));
    if (!draft.trim() || Number.isNaN(n)) return;
    const next = Math.min(max, Math.max(min, n));
    if (next !== value) { SELECT(); onChange(next); }
  };

  return (
    <div style={{ display: "flex", alignItems: "center", gap: 10 }}>
      {btn("−", -step, value <= min, "کم کردن")}

      {typing ? (
        <input
          autoFocus
          inputMode="numeric"
          value={draft}
          onChange={(e) => setDraft(e.target.value)}
          /* لمسِ عدد یعنی «می‌خواهم عددِ دیگری بزنم»، نه «می‌خواهم این را
             ویرایش کنم». پس کلِ متن انتخاب می‌شود تا اولین رقمی که
             می‌زند جایش را بگیرد و لازم نباشد اول پاکش کند.
             هم روی ref و هم روی onFocus: بعضی مرورگرهای موبایل انتخابِ
             حینِ نصبِ عنصر را با فوکوسِ خودشان بازنویسی می‌کنند. */
          ref={selectAll}
          onFocus={(e) => e.currentTarget.select()}
          onBlur={commit}
          onKeyDown={(e) => { if (e.key === "Enter") (e.target as HTMLInputElement).blur(); }}
          aria-label="تعداد"
          style={{
            flex: 1, minWidth: 0, height: 44, borderRadius: 14, textAlign: "center",
            fontSize: 24, fontWeight: 800, fontFamily: "inherit",
            background: dark ? v("cardDarkAlt") : v("surfaceAlt"),
            color: dark ? v("deepInk") : v("ink"),
            border: `1.5px solid ${v("ring")}`, outline: "none",
          }}
        />
      ) : (
        <Pressable
          onPress={() => { TAP(); setDraft(String(value)); setTyping(true); }}
          scale={0.96}
          ariaLabel="واردکردنِ تعداد"
          style={{
            flex: 1, minWidth: 0, height: 44, borderRadius: 14,
            display: "grid", placeItems: "center",
          }}
        >
          <span style={{ fontSize: 24, fontWeight: 800,
                         color: dark ? v("deepInk") : v("ink"),
                         borderBottom: `1.5px dashed ${dark ? v("deepInkMuted") : v("inkFaint")}`,
                         paddingInline: 10, lineHeight: 1.5 }}>
            <Num value={value} />
          </span>
        </Pressable>
      )}

      {btn("+", step, value >= max, "زیاد کردن")}
    </div>
  );
}

/* ── دکمهٔ اصلی ───────────────────────────────────────── */
export function Button({
  children, onPress, tone = "accent", disabled, style, icon: Icon,
}: {
  children: React.ReactNode; onPress?: () => void;
  tone?: "accent" | "dark" | "ghost" | "ghostDark" | "danger"; disabled?: boolean;
  style?: React.CSSProperties; icon?: React.ComponentType<any>;
}) {
  /* `ghostDark` همان AddRow نمونه است: حاشیهٔ خط‌چینِ روشن روی ورقهٔ سیاه */
  /* دکمهٔ اصلی و دکمهٔ تیره گرادیان می‌گیرند — تنها جای گرادیانِ
     «تأکیدی» در اپ. در تم‌هایی که گرادیان نمی‌خواهند، همان توکن رنگِ
     تخت است، پس اینجا شرطی لازم نیست. */
  const map = {
    accent:    { bg: v("accentGrad"), ink: v("accentStrongInk"), border: "none" },
    dark:      { bg: v("deepGrad"), ink: v("onDark"), border: "none" },
    ghost:     { bg: "transparent", ink: v("inkMuted"), border: `1.5px solid ${v("divider")}` },
    ghostDark: { bg: "transparent", ink: v("deepInk"), border: `1.5px dashed ${v("divider")}` },
    danger:    { bg: v("critWash"), ink: v("crit"), border: `1px solid ${v("hair")}` },
  }[tone];
  return (
    <Pressable onPress={onPress} disabled={disabled} scale={0.97}
      style={{
        width: "100%", minHeight: 48, borderRadius: 999,
        display: "flex", alignItems: "center", justifyContent: "center", gap: 8,
        background: map.bg, color: map.ink, border: map.border,
        fontSize: 14, fontWeight: 800,
        boxShadow: tone === "accent" ? SHADOW.pill : "none",
        ...style,
      }}>
      {Icon && <Icon size={17} stroke={2.1} />}
      {children}
    </Pressable>
  );
}

/* ── ردیفِ انتخابگر ───────────────────────────────────── */
export function PickerRow({
  icon, label, value, onPress, tone = "light",
}: {
  icon?: React.ComponentType<any>; label: string; value?: React.ReactNode;
  onPress?: () => void; tone?: "light" | "dark";
}) {
  const dark = tone === "dark";
  const Row = dark ? DarkRow : LightRow;
  return (
    <Row onPress={onPress} height={62}>
      {icon && <IconSquare icon={icon} tone={dark ? "dark" : "light"} />}
      <div style={{ flex: 1, minWidth: 0, marginInlineStart: icon ? 12 : 0 }}>
        <div style={{ fontSize: 10.5, fontWeight: 700, color: dark ? v("deepInkMuted") : v("inkFaint") }}>{label}</div>
        <div style={{ marginTop: 2, fontSize: 13, fontWeight: 700,
                      color: dark ? v("deepInk") : v("ink"),
                      whiteSpace: "nowrap", overflow: "hidden", textOverflow: "ellipsis" }}>
          {value ?? "—"}
        </div>
      </div>
      <IconForward size={15} stroke={2} color={dark ? v("deepInkMuted") : v("inkFaint")} />
    </Row>
  );
}

/* ── ردیفِ انتخاب (چک) ────────────────────────────────── */
export function ChoiceRow({
  label, meta, on, onPress, tone = "light",
}: {
  label: React.ReactNode; meta?: React.ReactNode; on?: boolean;
  onPress?: () => void; tone?: "light" | "dark";
}) {
  const dark = tone === "dark";
  const Row = dark ? DarkRow : LightRow;
  return (
    <Row onPress={onPress} height={54}>
      <div style={{ flex: 1, minWidth: 0 }}>
        <div style={{ fontSize: 13, fontWeight: 700, color: dark ? v("deepInk") : v("ink") }}>{label}</div>
        {meta && (
          <div style={{ marginTop: 2, fontSize: 10.5,
                        color: dark ? v("deepInkMuted") : v("inkFaint") }}>{meta}</div>
        )}
      </div>
      <div style={{
        width: 22, height: 22, borderRadius: 999, flex: "none",
        display: "grid", placeItems: "center",
        /* تیکِ انتخاب رنگِ تأکید می‌گیرد: این «سطح» نیست، «حالت» است و
           باید از یک نگاه معلوم باشد کدام ردیف انتخاب شده. */
        background: on ? v("accentStrong") : "transparent",
        border: on ? "none" : `1.5px solid ${v("divider")}`,
        transition: `background 180ms ${EASE.out}`,
      }}>
        {on && <IconCheck size={13} stroke={3} color={v("accentStrongInk")} />}
      </div>
    </Row>
  );
}

/* ── حالتِ خالی ───────────────────────────────────────── */
export function Empty({
  icon: Icon, title, note, tone = "light",
}: { icon: React.ComponentType<any>; title: string; note?: string; tone?: "light" | "dark" }) {
  const dark = tone === "dark";
  return (
    <div style={{ display: "grid", placeItems: "center", gap: 10, padding: "44px 20px", textAlign: "center" }}>
      <div style={{ width: 54, height: 54, borderRadius: 18, display: "grid", placeItems: "center",
                    background: dark ? v("cardDark") : v("surfaceAlt") }}>
        <Icon size={22} stroke={1.7} color={dark ? v("deepInkMuted") : v("inkFaint")} />
      </div>
      <div style={{ fontSize: 13.5, fontWeight: 800, color: dark ? v("deepInk") : v("ink") }}>{title}</div>
      {note && (
        <div style={{ fontSize: 11.5, lineHeight: 1.9, maxWidth: 260,
                      color: dark ? v("deepInkMuted") : v("inkFaint") }}>{note}</div>
      )}
    </div>
  );
}

/* ── حلقهٔ پیشرفت ─────────────────────────────────────── */
export function Ring({ pct, size = 56, tone = "light" }: { pct: number; size?: number; tone?: "light" | "dark" }) {
  const r = (size - 7) / 2;
  const c = 2 * Math.PI * r;
  return (
    <svg width={size} height={size} viewBox={`0 0 ${size} ${size}`} style={{ flex: "none" }}>
      <circle cx={size / 2} cy={size / 2} r={r} fill="none" strokeWidth="5"
              stroke={tone === "dark" ? v("cardDarkAlt") : v("ringTrack")} />
      <circle cx={size / 2} cy={size / 2} r={r} fill="none" strokeWidth="5" strokeLinecap="round"
              stroke={v("accentStrong")}
              strokeDasharray={c}
              strokeDashoffset={c * (1 - Math.max(0, Math.min(1, pct)))}
              transform={`rotate(-90 ${size / 2} ${size / 2})`}
              style={{ transition: `stroke-dashoffset 620ms ${EASE.out}` }} />
    </svg>
  );
}

export const Gap = ({ h = 12 }: { h?: number }) => <div style={{ height: h }} />;

/** حاشیهٔ افقیِ استانداردِ صفحه */
export const PAD = 18;
export const Pad = ({ children, style }: { children: React.ReactNode; style?: React.CSSProperties }) => (
  <div style={{ paddingInline: PAD, ...style }}>{children}</div>
);
