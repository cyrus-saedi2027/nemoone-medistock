/* ─────────────────────────────────────────────────────────────
 *  فیلترهای جست‌وجو
 *
 *  با دکمهٔ کنارِ نوارِ جست‌وجو باز و بسته می‌شود. هر فیلتری که روشن
 *  شود نتیجه را کوچک‌تر می‌کند؛ چند فیلتر با هم AND می‌شوند.
 *
 *  یک مؤلفه برای *همهٔ* جاهایی که جست‌وجو داریم — کاتالوگ و شیتِ
 *  انتخابِ کالا — تا رفتار همه‌جا یکی باشد.
 * ───────────────────────────────────────────────────────────── */

import * as React from "react";
import { v } from "@/system/theme/ThemeProvider";
import { R, EASE } from "@/system/tokens";
import { Chip } from "@/ui/kit";
import { Num } from "@/ui/text/Text";
import { Pressable } from "@/ui/primitives/Pressable";
import { IconX, IconCal, IconForward } from "@/ui/icons";
import { JalaliRangeSheet, rangeLabel, type ISORange } from "@/ui/overlays/JalaliRange";
import { SELECT } from "@/system/haptics";
import type { Batch, CatalogRow, Supplier, Warehouse } from "@/domain/types";
import { monthsUntil } from "@/domain/derive";

/** وضعیتِ انقضا
 *
 * `noDate` عمداً یک گزینهٔ *جدا* است و داخلِ `expired` نرفته: کالایی
 * که تاریخ ندارد منقضی نشده، فقط از روی تاریخ نمی‌شود قضاوتش کرد.
 * قاطی‌کردنشان یعنی کسی که دنبالِ دارویِ تاریخ‌گذشته می‌گردد، ۴۵
 * باند و ست سرم هم تحویل بگیرد. */
export type Expiry = "any" | "expired" | "lt3" | "lt6" | "gt6" | "noDate";
/** وضعیتِ موجودی */
export type Stock = "any" | "in" | "out";

export type Filters = {
  expiry: Expiry;
  /** بازهٔ تاریخِ ورود به انبار — میلادیِ ISO، نمایشش شمسی است */
  entry: ISORange;
  /** بازهٔ تاریخِ خرید از تأمین‌کننده */
  buy: ISORange;
  supplierId: number | null;
  warehouseId: number | null;
  category: string | null;
  stock: Stock;
};

export const EMPTY_FILTERS: Filters = {
  expiry: "any", entry: null, buy: null,
  supplierId: null, warehouseId: null, category: null, stock: "any",
};

export const countActive = (f: Filters) =>
  (f.expiry !== "any" ? 1 : 0) + (f.entry ? 1 : 0) + (f.buy ? 1 : 0) +
  (f.supplierId != null ? 1 : 0) + (f.warehouseId != null ? 1 : 0) +
  (f.category != null ? 1 : 0) + (f.stock !== "any" ? 1 : 0);

const EXPIRY_FA: Record<Expiry, string> = {
  any: "همه", expired: "منقضی", lt3: "زیر ۳ ماه", lt6: "زیر ۶ ماه",
  gt6: "بیش از ۶ ماه", noDate: "بدون تاریخ",
};
const STOCK_FA: Record<Stock, string> = { any: "همه", in: "موجود", out: "ناموجود" };

/** تاریخِ ISO داخلِ بازه است؟ مقایسهٔ رشته‌ای کافی است چون YYYY-MM-DD مرتب است. */
function inRange(iso: string | null, r: ISORange) {
  if (!r) return true;
  if (!iso) return false;
  const d = iso.slice(0, 10);
  return d >= r.from && d <= r.to;
}

/**
 * آیا این کالا از صافیِ فیلترها رد می‌شود؟
 *
 * فیلترهای پارت‌محور (انقضا، انبار، تأمین‌کننده، تاریخ‌ها) روی
 * *حداقل یک پارتِ* کالا بررسی می‌شوند — یعنی «کالایی که پارتی با این
 * مشخصات دارد»، که همان چیزی است که کاربر انتظار دارد.
 */
export function passes(
  r: CatalogRow, f: Filters, batchesOf: (id: number) => Batch[], now = new Date()
) {
  if (f.category && r.c !== f.category) return false;
  if (f.stock === "in" && r.q <= 0) return false;
  if (f.stock === "out" && r.q > 0) return false;

  const needsBatch =
    f.expiry !== "any" || !!f.entry || !!f.buy ||
    f.supplierId != null || f.warehouseId != null;
  if (!needsBatch) return true;

  for (const b of batchesOf(r.i)) {
    if (f.warehouseId != null && b.warehouseId !== f.warehouseId) continue;
    if (f.supplierId != null && b.supplierId !== f.supplierId) continue;
    if (!inRange(b.entryDate, f.entry)) continue;
    if (!inRange(b.purchasedAt ?? null, f.buy)) continue;
    if (f.expiry === "noDate") {
      /* هر پارتی که تاریخ ندارد — چه «بدون انقضا» چه «نامشخص» */
      if (b.expiry) continue;
    } else if (f.expiry !== "any") {
      const m = monthsUntil(b.expiry, now);
      if (m == null) continue;
      if (f.expiry === "expired" && m >= 0) continue;
      if (f.expiry === "lt3" && !(m >= 0 && m < 3)) continue;
      if (f.expiry === "lt6" && !(m >= 0 && m < 6)) continue;
      if (f.expiry === "gt6" && m < 6) continue;
    }
    return true;      // یک پارت کافی است
  }
  return false;
}

/* ── پنل ──────────────────────────────────────────────── */
function Group({
  label, children, tone,
}: { label: string; children: React.ReactNode; tone: "light" | "dark" }) {
  return (
    <div style={{ marginBottom: 12 }}>
      <div style={{ fontSize: 10.5, fontWeight: 800, marginBottom: 7,
                    color: tone === "dark" ? v("deepInkMuted") : v("inkFaint") }}>{label}</div>
      <div style={{ display: "flex", gap: 6, flexWrap: "wrap" }}>{children}</div>
    </div>
  );
}

/** ردیفِ انتخابِ بازه — تقویم را باز می‌کند */
function DateRow({
  value, onPress, tone,
}: { value: ISORange; onPress: () => void; tone: "light" | "dark" }) {
  const dark = tone === "dark";
  const label = rangeLabel(value);
  return (
    <Pressable onPress={onPress} scale={0.985}
      style={{
        width: "100%", display: "flex", alignItems: "center", gap: 10,
        minHeight: 44, paddingInline: 12, borderRadius: R.field,
        /* حالتِ فعال رنگِ *تأکید* می‌گیرد نه رنگِ سطح: `accentSurface` و
           `surfaceAlt` در تمِ دیفالت هر دو خاکستریِ روشن‌اند و معلوم
           نمی‌شد بازه‌ای انتخاب شده یا نه. */
        background: value
          ? v("accentStrong")
          : dark ? v("cardDarkAlt") : v("surfaceAlt"),
        transition: `background 220ms ${EASE.out}`,
      }}>
      <IconCal size={15}
        color={value ? v("accentStrongInk") : dark ? v("deepInkMuted") : v("inkFaint")} />
      <span style={{
        flex: 1, minWidth: 0, textAlign: "start",
        fontSize: 12, fontWeight: value ? 800 : 600,
        whiteSpace: "nowrap", overflow: "hidden", textOverflow: "ellipsis",
        color: value ? v("accentStrongInk") : dark ? v("deepInkMuted") : v("inkMuted"),
      }}>{label ?? "انتخابِ بازه"}</span>
      <IconForward size={14} stroke={2}
        color={value ? v("accentStrongInk") : dark ? v("deepInkMuted") : v("inkFaint")} />
    </Pressable>
  );
}

export function FilterPanel({
  open, filters, set, cats, warehouses, suppliers, tone = "light",
}: {
  open: boolean;
  filters: Filters;
  set: (f: Filters) => void;
  cats: string[];
  warehouses: Warehouse[];
  suppliers: Supplier[];
  tone?: "light" | "dark";
}) {
  const box = React.useRef<HTMLDivElement>(null);
  const [h, setH] = React.useState(0);
  const [cal, setCal] = React.useState<null | "entry" | "buy">(null);

  /* ارتفاع را می‌سنجیم تا باز/بسته‌شدن *انیمیت* شود، نه پرش.
     `auto` را نمی‌شود transition داد. */
  React.useLayoutEffect(() => {
    const measure = () => setH(box.current?.scrollHeight ?? 0);
    measure();
    const ro = new ResizeObserver(measure);
    if (box.current) ro.observe(box.current);
    return () => ro.disconnect();
  }, [cats.length, warehouses.length, suppliers.length]);

  const pick = <K extends keyof Filters>(k: K, val: Filters[K]) => {
    SELECT();
    set({ ...filters, [k]: filters[k] === val ? EMPTY_FILTERS[k] : val });
  };

  const n = countActive(filters);

  /* سقفِ ارتفاع تا سرصفحه بی‌نهایت بلند نشود و تراشه‌های دسته زیرِ
     نوارِ پایین نروند؛ اگر فیلترها بیشتر از این جا بگیرند، خودِ پنل
     اسکرول می‌شود. */
  const capped = Math.min(h, 300);

  return (
    <div style={{
      overflowY: open ? "auto" : "hidden",
      overflowX: "hidden",
      overscrollBehavior: "contain",
      height: open ? capped : 0,
      opacity: open ? 1 : 0,
      transition: `height 340ms ${EASE.ios}, opacity 240ms ${EASE.out}`,
    }}>
      <div ref={box} style={{ paddingTop: 12 }}>
        <div style={{
          padding: "14px 14px 4px", borderRadius: R.card,
          background: tone === "dark" ? v("cardDark") : v("card"),
        }}>
          <Group label="وضعیتِ انقضا" tone={tone}>
            {(["expired", "lt3", "lt6", "gt6", "noDate"] as Expiry[]).map((k) => (
              <Chip key={k} tone={tone} on={filters.expiry === k}
                    onPress={() => pick("expiry", k)}>{EXPIRY_FA[k]}</Chip>
            ))}
          </Group>

          <Group label="موجودی" tone={tone}>
            {(["in", "out"] as Stock[]).map((k) => (
              <Chip key={k} tone={tone} on={filters.stock === k}
                    onPress={() => pick("stock", k)}>{STOCK_FA[k]}</Chip>
            ))}
          </Group>

          <Group label="تاریخِ ورود به انبار" tone={tone}>
            <DateRow tone={tone} value={filters.entry} onPress={() => setCal("entry")} />
          </Group>

          <Group label="تاریخِ خرید از تأمین‌کننده" tone={tone}>
            <DateRow tone={tone} value={filters.buy} onPress={() => setCal("buy")} />
          </Group>

          {suppliers.length > 0 && (
            <Group label="تأمین‌کننده" tone={tone}>
              {suppliers.map((s) => (
                <Chip key={s.id} tone={tone} on={filters.supplierId === s.id}
                      onPress={() => pick("supplierId", s.id)}>{s.name}</Chip>
              ))}
            </Group>
          )}

          <Group label="محلِ نگهداری" tone={tone}>
            {warehouses.map((wh) => (
              <Chip key={wh.id} tone={tone} on={filters.warehouseId === wh.id}
                    onPress={() => pick("warehouseId", wh.id)}>{wh.name}</Chip>
            ))}
          </Group>

          {cats.length > 0 && (
            <Group label="دسته" tone={tone}>
              {cats.map((c) => (
                <Chip key={c} tone={tone} on={filters.category === c}
                      onPress={() => pick("category", c)}>{c}</Chip>
              ))}
            </Group>
          )}

          {n > 0 && (
            <Pressable onPress={() => { SELECT(); set(EMPTY_FILTERS); }} scale={0.96}
              style={{
                width: "100%", minHeight: 40, marginBottom: 10, borderRadius: 999,
                display: "flex", alignItems: "center", justifyContent: "center", gap: 6,
                background: tone === "dark" ? v("cardDarkAlt") : v("surfaceAlt"),
                color: tone === "dark" ? v("deepInk") : v("inkMuted"),
                fontSize: 11.5, fontWeight: 800,
              }}>
              <IconX size={13} stroke={2.4} />
              پاک‌کردنِ <Num value={n} /> فیلتر
            </Pressable>
          )}
        </div>
      </div>

      <JalaliRangeSheet
        open={cal != null}
        onClose={() => setCal(null)}
        title={cal === "buy" ? "تاریخِ خرید از تأمین‌کننده" : "تاریخِ ورود به انبار"}
        value={cal ? filters[cal] : null}
        onChange={(r) => { if (cal) set({ ...filters, [cal]: r }); }}
      />
    </div>
  );
}
