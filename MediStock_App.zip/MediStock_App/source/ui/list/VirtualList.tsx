/* ─────────────────────────────────────────────────────────────
 *  لیستِ مجازیِ ۵۰۱۰ ردیف — بدونِ وابستگی
 *
 *  بدونِ این، اسکرولِ کاتالوگ روی گوشیِ متوسط می‌میرد.
 *  فقط پنجرهٔ دیده‌شده + overscan رندر می‌شود؛ اسکرول از rAF
 *  عبور می‌کند تا در هر رویداد setState نزنیم.
 * ───────────────────────────────────────────────────────────── */

import * as React from "react";

type Props<T> = {
  items: T[];
  rowHeight: number;
  overscan?: number;
  /** المانِ اسکرول‌شونده (ScreenScroll آن را می‌دهد) */
  scrollRef: React.RefObject<HTMLElement>;
  /** فاصلهٔ بالای لیست تا بالای ناحیهٔ اسکرول */
  offsetTop?: number;
  children: (item: T, index: number) => React.ReactNode;
};

export function VirtualList<T>({
  items, rowHeight, overscan = 6, scrollRef, offsetTop = 0, children,
}: Props<T>) {
  const [range, setRange] = React.useState({ a: 0, b: 24 });
  const raf = React.useRef(0);
  const last = React.useRef({ a: -1, b: -1 });

  const measure = React.useCallback(() => {
    raf.current = 0;
    const el = scrollRef.current;
    if (!el) return;
    const top = Math.max(0, el.scrollTop - offsetTop);
    const h = el.clientHeight;
    const a = Math.max(0, Math.floor(top / rowHeight) - overscan);
    const b = Math.min(items.length, Math.ceil((top + h) / rowHeight) + overscan);
    // فقط وقتی پنجره واقعاً عوض شده، رندر کن
    if (a !== last.current.a || b !== last.current.b) {
      last.current = { a, b };
      setRange({ a, b });
    }
  }, [items.length, rowHeight, overscan, offsetTop, scrollRef]);

  React.useEffect(() => {
    const el = scrollRef.current;
    if (!el) return;
    const onScroll = () => {
      if (raf.current) return;              // یک اندازه‌گیری در هر فریم
      raf.current = requestAnimationFrame(measure);
    };
    el.addEventListener("scroll", onScroll, { passive: true });
    measure();
    return () => {
      el.removeEventListener("scroll", onScroll);
      if (raf.current) cancelAnimationFrame(raf.current);
      raf.current = 0;
    };
  }, [measure, scrollRef]);

  // وقتی فیلتر عوض می‌شود، پنجره را از نو بسنج
  React.useEffect(() => { last.current = { a: -1, b: -1 }; measure(); }, [items, measure]);

  const slice = [];
  for (let i = range.a; i < range.b; i++) {
    const it = items[i];
    if (it === undefined) continue;
    slice.push(
      <div key={i} style={{ position: "absolute", insetInlineStart: 0, insetInlineEnd: 0,
                            top: i * rowHeight, height: rowHeight }}>
        {children(it, i)}
      </div>
    );
  }

  return (
    <div style={{ position: "relative", height: items.length * rowHeight }}>
      {slice}
    </div>
  );
}
