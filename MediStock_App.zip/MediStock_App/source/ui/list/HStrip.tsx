/* ─────────────────────────────────────────────────────────────
 *  نوارِ افقیِ کارت‌ها
 *
 *  چرا کامپوننتِ جدا: کشیدنِ افقی داخلِ یک صفحهٔ عمودی سه‌تا تلهٔ
 *  شناخته‌شده دارد و هر سه‌تا در «محل‌های نگهداری» با هم اتفاق افتاده
 *  بودند — نتیجه‌اش همان «یهو می‌پره، یهو تند می‌ره».
 *
 *  ۱) `scroll-snap-type: x proximity`
 *     «proximity» یعنی مرورگر *خودش* تصمیم می‌گیرد کِی بچسبد. انگشت
 *     که بلند می‌شود، گاهی سُر می‌خورد و گاهی وسطِ راه پرت می‌شود روی
 *     کارتِ بعدی. همان پرشی که دیده شد. برداشته شد — نوار آزاد است.
 *
 *  ۲) کششِ الاستیکِ صفحه
 *     `ScreenScroll` با هر `touchmove` که صفحه بالای فهرست باشد کلِ
 *     محتوا را می‌کشد. کشیدنِ افقی همیشه چند پیکسل مؤلفهٔ عمودی دارد،
 *     پس نوار افقی می‌رفت و صفحه هم‌زمان بالا و پایین می‌پرید. حالا
 *     `ScreenScroll` محورِ غالب را می‌سنجد و از ژستِ افقی کنار می‌کشد.
 *
 *  ۳) `overscroll-behavior`
 *     بدونِ آن، رسیدن به انتهای نوار کششِ صفحهٔ پشتی را روشن می‌کرد.
 *
 *  حاشیه‌ها داخلِ خودِ نوارند نه روی ظرف، وگرنه کارتِ اول به لبهٔ صفحه
 *  می‌چسبد و کارتِ آخر پشتِ لبه گیر می‌کند.
 * ───────────────────────────────────────────────────────────── */

import * as React from "react";
import { PAD } from "@/ui/kit";

export function HStrip({
  children, gap = 8, pad = PAD, style,
}: {
  children: React.ReactNode; gap?: number; pad?: number; style?: React.CSSProperties;
}) {
  return (
    <div
      data-hstrip=""
      style={{
        display: "flex", gap,
        overflowX: "auto", overflowY: "hidden",
        paddingInline: pad, paddingBottom: 8,
        WebkitOverflowScrolling: "touch",
        overscrollBehaviorX: "contain",
        overscrollBehaviorY: "none",
        scrollbarWidth: "none",
        ...style,
      }}
    >
      {children}
    </div>
  );
}
