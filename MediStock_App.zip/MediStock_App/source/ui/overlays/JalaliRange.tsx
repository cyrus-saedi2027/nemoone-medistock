/* ─────────────────────────────────────────────────────────────
 *  تقویمِ شمسی با انتخابِ بازه
 *
 *  رفتار عیناً همان چیزی است که در پروژهٔ «order-management» هست و
 *  محمد می‌پسندد:
 *      لمسِ اول  → شروعِ بازه
 *      لمسِ دوم  → پایانِ بازه (اگر عقب‌تر بود، جای شروع می‌نشیند)
 *      لمسِ سوم  → از نو شروع می‌کند
 *  «امروز» حلقه دارد، روزهای بینِ دو سر با نوارِ کم‌رنگ وصل می‌شوند.
 *
 *  خروجی همیشه **میلادیِ ISO** است (`YYYY-MM-DD`) چون داده‌ها میلادی
 *  ذخیره می‌شوند؛ نمایش شمسی است. تبدیل فقط همین‌جا اتفاق می‌افتد.
 * ───────────────────────────────────────────────────────────── */

import * as React from "react";
import { v } from "@/system/theme/ThemeProvider";
import { R, EASE } from "@/system/tokens";
import { Pressable } from "@/ui/primitives/Pressable";
import { Sheet } from "@/ui/overlays/Sheet";
import { Button } from "@/ui/kit";
import { IconBack, IconForward } from "@/ui/icons";
import { SELECT, TAP } from "@/system/haptics";
import {
  J_MONTHS, jDaysInMonth, toJalali, fromJalali, type J,
} from "@/system/i18n/jalali";

const WEEK = ["ش", "ی", "د", "س", "چ", "پ", "ج"];
const fa = (n: number | string) => String(n).replace(/\d/g, (d) => "۰۱۲۳۴۵۶۷۸۹"[+d]);
const p2 = (n: number) => String(n).padStart(2, "0");

export type ISORange = { from: string; to: string } | null;

/** شمارهٔ ستونِ روز — هفته از شنبه شروع می‌شود، getDay() از یک‌شنبه */
const col = (d: Date) => (d.getDay() + 1) % 7;

const toISO = (j: J) => {
  const g = fromJalali(j.jy, j.jm, j.jd);
  return `${g.getFullYear()}-${p2(g.getMonth() + 1)}-${p2(g.getDate())}`;
};
const fromISO = (s: string): J => {
  const [y, m, d] = s.split("-").map(Number);
  return toJalali(new Date(y, m - 1, d));
};
const key = (j: J) => j.jy * 10000 + j.jm * 100 + j.jd;

export const rangeLabel = (r: ISORange) => {
  if (!r) return undefined;
  const a = fromISO(r.from), b = fromISO(r.to);
  if (r.from === r.to) return `${fa(a.jd)} ${J_MONTHS[a.jm - 1]} ${fa(a.jy)}`;
  const sameYear = a.jy === b.jy;
  return `${fa(a.jd)} ${J_MONTHS[a.jm - 1]}${sameYear ? "" : " " + fa(a.jy)} — ` +
         `${fa(b.jd)} ${J_MONTHS[b.jm - 1]} ${fa(b.jy)}`;
};

export function JalaliRangeSheet({
  open, onClose, value, onChange, title = "بازهٔ تاریخ",
}: {
  open: boolean; onClose: () => void;
  value: ISORange; onChange: (r: ISORange) => void; title?: string;
}) {
  const today = React.useMemo(() => toJalali(new Date()), []);
  const [view, setView] = React.useState({ jy: today.jy, jm: today.jm });
  const [a, setA] = React.useState<J | null>(null);
  const [b, setB] = React.useState<J | null>(null);

  /* هر بار که شیت باز می‌شود، از مقدارِ فعلی شروع کن */
  React.useEffect(() => {
    if (!open) return;
    if (value) {
      const s = fromISO(value.from), e = fromISO(value.to);
      setA(s); setB(value.from === value.to ? null : e);
      setView({ jy: s.jy, jm: s.jm });
    } else {
      setA(null); setB(null);
      setView({ jy: today.jy, jm: today.jm });
    }
  }, [open, value, today.jy, today.jm]);

  const days = jDaysInMonth(view.jy, view.jm);
  const lead = col(fromJalali(view.jy, view.jm, 1));

  const step = (d: number) => {
    TAP();
    setView((s) => {
      let jm = s.jm + d, jy = s.jy;
      if (jm < 1) { jm = 12; jy--; }
      if (jm > 12) { jm = 1; jy++; }
      return { jy, jm };
    });
  };

  const tap = (jd: number) => {
    SELECT();
    const j: J = { jy: view.jy, jm: view.jm, jd };
    if (!a || (a && b)) { setA(j); setB(null); return; }   // شروعِ تازه
    if (key(j) < key(a)) { setB(a); setA(j); return; }      // عقب‌تر → جابه‌جا
    setB(j);
  };

  const lo = a ? key(a) : 0;
  const hi = b ? key(b) : a ? key(a) : 0;

  const apply = () => {
    if (!a) { onChange(null); onClose(); return; }
    const s = toISO(a), e = toISO(b ?? a);
    onChange(s <= e ? { from: s, to: e } : { from: e, to: s });
    onClose();
  };

  const cells: React.ReactNode[] = [];
  for (let i = 0; i < lead; i++) cells.push(<div key={`x${i}`} />);
  for (let d = 1; d <= days; d++) {
    const k = view.jy * 10000 + view.jm * 100 + d;
    const isA = a && k === key(a);
    const isB = b && k === key(b);
    const inside = lo && hi && k > lo && k < hi;
    const isToday = k === key(today);
    const edge = isA || isB;

    cells.push(
      <Pressable
        key={d}
        onPress={() => tap(d)}
        haptic={false}
        scale={0.88}
        ariaLabel={`${d} ${J_MONTHS[view.jm - 1]}`}
        style={{
          height: 42, display: "grid", placeItems: "center", position: "relative",
          /* نوارِ اتصالِ بازه پشتِ عدد کشیده می‌شود، نه دورش */
          background: inside ? v("accentSurface") : "transparent",
          borderRadius: inside ? 0 : 999,
        }}
      >
        {/* دو سرِ بازه رنگِ *تأکید* می‌گیرند نه رنگِ سطح: وگرنه از
            نوارِ میانی جدا نمی‌شوند و معلوم نیست بازه از کجا تا کجاست. */}
        {edge && (
          <i style={{
            position: "absolute", inset: "3px 1px", borderRadius: 999,
            background: v("accentStrong"),
            animation: `dayPop 260ms ${EASE.out} both`,
          }} />
        )}
        <span style={{
          position: "relative", fontSize: 13,
          fontWeight: edge ? 800 : isToday ? 800 : 600,
          color: edge ? v("accentStrongInk") : inside ? v("accentSurfaceInk") : v("ink"),
          borderBottom: isToday && !edge ? `2px solid ${v("accentStrong")}` : "2px solid transparent",
          lineHeight: 1.5,
        }}>{fa(d)}</span>
      </Pressable>
    );
  }

  return (
    <Sheet
      open={open}
      onClose={onClose}
      title={title}
      footer={
        <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 8 }}>
          <Button tone="ghost" onPress={() => { onChange(null); onClose(); }}>پاک کردن</Button>
          <Button onPress={apply}>تأیید</Button>
        </div>
      }
    >
      <div style={{ paddingBlock: 6 }}>
        {/* ماه و سال */}
        <div style={{ display: "flex", alignItems: "center", gap: 8, marginBottom: 12 }}>
          <Pressable onPress={() => step(-1)} scale={0.86} ariaLabel="ماه قبل"
            style={{ width: 40, height: 40, borderRadius: 13, display: "grid", placeItems: "center",
                     background: v("surfaceAlt"), color: v("inkMuted") }}>
            <IconBack size={16} stroke={2.2} />
          </Pressable>
          <div style={{ flex: 1, textAlign: "center", fontSize: 15, fontWeight: 800, color: v("ink") }}>
            {J_MONTHS[view.jm - 1]} {fa(view.jy)}
          </div>
          <Pressable onPress={() => step(1)} scale={0.86} ariaLabel="ماه بعد"
            style={{ width: 40, height: 40, borderRadius: 13, display: "grid", placeItems: "center",
                     background: v("surfaceAlt"), color: v("inkMuted") }}>
            <IconForward size={16} stroke={2.2} />
          </Pressable>
        </div>

        {/* روزهای هفته */}
        <div style={{ display: "grid", gridTemplateColumns: "repeat(7,1fr)", marginBottom: 4 }}>
          {WEEK.map((w) => (
            <div key={w} style={{ textAlign: "center", fontSize: 10.5, fontWeight: 800,
                                  color: v("inkFaint"), paddingBlock: 6 }}>{w}</div>
          ))}
        </div>

        {/* شبکهٔ روزها */}
        <div style={{
          display: "grid", gridTemplateColumns: "repeat(7,1fr)",
          borderRadius: R.field, overflow: "hidden",
        }}>{cells}</div>

        <div style={{ marginTop: 12, minHeight: 20, textAlign: "center",
                      fontSize: 11.5, fontWeight: 700, color: v("inkMuted") }}>
          {!a ? "روزِ شروع را بزن"
            : !b ? "حالا روزِ پایان را بزن — یا «تأیید» برای همین یک روز"
            : rangeLabel({ from: toISO(a), to: toISO(b) })}
        </div>
      </div>

      <style>{`@keyframes dayPop{ from{ transform:scale(.55); opacity:0 } to{ transform:none; opacity:1 } }`}</style>
    </Sheet>
  );
}
