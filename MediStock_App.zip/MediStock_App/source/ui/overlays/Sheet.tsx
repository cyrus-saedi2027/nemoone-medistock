/* ─────────────────────────────────────────────────────────────
 *  شیتِ پایین — قابلِ کشیدن، با فنرِ قابلِ گرفتن
 *
 *  ارتفاع را خودش می‌سنجد تا شیت‌های کوتاه بی‌خود بلند نشوند و
 *  شیت‌های بلند از قاب نزنند بیرون (سقف: ۸۶٪ ارتفاعِ قاب).
 *  جابه‌جایی مستقیم روی DOM — صفر رندر حینِ کشیدن.
 * ───────────────────────────────────────────────────────────── */

import * as React from "react";
import { createPortal } from "react-dom";
import { useSpringRef, useSpringBind } from "@/system/motion/useSpring";
import { useFrame } from "@/system/frame";
import { v } from "@/system/theme/ThemeProvider";
import { R, MOTION, Z, EASE, SHADOW } from "@/system/tokens";
import { PAD } from "@/ui/kit";
import { pushOverlay } from "@/ui/overlays/overlayStack";
import { OVERLAY_ID } from "@/ui/chrome/PhoneFrame";

export function Sheet({
  open, onClose, title, children, footer,
}: {
  open: boolean; onClose: () => void;
  title?: React.ReactNode; children: React.ReactNode; footer?: React.ReactNode;
}) {
  const { h } = useFrame();
  const onCloseRef = React.useRef(onClose);
  onCloseRef.current = onClose;
  const [mounted, setMounted] = React.useState(open);
  const panel = React.useRef<HTMLDivElement>(null);
  const height = React.useRef(400);
  const y = useSpringRef(1, MOTION.sheet);      // ۱ = پایین (بسته)
  const drag = React.useRef<{ y0: number; p0: number; t: number; last: number; v: number } | null>(null);

  /* `Math.max(0, x)` نگهبان است نه تزئین: پنل به `bottom:0` چسبیده و
     رو به پایین جابه‌جا می‌شود. اگر فنر ذره‌ای از صفر رد شود، پنل
     می‌رود *بالاتر* از جای خودش و زیرش یک نوارِ خالی از صفحهٔ پشت
     پیدا می‌شود. با این قید می‌شود میرایی را آزادانه تنظیم کرد. */
  const bind = useSpringBind<HTMLDivElement>(y, (el, x) => {
    el.style.transform = `translate3d(0,${(Math.max(0, x) * height.current).toFixed(2)}px,0)`;
  });
  React.useEffect(() => {
    if (open) setMounted(true);
  }, [open]);

  /* تا وقتی باز است در پشتهٔ لایه‌ها ثبت باشد تا Esc و دکمهٔ برگشتِ
     گوشی *اول* این را ببندند، نه اینکه از صفحه بپرند بیرون. */
  React.useEffect(() => {
    if (!open) return;
    return pushOverlay(onCloseRef.current);
  }, [open]);

  React.useLayoutEffect(() => {
    if (!mounted) return;
    height.current = Math.max(160, panel.current?.offsetHeight ?? 400);
    if (open) {
      y.set(1);
      requestAnimationFrame(() => y.springTo(0));
    } else {
      y.springTo(1, 0, () => setMounted(false));
    }
  }, [open, mounted, y]);

  if (!mounted) return null;

  /* به لایهٔ روپوش پورتال می‌شود تا از بافتِ چیدمانِ لایهٔ push بیرون
     بزند؛ وگرنه زیرِ نوارِ پایین می‌ماند و دکمه‌هایش کلیک نمی‌شوند. */
  const host = typeof document !== "undefined" ? document.getElementById(OVERLAY_ID) : null;

  const onPointerDown = (e: React.PointerEvent) => {
    (e.currentTarget as HTMLElement).setPointerCapture(e.pointerId);
    drag.current = { y0: e.clientY, p0: y.x, t: performance.now(), last: e.clientY, v: 0 };
  };
  const onPointerMove = (e: React.PointerEvent) => {
    const d = drag.current;
    if (!d) return;
    const now = performance.now();
    d.v = (e.clientY - d.last) / Math.max(1, now - d.t) / height.current;
    d.t = now; d.last = e.clientY;
    y.set(Math.max(0, Math.min(1.1, d.p0 + (e.clientY - d.y0) / height.current)));
  };
  const finish = () => {
    const d = drag.current;
    if (!d) return;
    drag.current = null;
    if (y.x > 0.36 || d.v * 1000 > 1.1) y.springTo(1, d.v * 1000, onClose);
    else y.springTo(0, d.v * 1000);
  };

  const body = (
    <div style={{ position: "absolute", inset: 0, zIndex: Z.sheet, pointerEvents: "none" }}>
      <div ref={bind} style={{
        position: "absolute", insetInline: 0, bottom: 0, willChange: "transform",
        pointerEvents: "auto",
      }}>
      <div
        ref={panel}
        style={{
          maxHeight: h * 0.86, display: "flex", flexDirection: "column",
          background: v("surface"),
          borderStartStartRadius: R.sheet, borderStartEndRadius: R.sheet,
          borderTop: `1px solid ${v("hair")}`,
          boxShadow: SHADOW.sheet,
        }}
      >
        {/* ناحیهٔ گرفتن عمداً بلندتر از خودِ دستگیره است — ۱۴ پیکسل
            هدفِ انگشت نیست. */}
        <div
          onPointerDown={onPointerDown}
          onPointerMove={onPointerMove}
          onPointerUp={finish}
          onPointerCancel={finish}
          style={{ padding: "14px 0 8px", flex: "none", touchAction: "none", cursor: "grab" }}
        >
          <div style={{ width: 42, height: 4, borderRadius: 99, background: v("divider"), margin: "0 auto" }} />
          {title && (
            <div style={{ marginTop: 10, paddingInline: PAD, fontSize: 15, fontWeight: 800, color: v("ink") }}>
              {title}
            </div>
          )}
        </div>
        <div style={{ overflowY: "auto", overscrollBehavior: "contain", paddingInline: PAD, paddingBottom: footer ? 4 : 22 }}>
          {children}
        </div>
        {footer && (
          <div style={{ flex: "none", padding: `12px ${PAD}px 22px`, borderTop: `1px solid ${v("divider")}` }}>
            {footer}
          </div>
        )}
      </div>
      </div>
    </div>
  );

  return host ? createPortal(body, host) : body;
}

/* ── توست ─────────────────────────────────────────────── */
export function ToastHost({
  items, onDrop,
}: {
  items: { id: number; text: string; tone?: "ok" | "warn" | "crit"; action?: { label: string; run: () => void } }[];
  onDrop: (id: number) => void;
}) {
  return (
    <div style={{
      position: "absolute", insetInline: 12, bottom: 128,
      zIndex: Z.toast, display: "grid", gap: 8, pointerEvents: "none",
    }}>
      {items.map((t) => (
        <div key={t.id} style={{
          pointerEvents: "auto",
          display: "flex", alignItems: "center", gap: 10,
          padding: "11px 14px", borderRadius: 16,
          background: v("deep"), color: v("onDark"),
          boxShadow: SHADOW.lifted,
          animation: `toastIn 320ms ${EASE.out} both`,
        }}>
          <i style={{
            width: 7, height: 7, borderRadius: 99, flex: "none",
            background: t.tone === "crit" ? v("crit") : t.tone === "warn" ? v("warn") : v("ok"),
          }} />
          <span style={{ flex: 1, fontSize: 12.5, fontWeight: 600 }}>{t.text}</span>
          {t.action && (
            <button type="button"
              onClick={() => { t.action!.run(); onDrop(t.id); }}
              style={{ background: "none", border: "none", padding: "2px 4px", cursor: "pointer",
                       fontFamily: "inherit", fontSize: 12, fontWeight: 800, color: v("accentStrong") }}>
              {t.action.label}
            </button>
          )}
        </div>
      ))}
    </div>
  );
}
