/* ─────────────────────────────────────────────────────────────
 *  اسکنِ QR — لایهٔ دوربین
 *
 *  اگر مرورگر دوربین‌خوان نداشته باشد، به‌جای پیامِ خطا، *واردکردنِ
 *  دستیِ کد* را نشان می‌دهد. انباردار همیشه راهی برای جلو رفتن دارد.
 * ───────────────────────────────────────────────────────────── */

import * as React from "react";
import { v } from "@/system/theme/ThemeProvider";
import { R, Z, EASE } from "@/system/tokens";
import { Button, Field } from "@/ui/kit";
import { Pressable } from "@/ui/primitives/Pressable";
import { IconX, IconQr } from "@/ui/icons";
import { startScan, cameraSupported, qrDecodeSupported, type ScanHandle } from "@/system/scan";
import { pushOverlay } from "@/ui/overlays/overlayStack";
import { SUCCESS } from "@/system/haptics";
import { toEn } from "@/system/i18n/digits";

export function ScanSheet({
  open, onClose, onCode,
}: {
  open: boolean;
  onClose: () => void;
  /** کدِ خام؛ تمیزکردنش با فراخوان است */
  onCode: (raw: string) => void;
}) {
  const videoRef = React.useRef<HTMLVideoElement>(null);
  const handle = React.useRef<ScanHandle | null>(null);
  const [err, setErr] = React.useState("");
  const [hint, setHint] = React.useState("");
  const [manual, setManual] = React.useState("");
  /**
   * `null` = هنوز نپرسیده‌ایم.
   *
   * قبلاً فقط `"BarcodeDetector" in window` را نگاه می‌کردیم. روی
   * اندروید این می‌تواند درست باشد ولی خودِ خواننده کار نکند، و
   * نتیجه‌اش دوربینی بود که باز می‌ماند و هیچ‌وقت چیزی پیدا نمی‌کرد.
   */
  const [canScan, setCanScan] = React.useState<boolean | null>(null);

  React.useEffect(() => {
    if (!open) return;
    /* پردهٔ مشترک لازم نیست: خودش تمامِ صفحه را مات می‌پوشاند. */
    return pushOverlay(onClose, { scrim: false });
  }, [open, onClose]);

  React.useEffect(() => {
    if (!open) { setCanScan(null); return; }
    let alive = true;
    setErr(""); setHint("");
    (async () => {
      const ok = cameraSupported() && (await qrDecodeSupported());
      if (alive) setCanScan(ok);
    })();
    return () => { alive = false; };
  }, [open]);

  React.useEffect(() => {
    if (!open || canScan !== true || !videoRef.current) return;
    let alive = true;
    startScan(
      videoRef.current,
      (text) => { if (alive) { SUCCESS(); onCode(text); } },
      (m) => { if (alive) setErr(m); },
      (m) => { if (alive) setHint(m); },
    ).then((h) => {
      handle.current = h;
      if (!alive) h.stop();
    });
    return () => {
      alive = false;
      handle.current?.stop();
      handle.current = null;
    };
  }, [open, canScan, onCode]);

  if (!open) return null;

  const showManual = canScan === false || !!err;

  return (
    <div
      style={{
        position: "absolute", inset: 0, zIndex: Z.sheet,
        background: "rgba(8,10,12,.92)",
        display: "flex", flexDirection: "column",
        animation: `tabIn 240ms ${EASE.out} both`,
      }}
    >
      <div style={{ display: "flex", alignItems: "center", gap: 10, padding: "14px 16px" }}>
        <div style={{ flex: 1, minWidth: 0, color: "#fff", fontSize: 15, fontWeight: 800 }}>
          اسکنِ بارکد
        </div>
        <Pressable onPress={onClose} scale={0.88} ariaLabel="بستنِ اسکنر"
          style={{ width: 38, height: 38, borderRadius: 13, display: "grid",
                   placeItems: "center", background: "rgba(255,255,255,.14)", color: "#fff" }}>
          <IconX size={17} stroke={2.2} />
        </Pressable>
      </div>

      {!showManual ? (
        <>
          <div style={{ position: "relative", flex: 1, minHeight: 0, overflow: "hidden" }}>
            <video ref={videoRef} muted playsInline
                   style={{ width: "100%", height: "100%", objectFit: "cover" }} />
            {/* کادرِ هدف — چشم را جایی می‌برد که باید ببرد */}
            <div style={{
              position: "absolute", insetInlineStart: "50%", top: "50%",
              width: "62%", aspectRatio: "1", transform: "translate(50%,-50%)",
              border: "2px solid rgba(255,255,255,.9)", borderRadius: 22,
              boxShadow: "0 0 0 4000px rgba(0,0,0,.35)",
            }} />
          </div>
          {/* بعد از ۹ ثانیه گشتنِ بی‌نتیجه، به‌جای سکوت راهنمایی می‌کند
              و راهِ دستی را نشان می‌دهد. */}
          <div style={{ padding: "16px 20px 26px", textAlign: "center",
                        color: "rgba(255,255,255,.75)", fontSize: 12, lineHeight: 2 }}>
            {hint || "بارکدِ روی برچسب را داخلِ کادر بگیرید"}
            {hint && (
              <div style={{ marginTop: 10 }}>
                <Pressable onPress={() => setErr("پیدا نشد")} scale={0.95}
                  style={{ display: "inline-flex", alignItems: "center", gap: 6,
                           padding: "9px 16px", borderRadius: 999, color: "#fff",
                           background: "rgba(255,255,255,.16)",
                           fontSize: 12, fontWeight: 800 }}>
                  واردکردنِ دستیِ کد
                </Pressable>
              </div>
            )}
          </div>
        </>
      ) : canScan === null ? (
        <div style={{ flex: 1, display: "grid", placeItems: "center",
                      color: "rgba(255,255,255,.7)", fontSize: 12.5 }}>
          در حالِ آماده‌کردنِ دوربین…
        </div>
      ) : (
        <div style={{ flex: 1, minHeight: 0, overflowY: "auto", padding: "8px 18px 24px" }}>
          <div style={{ display: "grid", placeItems: "center", gap: 12, padding: "26px 0" }}>
            <div style={{ width: 56, height: 56, borderRadius: 18, display: "grid",
                          placeItems: "center", background: "rgba(255,255,255,.12)", color: "#fff" }}>
              <IconQr size={24} stroke={1.8} />
            </div>
            <div style={{ color: "#fff", fontSize: 13.5, fontWeight: 800, textAlign: "center" }}>
              {err || "این دستگاه دوربین‌خوان ندارد"}
            </div>
            <div style={{ color: "rgba(255,255,255,.62)", fontSize: 11.5,
                          lineHeight: 1.9, textAlign: "center", maxWidth: 260 }}>
              کدِ روی برچسب را دستی وارد کنید — همان عددی که بعد از ‎# چاپ شده.
            </div>
          </div>

          <div style={{ background: v("card"), borderRadius: R.card, padding: 16 }}>
            <Field label="کدِ کالا" value={manual} onChange={setManual} ltr
                   inputMode="numeric" placeholder="0001" autoFocus />
            <div style={{ height: 12 }} />
            <Button disabled={!toEn(manual).replace(/\D/g, "")}
                    onPress={() => onCode(toEn(manual).replace(/\D/g, ""))}>
              پیدا کن
            </Button>
          </div>
        </div>
      )}
    </div>
  );
}
