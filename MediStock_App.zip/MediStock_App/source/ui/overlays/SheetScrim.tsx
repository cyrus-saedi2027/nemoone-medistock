/* ─────────────────────────────────────────────────────────────
 *  پردهٔ مشترکِ شیت‌ها — یکی برای همه
 *
 *  تا نسخهٔ ۱٫۴٫۲ هر شیت پردهٔ خودش را داشت. وقتی یک شیت جای شیتِ
 *  دیگری را می‌گرفت — و در «ورود کالا» دقیقاً همین می‌شود:
 *
 *      انتخابِ کالا → انتخابِ پارت → پارتِ جدید
 *
 *  دو پرده هم‌زمان روی هم بودند؛ یکی محو می‌شد و دیگری ظاهر. چون
 *  شفافیت ضرب می‌شود نه جمع، وسطِ کار تیرگیِ مؤثر از ۰٫۴۲ به ۰٫۲۶
 *  می‌افتاد و دوباره برمی‌گشت. یعنی هر بار عوض شدنِ شیت، پس‌زمینه یک
 *  «پلک» می‌زد. همان چیزی که خشک و تکه‌تکه دیده می‌شد.
 *
 *  حالا یک پرده هست که فقط به «هیچ شیتی باز است یا نه» نگاه می‌کند.
 *  بینِ دو شیت اصلاً تکان نمی‌خورد.
 * ───────────────────────────────────────────────────────────── */

import * as React from "react";
import { useSpringRef, useSpringBind } from "@/system/motion/useSpring";
import { MOTION, Z } from "@/system/tokens";
import { subscribeOverlays, closeTopOverlay } from "@/ui/overlays/overlayStack";

export function SheetScrim() {
  const [any, setAny] = React.useState(false);
  const [mounted, setMounted] = React.useState(false);
  const k = useSpringRef(0, MOTION.sheet);

  React.useEffect(() => subscribeOverlays((n) => setAny(n > 0)), []);

  const bind = useSpringBind<HTMLDivElement>(k, (el, x) => {
    /* توانِ ۱٫۶ چون چشم روشناییِ خطی را «کند در اول، تند در آخر»
       می‌بیند؛ همان چیزی که حرکت را خشک نشان می‌دهد. */
    el.style.opacity = (Math.max(0, x) ** 1.6).toFixed(3);
  });

  React.useEffect(() => {
    if (any) setMounted(true);
  }, [any]);

  React.useLayoutEffect(() => {
    if (!mounted) return;
    if (any) k.springTo(1);
    else k.springTo(0, 0, () => setMounted(false));
  }, [any, mounted, k]);

  if (!mounted) return null;

  return (
    <div
      ref={bind}
      onClick={() => closeTopOverlay()}
      style={{
        position: "absolute", inset: 0, zIndex: Z.sheet - 1,
        background: "rgba(24,20,14,.42)", opacity: 0, pointerEvents: "auto",
      }}
    />
  );
}
