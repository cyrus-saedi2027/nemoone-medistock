/* ─────────────────────────────────────────────────────────────
 *  پشتهٔ لایه‌های رویی
 *
 *  هر شیتِ باز خودش را اینجا ثبت می‌کند. دو مصرف‌کننده دارد:
 *
 *    Esc            → بالاترین لایه بسته می‌شود
 *    دکمهٔ برگشتِ گوشی → *اول* لایه بسته می‌شود، نه اینکه صفحه عوض شود
 *
 *  بدونِ این، کاربر با دکمهٔ برگشتِ اندروید از وسطِ یک شیت می‌پرید بیرون
 *  و — بدتر — پردهٔ شیت روی صفحه می‌ماند و همه‌چیز را می‌بلعید.
 * ───────────────────────────────────────────────────────────── */

type Closer = () => void;
type Entry = { close: Closer; scrim: boolean };

const stack: Entry[] = [];

/* ── چرا «چند تا» کافی نیست ───────────────────────────────
 * پردهٔ مشترک فقط باید برای لایه‌هایی بیاید که خودشان پس‌زمینه
 * ندارند. `ScanSheet` تمامِ صفحه را با رنگِ تقریباً مات می‌پوشاند؛
 * اگر پرده را هم بالا می‌آورد، موقعِ بستنش یک موجِ تیرهٔ بی‌دلیل
 * پشتِ سرش می‌ماند. پس هر لایه خودش می‌گوید پرده می‌خواهد یا نه. */
const watchers = new Set<(n: number) => void>();
const scrimCount = () => stack.reduce((n, e) => n + (e.scrim ? 1 : 0), 0);
const tell = () => { const n = scrimCount(); for (const w of watchers) w(n); };

export function subscribeOverlays(fn: (n: number) => void): () => void {
  watchers.add(fn);
  fn(scrimCount());
  return () => { watchers.delete(fn); };
}

export function pushOverlay(close: Closer, opts?: { scrim?: boolean }): () => void {
  const e: Entry = { close, scrim: opts?.scrim !== false };
  stack.push(e);
  tell();
  return () => {
    const i = stack.lastIndexOf(e);
    if (i >= 0) { stack.splice(i, 1); tell(); }
  };
}

export const overlayCount = () => stack.length;

/** بالاترین لایه را ببند. اگر چیزی باز بود `true` برمی‌گرداند. */
export function closeTopOverlay(): boolean {
  const e = stack.pop();
  if (!e) return false;
  tell();
  e.close();
  return true;
}

if (typeof window !== "undefined") {
  window.addEventListener("keydown", (e) => {
    if (e.key === "Escape" && closeTopOverlay()) e.preventDefault();
  });
}
