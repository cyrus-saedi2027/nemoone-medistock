# What to take, what to adapt, what to leave

Written for a model building a different app from this reference. Honest
about what generalises and what does not.

---

## Take as-is

These are framework-light, dependency-free, and solve problems every mobile
app has.

### 1. The motion engine — `system/motion/`
`spring.ts` + `ticker.ts` are plain TypeScript with no React import. Drop
them into any project. `useSpring.ts` is the only React-aware file and is 60
lines; rewriting it for Vue or Svelte is trivial.

**Why bother over a library:** zero re-renders, interruptible gestures, and
`set()`/`springTo(target, v0)` giving you grabbable animation almost for free.

### 2. The token layer — `system/tokens.ts`
Not the values — the *shape*. Radii named for what they wrap (`R.card`, not
`R.lg`), gesture thresholds in one table, spring presets with damping ratios
reasoned about rather than guessed, and a comment on each saying what went
wrong before.

### 3. CSS-variable theming — `system/theme/ThemeProvider.tsx`
Typed palette in TS, applied as CSS custom properties, accessed through
`v("key")` with `keyof Palette`. Theme switching costs zero renders, typos
are compile errors, and `colorScheme` + `theme-color` stay in sync.

Take the **default-generation counter** too. It is the part everyone forgets,
and without it a changed default theme never reaches existing users.

### 4. `Pressable` — `ui/primitives/Pressable.tsx`
Specifically for the `pointerup`-on-`window` listener. If you write your own
press component without it, children will stick in the pressed state whenever
a parent gesture captures the pointer, and you will lose an afternoon to it.

### 5. `overlayStack.ts`
58 lines so the back gesture closes the top overlay instead of navigating
away. Nearly always missing from hand-rolled sheets.

### 6. `VirtualList.tsx`
80 lines, fixed-height rows, no dependency. Enough for most lists. (Needs
replacing if your rows vary in height.)

### 7. The RTL boundary rule — `system/dir.ts`
If you are building RTL, read this before writing a single transform. The
rule (physical→logical on input, logical→physical on output, never both) is
37 lines and prevents a whole category of bug.

---

## Adapt

### `Sheet.tsx`
The drag/release maths is correct and worth copying. Self-measuring height
and the 86% cap may not suit your layout.

### `ScreenScroll.tsx`
Elastic overscroll and pull-to-refresh, good patterns both. Tied to the
phone-frame geometry, so the measurement part needs reworking.

### `Router.tsx`
A hand-written stack navigator with interactive swipe-back. Read it for the
transition and gesture handling; use a real router if you have deep linking,
many routes, or need URL state.

### `kit.tsx`
Solid plain-React components with no dependencies. Likely to be replaced by
your own design language — but `Field`, `Stepper` and `Switch` are worth
reading for the details (hold-to-repeat, `ltr` on Latin-only inputs, the
spring-driven knob).

---

## Leave

### `PhoneFrame.tsx`
Scaling a fixed 390×844 design frame to the viewport. Fine for a
phone-only installed app; wrong for anything responsive.

### The screens
Composition examples only — they import a store that is not in this folder
and will not compile.

### The Jalali calendar and Persian i18n
Unless you need them. If you do, they are complete and correct.

### The domain model
Pharmacy inventory: batches, expiry, warehouses, stocktake. Specific.

---

## Patterns worth copying even without the code

**Comment the failure, not the function.** Almost every unusual number here
has a note saying what broke before it got that value. That is what stops the
next person — or the next model — from "tidying" it back and reintroducing
the bug. Examples: `GESTURE.edgeBail` (a thumb arcs from the edge),
`MOTION.sheet.precision` (snapping near the end), `useSpringBind` (an early
return that silently killed every sheet).

**Put all thresholds of one kind in one table.** When a gesture feels wrong,
the fix is a number. Having them scattered means tuning by search.

**Decide the physical/logical boundary once, in writing.** Applies to RTL,
and equally to scroll direction, inverted axes and mirrored layouts.

**Measure velocity over a time window, not two samples.** 90ms here. Two
samples is the most common flick bug there is.

**Resist at limits, don't clamp.** Clamping feels dead; rubber-banding keeps
the finger connected to the surface.

**Order thresholds to resolve gesture conflicts.** Rows lock at 6px, tabs at
8px — so rows win. Cheaper and more predictable than a state machine.

**Say what is stuck, in the user's words.** `PendingSheet` exists because
"29 records pending" is not something the person who owns the stock can check
against a shelf. If your app has an offline queue, let people see inside it.

**Treat reduced-motion in the engine.** One place, and every call site works
unchanged with animation off — including the completion callbacks.

---

## Reading order for a model

1. `system/tokens.ts` — the vocabulary; read every comment
2. `system/motion/spring.ts` + `ticker.ts` — the engine
3. `system/motion/useSpring.ts` — how it reaches React, and the bug comment
4. `ui/overlays/Sheet.tsx` — the engine applied to a real interruptible gesture
5. `system/theme/palettes.ts` (the `mono` theme and the `Palette` type)
6. `ui/kit.tsx` — the component vocabulary
7. `router/Router.tsx` — transitions and swipe-back
8. One screen, e.g. `screens/tabs/Catalog.tsx`, for composition

The comments are in Persian and carry the reasoning. Read them.
