# Performance

The constraint behind every decision in this codebase: **a mid-range Android
phone, a weak connection, and a user who is standing up and in a hurry.**

Nothing here is premature. Each item below exists because something was
measurably slow, and most carry a comment naming the number.

---

## 1. Animation writes to the DOM, not to state

The single biggest one. A spring delivering its value through `setState`
re-renders the owning subtree 60 times a second. When the thing being
animated is a whole screen, that is the difference between smooth and not.

```ts
spring.subscribe((x) => { el.style.transform = `translate3d(0,${x}px,0)`; });
```

Zero renders per frame. See [`01-motion.md`](01-motion.md).

## 2. One rAF loop for every spring

Per-spring `requestAnimationFrame` means four competing loops when a sheet
drags while a row swipes and the nav slides. One shared loop, which sleeps
when the set is empty.

## 3. Shadow blur radius is a performance decision

```ts
rowDark: "0 6px 14px -10px rgba(0,0,0,.55)",
```

> The blur radius is small because 23 rows are visible at once, and a larger
> blur took p95 frame time from 33ms to 50ms on a mid-range Android.
> *Measured.*

A 1px hairline (`hair`) carries the card separation instead, because painting
a border is free and painting a large blur is not.

## 4. Backdrop blur is off by default

```ts
export const FROST = { enabled: false };
```

Frosted glass is the most expensive common effect on mid-range Android. The
flag exists so it can be enabled on a capable device, not so it can be
forgotten in the on position.

## 5. Virtualised list for ~5,000 rows

[`VirtualList.tsx`](../source/ui/list/VirtualList.tsx), 80 lines: render a
window plus overscan, use padding rather than absolute positioning so no
layout reads are needed during scroll.

## 6. The base catalogue is never written to local storage

~5,000 products ≈ 1.4MB. Serialising that on every change is a visible lock-up
on a mid-range phone. It is fetched once as a static JSON file and cached by
the service worker; only user-created rows and manual overrides are persisted.

Persistence itself is debounced and runs in `requestIdleCallback`, so a write
never lands mid-animation or mid-scroll.

## 7. Search keys are precomputed, server-side

Each catalogue row ships with a `k` field: name + Latin name + code, already
normalised. The server builds it, because the phone would otherwise rebuild
~5,000 normalised strings on every sync.

> The comment is explicit that the client and server normalisers must stay
> identical — if they drift, products created on the server stop being
> findable in the app and nobody can work out why.

## 8. Sync sends deltas, and only touched rows

- `GET /api/state?since=N` returns **204 with no body** if nothing changed.
- After an operation, the response carries only the products that operation
  touched, not all 5,000 rows.

The comment records why the second one was added: the full array was ~800KB,
and on the pharmacy's connection the response was being cut off mid-flight —
so a keeper entering twenty items in a row waited for the whole catalogue
twenty times.

## 9. Transitions respect `prefers-reduced-motion` inside the spring

Handled once, in the engine, including still firing `onRest` so nothing that
unmounts after a transition leaks. No call site needs to know.

## 10. Icons are hand-drawn SVG, not a library

~40 icons on a shared 24×24 grid. No icon package, no tree-shaking question,
no runtime font.

---

## Bundle

```
index.js   274 KB   (84 KB gzipped)
vendor.js  142 KB   (45 KB gzipped)   ← React + ReactDOM
xlsx.js     10 KB   ( 3 KB gzipped)   ← lazy, spreadsheet export only
```

React is the largest single dependency, and the only one that is not
application code. The app ships **two** runtime dependencies in total:
`react` and `react-dom`.

---

## The service worker

Cache-first for assets, network-first for data, with a version constant
(`medistock-v7`) that invalidates the shell on deploy.

One lesson embedded there is worth repeating. Icons are served under fixed
names (`/icons/icon-192.png`). Under cache-first, an installed app **never
re-requests them** — so when the icon colour changed from amber to black,
every existing install kept the cached amber one indefinitely. The fix was
bumping the cache version; the better fix is version-stamped asset URLs.

---

## What was *not* done

Stated honestly:

- No code splitting beyond the lazy spreadsheet module. The app is small
  enough that route-level splitting would add latency on navigation for a
  marginal first-load gain.
- No image optimisation pipeline. There are almost no images — the UI is
  type, colour and SVG.
- No SSR. It is an installed PWA; the first paint is from cache.
- No memoisation sprinkled across components. The hot paths bypass React
  entirely, so `React.memo` would be solving a problem that does not exist
  here. A handful of `useMemo` calls exist where a list is genuinely derived.
