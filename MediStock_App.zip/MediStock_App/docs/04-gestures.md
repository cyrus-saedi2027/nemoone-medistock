# Gestures

All gesture thresholds live in one place — `GESTURE` in
[`system/tokens.ts`](../source/system/tokens.ts) — and every number there was
changed at least once because of a real complaint. The comments record which.

---

## The thresholds

```ts
export const GESTURE = {
  edgeOnly: true,
  edgeInset: 56,          // edge strip — starts immediately
  anywhereLock: 16,       // horizontal travel needed to start mid-screen
  edgeBail: 30,           // vertical slack before an edge swipe is cancelled
  anywhereBail: 22,       // stricter mid-screen, where scrolling competes
  axisRatio: 1.5,         // horizontal must beat vertical by this much
  backCommit: 0.26,       // fraction of width that commits the back
  backFlick: 0.65,        // widths per second that commits regardless
  backCancelFlick: -1.0,
  velWindow: 90,          // ms window for velocity sampling
  tabCommit: 0.3,
  tabLock: 8,
  rowLock: 6,             // rows lock before tabs, so rows win
  rowOpen: 76,
  rubber: 0.28,
  longPressMs: 420,
  longPressSlop: 8,
};
```

---

## Swipe-back: two ways in

Originally the back gesture only started from a 38px edge strip and needed
34% of the screen width to commit. Together that read as *barely works*.

It now has two entry points:

1. **From the edge strip** (`edgeInset: 56`) — starts immediately, no
   threshold. Your thumb is already there on purpose.
2. **From anywhere else** — but only once the movement is unambiguously
   horizontal (`anywhereLock: 16`, `axisRatio: 1.5`).

The second path is only safe because this app has no other horizontal
gesture on list rows. The one exception is horizontal scrollers, which are
tagged `data-hstrip` and opt out.

### `edgeBail` is the fix most implementations miss

A thumb starting from the screen edge **always arcs**. The original code used
the same vertical tolerance everywhere, so about 12px of natural hand curve
silently cancelled the gesture — the classic "sometimes it works, sometimes
it doesn't". Edge swipes now tolerate 30px of vertical drift; mid-screen
swipes, where vertical scrolling is a real competitor, tolerate 22px.

### Commit by distance *or* by flick

```
committed = travelled > 26% of width  ||  velocity > 0.65 widths/second
```

Either one. A fast short flick should go back; a slow long drag should go
back. Requiring both makes the gesture feel heavy; requiring only distance
makes flicking feel broken.

### `velWindow: 90`

Velocity is averaged over the last 90ms rather than the last two pointer
samples. Two samples are far too noisy — a single jittery event at release
sends the sheet the wrong way. This is the single most common bug in
hand-written flick handling.

---

## Gesture priority: rows beat tabs

```ts
tabLock: 8,
rowLock: 6,   // rows lock first, so rows win
```

Both a tab pan and a row swipe respond to horizontal movement in the same
area. Rather than arbitrating with flags, the thresholds are ordered: the row
claims the pointer at 6px, before the tab's 8px is reached. The conflict is
resolved by a number, not by a state machine.

---

## Rubber-banding

```ts
rubber: 0.28
```

Past a limit, further movement is multiplied by 0.28, so the surface keeps
responding but visibly resists. Used by both `ScreenScroll` overscroll and
`Sheet` drag.

The important half: **resistance must be applied to displacement, not by
clamping.** Clamping makes the surface feel dead at the limit; resistance
keeps the finger connected to it.

---

## Press feedback and long press

```ts
longPressMs: 420,
longPressSlop: 8,
```

420ms is slightly above the usual 300–400, deliberately: this app is used in
a hurry, and a faster long-press fired on ordinary taps. 8px of slop keeps it
alive through a normal unsteady finger.

Press feedback itself is a CSS transition rather than a spring — `scale
0.955` over 280ms with `EASE.out`. A press is not interruptible, so the extra
machinery of a spring buys nothing.

---

## Haptics

[`system/haptics.ts`](../source/system/haptics.ts) wraps `navigator.vibrate`
behind two named calls — `TAP()` and `IMPACT()` — so firing patterns are not
scattered through the UI, and the whole thing can be disabled in one place.
`TAP` on every press; `IMPACT` only when something commits (a refresh
triggers, a sheet snaps).

---

## General lessons

1. **Put every threshold in one table.** When a gesture feels wrong, the fix
   is a number, and you want all the numbers in one place to compare.
2. **Write down what broke.** Almost every value here has a comment naming
   the complaint that changed it. That is what stops someone "tidying" it
   back to a round number.
3. **Measure velocity over a window, not two samples.**
4. **Order thresholds to resolve conflicts.** Cheaper and more predictable
   than a state machine.
5. **Resist, do not clamp, at limits.**
