# The motion system

The most portable thing in this repo. Three files, ~210 lines total, and
every moving pixel in the app goes through them.

- [`system/motion/spring.ts`](../source/system/motion/spring.ts) — the physics
- [`system/motion/ticker.ts`](../source/system/motion/ticker.ts) — one shared rAF loop
- [`system/motion/useSpring.ts`](../source/system/motion/useSpring.ts) — the React bridge

---

## Why hand-rolled instead of a library

Three reasons, in order of how much they mattered:

1. **Re-render cost.** Most React spring libraries deliver the value through
   state. At 60fps that re-renders the owning subtree 60 times a second. When
   the thing being animated is a whole screen, that is the difference between
   smooth and not on a mid-range Android.
2. **Grabbability.** A sheet you can catch mid-flight needs the animation to
   surrender position control to the finger instantly and hand back a
   velocity on release. Most libraries make this awkward.
3. **Size.** The entire engine is smaller than the import cost of a library.

---

## The spring

Semi-implicit Euler, which is what most reference implementations use, so
stiffness/damping numbers transfer from other systems:

```ts
step(dt) {
  const a = (-this.k * (this.x - this.target) - this.c * this.v) / this.m;
  this.v += a * dt;
  this.x += this.v * dt;
  // settle when both displacement and velocity are below precision
}
```

Three things in that class are worth copying verbatim:

### `set()` — what makes a gesture feel alive

```ts
set(x) {
  this.held = true;    // stop integrating
  leave(this);         // drop out of the rAF loop
  this.x = x;
  this.v = 0;
  this.target = x;
  this.emit();
}
```

While a finger is down, the spring is not animating — it *is* the finger.
`held` makes `step()` a no-op, so there is no fight between physics and
input. On release, `springTo(target, v0)` sets `held = false` and rejoins
the loop with the finger's exit velocity.

This is the whole trick behind "I can catch the sheet halfway and throw it
back."

### `step()` returns a boolean

`true` means "still moving, keep me". `false` means "I have settled, drop
me." The ticker uses the return value to prune itself, so a spring at rest
costs nothing and the loop stops entirely when the set is empty.

### Reduced motion is handled in the spring, not at call sites

```ts
if (REDUCED) {
  this.x = target; this.v = 0;
  this.emit();
  onRest?.();            // still fires — callers depend on it
  return;
}
```

Jumping to the target *and still firing `onRest`* means every caller works
unchanged with animation off. If `onRest` were skipped, anything that
unmounts after a transition would leak. The media query is also watched live,
so toggling the OS setting takes effect without a reload.

---

## The shared ticker

Each spring having its own `requestAnimationFrame` is the obvious design and
it is wrong. When a sheet is being dragged while a row swipes, the nav pill
slides and the scroll bounces, that is four loops competing for one frame.

One loop, one `Set`:

```ts
function frame(now) {
  const dt = last ? Math.min((now - last) / 1000, 1 / 30) : 1 / 60;
  last = now;
  for (const t of Array.from(live)) if (!t.step(dt)) live.delete(t);
  if (live.size) raf = requestAnimationFrame(frame);
  else { raf = 0; last = 0; }     // sleep
}
```

Two details that matter:

- **`dt` is clamped to 1/30.** After a dropped frame — a GC pause, a slow
  paint — an unclamped `dt` makes every spring jump visibly. Clamping trades
  exact timing for never looking broken.
- **Iteration over a copy.** `step()` can remove the spring from the set
  (via `onRest` → unmount → `dispose`), and mutating a `Set` mid-iteration
  skips entries.

---

## The React bridge: two paths, deliberately separate

### Hot path — `useSpringBind`

Writes straight to the DOM node. **Zero re-renders.**

```tsx
const y = useSpringRef(1, MOTION.sheet);
const bind = useSpringBind<HTMLDivElement>(y, (el, x) => {
  el.style.transform = `translate3d(0,${(Math.max(0, x) * height.current).toFixed(2)}px,0)`;
});
return <div ref={bind}>…</div>;
```

Use this for anything sitting above a large subtree: screen transitions,
sheets, scroll bounce, swipeable rows, the nav pill.

> There is a long comment in `useSpring.ts` about an early `if (!el.current)
> return` in this hook. A closed sheet rendered `null`, so there was no node
> when the effect ran, so it bailed — and since the dependency array was
> `[spring]` and the spring never changes, **the effect never ran again**.
> Every sheet in the app appeared instantly with no animation at all. Worth
> reading before you write a similar hook.

### Cold path — `useSpringState`

Puts the value through React state, with a threshold to avoid pointless
renders:

```ts
spring.subscribe((v) => setX((p) => (Math.abs(p - v) > 0.0005 ? v : p)));
```

Only for small subtrees — a 4-button segmented control, a tabbed card.

---

## The presets, and why damping ratio is the number to think about

From [`system/tokens.ts`](../source/system/tokens.ts):

| Preset | k | c | ζ (damping ratio) | Used for |
|---|---|---|---|---|
| `cradle` | 210 | 21 | 0.72 | the nav pill — the app's signature feel |
| `swipe` | 240 | 29 | 0.94 | screen back-swipe |
| `sheet` | 170 | 25 | 0.96 | bottom sheets |
| `flight` | 260 | 27 | 0.84 | shared-element transitions |
| `thumb` | 300 | 26 | 0.75 | switch knobs |
| `row` | 340 | 34 | 0.92 | list row swipe |
| `bounce` | 420 | 32 | 0.78 | overscroll |

ζ = c / (2·√(k·m)). Below 1 is underdamped — it overshoots and settles.
Around 0.7–0.8 reads as "alive but not cartoonish". At 0.95+ it arrives and
stops dead, which users describe as *stiff* or *lifeless* rather than fast.

The `sheet` comment records exactly this process: it was `200/26` (ζ ≈ 0.92),
the client said it felt abrupt, and the comment explains retuning it to
`185/21` (ζ ≈ 0.77) to sit near the `cradle` signature.

> **Note a real inconsistency here.** The shipped value is `170/25`, which is
> ζ ≈ 0.96 — *more* damped than what it replaced, and not what the comment
> above it describes. Somebody adjusted the numbers after writing the comment
> and did not update the prose. It is left as-is rather than quietly
> corrected, because it is a useful illustration: a comment that records
> reasoning is enormously valuable, and it is also the thing most likely to
> go stale. If you copy this pattern, make the reasoning comment part of what
> you review when the number changes.

### `precision` is in the units of the value, and this bites

A spring driving pixels wants `precision` around 0.25. A spring driving a
normalised 0→1 progress wants about 0.002.

`sheet` was once `0.4` while carrying a 0→1 value. The spring considered
itself settled the moment it got within 40% of the target and **snapped the
rest of the way**. The result looked like "it flies up and stops hard" and
was mistaken for a stiffness problem for a while. If a transition looks like
it teleports near the end, check `precision` before touching `stiffness`.

---

## Shape of a draggable sheet

The full implementation is [`ui/overlays/Sheet.tsx`](../source/ui/overlays/Sheet.tsx).
The pattern:

1. One spring carrying 0 (open) → 1 (closed).
2. Measure the panel height on mount; the writer multiplies by it, so the
   spring stays unit-less and the same numbers work for any sheet size.
3. On `pointerdown`, record y and `spring.set(current)`.
4. On `pointermove`, `spring.set(clamp(start + dy / height))` — and apply
   rubber-banding past the limits.
5. On `pointerup`, compute velocity over a short trailing window
   (`GESTURE.velWindow`, 90ms — two samples proved too noisy) and
   `springTo(0 or 1, velocity)` depending on distance *and* flick speed.
6. `onRest` at 1 unmounts.

`Math.max(0, x)` in the writer is load-bearing, not cosmetic: the panel is
pinned to `bottom: 0`, so a spring that overshoots below zero lifts it off
the bottom edge and reveals a strip of the screen behind. Clamping there
lets the damping be tuned freely.

---

## If you take one thing

The `Spring` + `ticker` pair, unchanged. They are framework-agnostic — only
`useSpring.ts` knows about React, and it is 60 lines. The same two files work
behind Vue, Svelte, or no framework at all.
