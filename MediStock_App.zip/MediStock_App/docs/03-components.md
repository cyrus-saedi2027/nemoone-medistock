# Component catalogue

What exists, what each is for, and which ones are worth lifting.

Legend: **★** = portable, take it as-is · **◐** = good pattern, needs adapting ·
**○** = app-specific, read for ideas only

---

## Primitives — `source/ui/primitives/`

### ★ `Pressable.tsx` (67 lines)
The press-feedback wrapper. Scales to 0.955 on pointer-down, fires haptics,
restores on release.

The detail worth copying is the `pointerup` listener on **`window`**, not the
element:

> When a parent grabs the pointer — a tab pan, a row swipe — the child never
> receives its own `pointerup` and **stays visually pressed forever**.
> Listening on `window` is the fix.

It also threads `aria-label`, `aria-current`, `role` and `aria-checked`
through, with comments on why each is needed (a screen reader cannot tell
which tab is active from colour alone).

### ★ `Motion.tsx` (40 lines)
Thin `Fade` / mount-transition helpers for cases that do not need a spring.

---

## Chrome — `source/ui/chrome/`

### ★ `ScreenScroll.tsx` (159 lines)
The scroll container. Two jobs:

1. **Elastic overscroll at both ends.** A PWA gets no rubber-banding from
   the browser, and without it the app feels like a web page instead of an
   app. Driven by `MOTION.bounce`, written straight to the DOM.
2. **Pull-to-refresh**, with a haptic `IMPACT` at the trigger threshold.

Note what it *stopped* doing: it used to mask content under the nav bar.
Content is no longer clipped — `NavScrim` just fades it slightly so the
boundary reads. Clipping lost the last row.

### ★ `PillNav.tsx` (83 lines)
The floating bottom nav. The active pill slides between tabs on the `cradle`
spring — ζ ≈ 0.72, the softest in the app, and deliberately the piece that
defines its character.

### ◐ `PhoneFrame.tsx` (80 lines)
Scales the fixed 390×844 design frame to the real viewport and exposes the
result through `useFrame()`. Useful if you are building phone-shaped, a
problem if you are not.

### ◐ `Header.tsx`, `NavScrim.tsx`, `Backdrop.tsx`
Sticky header with scroll-linked collapse; the gradient scrim under the nav;
the page background. `Backdrop` pairs with `system/geometry/backdrop.ts`,
which holds the single source of truth for where content ends.

### ○ `OfflineBar.tsx`, `PendingSheet.tsx`
App-specific, but a genuinely good pattern underneath: **when sync breaks,
say what is stuck, in the user's terms, and make it tappable.**

`PendingSheet` lists every unsent operation as "drug · in/out · quantity ·
date". It exists because a counter reading "29 records pending" is not
something the person who owns the stock can check against a shelf. If your
app has an offline queue, copy this idea.

---

## Overlays — `source/ui/overlays/`

### ★ `Sheet.tsx` (175 lines)
The draggable bottom sheet. Measures its own height so short sheets do not
stretch and tall ones cap at 86% of the frame. Fully interruptible — catch
it mid-flight, throw it back. See [`01-motion.md`](01-motion.md) for the
drag/release maths and the `Math.max(0, x)` clamp that is load-bearing.

### ★ `overlayStack.ts` (58 lines)
A tiny stack so the hardware/gesture back button closes the **topmost**
overlay rather than navigating away. Small, and the first thing that is
missing from most hand-rolled sheet implementations.

### ◐ `SheetScrim.tsx`
The dimming layer, with opacity tied to sheet position rather than toggled.

### ○ `JalaliRange.tsx` (209 lines)
A Persian-calendar date-range picker. Specific, but a real worked example of
a non-Gregorian calendar UI.

### ○ `ScanSheet.tsx`
Barcode scanning via `BarcodeDetector` with a graceful fallback.

---

## Lists — `source/ui/list/`

### ★ `VirtualList.tsx` (80 lines)
Windowed list in 80 lines. It renders a slice plus an overscan margin and
spaces with padding rather than absolute positioning. Handles the ~5,000-row
catalogue on a mid-range phone.

If you need variable row heights it will not serve you — it assumes a fixed
height. For uniform rows it is all the virtualisation most apps need.

### ◐ `SearchFilters.tsx` (278 lines)
Filter chips plus an expanding panel. Worth reading for the pattern of
keeping filter state in the URL/route rather than component state.

### ◐ `HStrip.tsx` (51 lines)
Horizontal scroller. Tagged `data-hstrip` so the global back-swipe gesture
knows to ignore horizontal movement here — see [`04-gestures.md`](04-gestures.md).

---

## Text — `source/ui/text/Text.tsx` (91 lines)

★ Handles the mixed-script problem: Persian text is RTL, but product codes,
Latin drug names and version numbers are LTR and must not be reordered by
the bidi algorithm. Exports `<Num>` (Persian digits with `٬` grouping) and
`<Lat>` (forces LTR for an inline Latin run).

Every number shown to a user goes through `<Num>`. Consistency here is what
stops an app from looking half-translated.

---

## Kit — `source/ui/kit.tsx` (579 lines)

The general component set. All of it is reusable; all of it is plain React
with inline styles and no dependencies.

| | |
|---|---|
| `Button` | primary / ghost / danger, with loading state |
| `Field` | labelled input; `ltr` prop for Latin-only fields |
| `Stepper` | numeric +/− with hold-to-repeat |
| `Switch` | toggle on the `thumb` spring |
| `Segmented` | segmented control, animated indicator |
| `Card`, `LightRow`, `DarkRow` | surfaces and list rows |
| `Chip`, `SectionLabel`, `StatBlock` | labels, section headers, metric tiles |
| `PickerRow`, `ChoiceRow` | selection rows for sheets |
| `Ring` | circular progress |
| `Empty` | empty state with icon and message |
| `IconSquare` | rounded icon container |
| `Gap`, `Pad`, `PAD`, `HAIR` | spacing and hairline helpers |

---

## Icons — `source/ui/icons/index.tsx`

~40 hand-drawn SVG icons on a shared 24×24 grid with a `stroke` prop. No
icon library. They are plain components, so any of them can be lifted
individually.

---

## Screens — `source/screens/`

Included as **composition examples only** — they import a store that is not
in this folder, so they will not compile. Read them for how the pieces fit:

- `tabs/Home.tsx` — stat tiles, quick actions, an attention list
- `tabs/Catalog.tsx` — virtual list + search + filters over ~5,000 rows
- `tabs/Alerts.tsx` — grouped, severity-sorted list
- `details/Move.tsx` — the most complex form: multi-step, sheet pickers, scanner
- `details/Product.tsx` — detail page with shared-element entry
- `Login.tsx` — focus handling, error shake, offline fallback

---

## Router — `source/router/Router.tsx` (299 lines)

◐ Hand-written stack navigator: push/pop with a parallax push transition and
an interactive edge swipe-back driven by the `swipe` spring. Tabs keep their
own scroll position across switches.

No routing library. For a fixed, known set of screens this is less code than
configuring one — and it gives complete control over the transition, which a
library would not.
