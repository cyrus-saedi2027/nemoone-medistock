# RTL, Persian numerals, and the Jalali calendar

This app is Persian-first: right-to-left is the assumption, not a mode. If
you are building for Arabic, Hebrew, Urdu or Farsi, this is the part to read
closely — most of it generalises.

---

## The one rule that prevents the double-mirror bug

From [`system/dir.ts`](../source/system/dir.ts), and it is worth memorising:

```
input  (pointer) : physical → logical    ← multiply by DIR here
output (render)  : logical → physical    ← multiply by DIR here
```

> Any value that is *in flight* is always logical. Gestures return a logical
> `dx` (positive = forward in reading order). Render layers multiply by `DIR`
> when they write a transform. **Never both.**

The bug this prevents is the classic one: a value gets mirrored on the way in
*and* on the way out, so it works perfectly in LTR, works perfectly in RTL,
and breaks the moment anything is nested or re-measured. Stating the boundary
as a rule — and putting both conversions in one 37-line file — makes it
impossible to get wrong by accident.

```ts
export const DIR = IS_RTL ? -1 : 1;
export const logicalDx = (dx: number) => dx * DIR;
export const toDesignX = (x, w) => (IS_RTL ? W - (x + w) : x);
export const START = IS_RTL ? "right" : "left";
export const END   = IS_RTL ? "left"  : "right";
```

### What does *not* go through `dir.ts`

Layout and text. Those mirror themselves through `dir="rtl"` and CSS logical
properties — `inset-inline`, `margin-inline`, `padding-inline`,
`border-inline`. Writing `marginInlineStart` instead of `marginLeft`
throughout means the layout needs no RTL logic at all.

`dir.ts` is only for the three things CSS cannot mirror for you:

1. `transform` values
2. SVG coordinates
3. `clientX` from pointer events

---

## Typography: Persian has no letter-spacing and no capitals

A direct quote from [`ui/text/Text.tsx`](../source/ui/text/Text.tsx):

> The reference design used `letterSpacing` in 49 places on small uppercase
> English labels. That visual device does not exist in Persian: letter
> spacing **breaks the connected Persian script**, and there are no capitals.

So `letterSpacing: 0` is set explicitly on every text component, and the
"eyebrow label" is rebuilt as a small coloured dot plus muted colour (`Cap`).
The original device is given to Latin drug names instead, where it is correct.

The components: `Title` (21/800), `Head` (16/800), `Body` (13.5/500),
`Cap` (10.5/700). Note the **line heights: 1.45–1.75**, higher than a Latin
design would use. Persian has tall ascenders and deep descenders; normal
Latin line height makes it collide.

---

## Digits

[`system/i18n/digits.ts`](../source/system/i18n/digits.ts) — two functions,
used everywhere:

```ts
toFa(1234)   // "۱٬۲۳۴"  — Persian digits, ٬ thousands separator, ٫ decimal
toEn("۱۲۳")  // "123"    — for search, inputs and anything compared
```

The rule that keeps it coherent:

- **Everything displayed** goes through `toFa` or the `<Num>` component.
- **Everything compared, searched or stored** goes through `toEn` first.

Users type in whichever digit set their keyboard produces. Searching for a
product code fails roughly half the time unless input is normalised. `toEn`
also handles Arabic-Indic digits (`٠١٢٣`), which Arabic keyboards emit and
which are *not* the same codepoints as Persian ones.

### Mixed scripts in one line

`<Lat>` forces LTR for an inline Latin run. Without it, the bidi algorithm
reorders things like `Novafen 200mg #5288` inside a Persian sentence, and
codes come out backwards. Any time Latin text or a code sits inside Persian
text, it needs wrapping.

---

## Normalisation for search

[`system/i18n/normalize.ts`](../source/system/i18n/normalize.ts) folds the
characters that look identical but are not:

| Typed | Normalised | Why |
|---|---|---|
| `ي` (Arabic yeh) | `ی` (Persian yeh) | different codepoints, identical glyph |
| `ك` (Arabic kaf) | `ک` (Persian kaf) | same |
| `ة` | `ه` | same |
| diacritics `ً ٌ ٍ َ ُ ِ ّ ْ` | removed | optional, inconsistently typed |
| ZWNJ `‌` | space | invisible, breaks matching |
| runs of whitespace | single space | |

Without this, a product entered on an Arabic keyboard is unfindable from a
Persian one, and nobody can see why — the two strings look identical on
screen.

**This same normalisation is duplicated on the server**, with a comment
explaining that if the two ever drift, products created server-side become
unsearchable in the app and no one will understand the cause. If you split
search across client and server, keep the normaliser in one shared place.

---

## The Jalali calendar

[`system/i18n/jalali.ts`](../source/system/i18n/jalali.ts) converts between
Gregorian and Jalali (Solar Hijri) and formats dates.

```ts
toJalali(date)              // { jy, jm, jd }
fmtJalali(j)                // "۱۴۰۵/۰۷/۱۷"
longJalali(j)               // "۱۷ مهر ۱۴۰۵"
expiryLabel("2027-05")      // "اردیبهشت ۱۴۰۶"
jDaysInMonth(jy, jm)        // 29/30/31, leap-year aware
```

Two decisions worth carrying over:

**Expiry is stored as `"YYYY-MM"` text, never a `DateTime`.** Drug expiry is
a *month*, not a day, and storing it as a timestamp meant a timezone could
shift it by one month at a boundary. A string cannot drift.

**Server-side month bucketing uses `Intl`, not a hand-rolled algorithm.** For
grouping records into Jalali months, the code uses
`Intl.DateTimeFormat("en-US-u-ca-persian")` with `timeZone: "Asia/Tehran"`,
on the reasoning that the OS calendar is the same one on the pharmacy wall,
and a one-day disagreement at a month boundary is exactly where that code
runs. The client-side converter is arithmetic because it needs to be
synchronous and fast in a render path.

---

## Fonts

Vazirmatn, self-hosted as four `woff2` weights (400/500/600/700), subset and
preloaded. Not from a CDN — the pharmacy's connection is slow and
occasionally blocked, and a font that fails to load makes Persian text fall
back to something unreadable.

`font-display: swap`, with the fallback stack chosen so the swap does not
reflow the layout noticeably.

---

## Checklist for an RTL app

1. Set `dir="rtl"` on `<html>` and let CSS logical properties do the layout.
2. Put the physical↔logical boundary in **one file** with an explicit rule.
3. Remove `letterSpacing` from the whole codebase.
4. Raise line heights (1.45–1.75).
5. Normalise digits on input, localise on output.
6. Fold Arabic/Persian character variants before any comparison.
7. Wrap inline Latin runs so bidi does not reorder them.
8. Self-host the font.
