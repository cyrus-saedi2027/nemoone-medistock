# Design tokens & theming

Two files carry the whole visual system:

- [`system/tokens.ts`](../source/system/tokens.ts) — geometry, shadow, easing, motion, gesture
- [`system/theme/palettes.ts`](../source/system/theme/palettes.ts) — 8 full colour themes
- [`system/theme/ThemeProvider.tsx`](../source/system/theme/ThemeProvider.tsx) — applies a theme as CSS variables

---

## Theming: typed in TS, delivered as CSS variables

The pattern is worth copying whole. A theme is a plain object; switching one
writes CSS custom properties onto `<html>`:

```ts
function apply(id: ThemeId) {
  const t = THEMES[id];
  const root = document.documentElement;
  for (const [k, val] of Object.entries(t.p)) root.style.setProperty(`--c-${k}`, val);
  root.setAttribute("data-theme", id);
  root.style.colorScheme = t.dark ? "dark" : "light";
  document.querySelector('meta[name="theme-color"]')?.setAttribute("content", t.p.bar);
}
```

Components never touch the palette object. They go through a typed accessor:

```ts
export const v = (k: keyof Palette) => `var(--c-${k})`;

// usage
<div style={{ background: v("card"), color: v("ink") }} />
```

Why this is good:

- **Changing the theme costs zero React renders.** No context value changes,
  nothing re-renders — the browser repaints from new variable values.
- **`keyof Palette` means a typo is a compile error.** `v("cardd")` fails to
  build. (This is also why adding a key to `Palette` forces you to fill it in
  for all 8 themes — tedious, but no theme can silently miss a colour.)
- **`colorScheme` and `theme-color` are updated together**, so native form
  controls and the Android status bar follow the theme instead of lagging
  one step behind.

### A migration detail most apps get wrong

The chosen theme lives in `localStorage`. When the app's *default* theme
changes, phones that already opened the app stay pinned to the old one, so
"the new default" only ever reaches clean installs.

`palettes.ts` carries a **default generation counter**. Bump it, and every
device moves to the new default once; after that the user's own choice is
respected again. Cheap, and it solves a problem that is otherwise invisible
until someone asks why their app looks different from yours.

---

## The palette shape

`Palette` has ~45 keys. The non-obvious ones:

### Two accent ramps, not one

```
accentSurface  → large tinted surfaces, dark text on top
accentStrong   → small emphatic elements (the nav pill), its own ink
```

In a yellow theme both can be the same colour — yellow is light enough to
carry dark text and still read as emphasis. In a blue theme they cannot. One
ramp forces every blue theme into either unreadable text or weak emphasis, so
there are two.

### `hair` — a 1px border, not a shadow

A white card on a near-white background is only separated by its shadow, and
a soft shadow is effectively invisible on a phone in daylight. The fix is not
a heavier shadow: 23 rows are on screen at once and a bigger blur measurably
raises p95 frame time. A one-pixel hairline costs nothing to paint.

### `cardDark` is opaque, not translucent white

It used to be `rgba(255,255,255,.07)`. Translucent surfaces take their colour
from whatever is behind them, so the card appeared and disappeared as the
page scrolled over different background bands. An opaque colour looks the
same everywhere.

### Status colours are dark, not bright

`crit: "#8C1414"`, not `#E53935`. Status text sits on white cards; bright red
on white is the mistake the previous theme made, and the "reorder" badge was
effectively invisible. Every text colour in the default theme is above 4.5:1
— the faintest, `#6E6E75`, is 5.3:1 on white, chosen because 10px Persian
text below that is unreadable on a phone.

### Gradients are restricted to three places

Page background, primary button, bottom nav bar. The comment is blunt about
why: more than that and the app looks dirty.

---

## Geometry tokens

```ts
export const R = {
  badge: 7, tag: 9, icon: 14, row: 18, card: 22,
  sheet: 30, panel: 42, field: 14, tile: 18, pill: 999,
};
```

Radii are named for **what they wrap**, not their size (`R.card`, not
`R.lg`). This is a small decision with a large payoff: when every card in the
app uses `R.card`, changing the app's roundness is one number, and nobody has
to decide whether a particular card is "lg" or "xl".

Same approach for shadows — `SHADOW.card`, `SHADOW.rowDark`, `SHADOW.sheet`,
`SHADOW.nav` — each with a comment on where it belongs.

```ts
export const EASE = {
  out:   "cubic-bezier(.22,1,.36,1)",     // the default for CSS transitions
  ios:   "cubic-bezier(.32,.72,0,1)",     // sheet-like, matches iOS feel
  inOut: "cubic-bezier(.65,0,.35,1)",
};
```

CSS easings are used for simple state changes (a press scale, an opacity
fade). Anything interruptible or gesture-driven uses a spring instead.

### `W = 390, H = 844` is a design frame, not a layout

Those constants describe the space the design was drawn in. Real geometry
comes from `useFrame()`, which measures the actual viewport. Layout code that
reaches for `W`/`H` directly is a bug waiting for a different phone.

### `Z` is tiny and ordered

```ts
Z = { tab: 1, preview: 4, push: 10, nav: 40, sheet: 55, flight: 58, toast: 64 };
```

Seven values for the whole app. No `z-index: 9999` anywhere.

### `FROST.enabled = false`

Backdrop blur is off by default. It is expensive on mid-range Android, and
the rule in this codebase is that speed wins over effect. The flag exists so
it can be turned on for a capable device, not so it can be forgotten on.

---

## Why inline styles instead of CSS or Tailwind

Stated honestly, with the trade-off:

**What it buys:** full TypeScript checking on every value, styles that read
in the same file as the markup, no class-name indirection, no build step
beyond the bundler, and trivially dynamic values (a spring writing
`transform` does not need a class).

**What it costs:** no cascade, no `:hover`/`:focus` without extra work
(`Pressable` handles press state in JS for exactly this reason), style
objects shipped in the JS bundle, and no browser style caching across
components.

For a phone-shaped app of this size the trade is reasonable. For a large
multi-surface product it probably is not — and a token layer this clean
would port to Tailwind config or CSS variables with little loss.
