# Notice

This folder contains source extracted from **MediStock**, a private
commercial pharmacy inventory application, published here by its author as a
UI and motion design reference.

## What is included

The presentation layer only: the motion engine, design tokens, theme system,
component library, router, and screens as composition examples.

## What is deliberately excluded

- the backend (API, database schema, server configuration)
- the client-side data store and sync layer
- all credentials, keys, environment files and database dumps
- the product catalogue and any business data

## Screenshots

`screenshots/` shows the running app. The product names and stock figures are
real but ordinary retail pharmacy items; no personal or customer data appears
anywhere in them.

## Comments

All source comments are in Persian. They carry the design reasoning and are
the most valuable part of this reference.

## Use

Provided as a reference to read and learn from. If you reuse substantial
portions in your own work, an acknowledgement is appreciated.
