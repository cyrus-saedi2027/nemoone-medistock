# MediStock — UI & Motion Reference

A working design system pulled out of a production React app: a Persian,
right-to-left, mobile-first pharmacy inventory tool that three people use
every day on mid-range Android phones over a slow connection.

This folder exists to be **read by another AI** that is building a new app
and wants to copy what works here — the motion engine, the token layer, the
component vocabulary, and the reasoning behind them.

---

## Start here

| If you want | Read |
|---|---|
| The animation system (the most reusable part) | [`docs/01-motion.md`](docs/01-motion.md) |
| Colour, spacing, radii, shadows, theming | [`docs/02-design-tokens.md`](docs/02-design-tokens.md) |
| What components exist and what each is for | [`docs/03-components.md`](docs/03-components.md) |
| Swipe-back, draggable sheets, row swipe | [`docs/04-gestures.md`](docs/04-gestures.md) |
| RTL, Persian numerals, Jalali dates | [`docs/05-rtl-and-persian.md`](docs/05-rtl-and-persian.md) |
| Why it stays fast on a cheap phone | [`docs/06-performance.md`](docs/06-performance.md) |
| What to take and what to leave | [`docs/07-what-to-steal.md`](docs/07-what-to-steal.md) |

Screenshots of the running app are in [`screenshots/`](screenshots/).

---

## What this is

React 18 + TypeScript + Vite. **No UI library, no CSS framework, no
animation library.** Everything here is hand-built:

- a spring physics engine (~110 lines) driving every transition
- a single shared `requestAnimationFrame` loop for all springs at once
- inline styles against a typed token layer — no Tailwind, no CSS-in-JS runtime
- 8 complete colour themes behind one `Palette` type
- gesture handling (edge swipe-back, draggable sheets, swipe-to-reveal rows)
  written against raw pointer events

Roughly 11,000 lines across 62 files.

The constraint that shaped all of it: **mid-range Android, weak network,
one hand, often in a hurry.** Nothing here is decorative. Where something
looks unusual, there is almost always a comment saying which real failure
caused it.

---

## A note on the comments

Every comment in the source is **in Persian**, and they are the single most
valuable thing in this folder. They are not "what this line does" — they are
"why this is written this way, what was tried first, and what broke."

Examples of what you will find:

> `sheet: { stiffness: 170, damping: 25 }` — a comment explaining that
> `200/26` gave a damping ratio of 0.92, which arrived fast and simply
> *stopped*, and read as lifeless; `170/25` brings it to ≈0.77, near the
> signature of the rest of the app.

> `SHADOW.rowDark` — a comment noting the blur radius is deliberately small
> because 23 rows are on screen at once and a larger blur moved p95 frame
> time from 33ms to 50ms on a mid-range Android. Measured, not guessed.

> `useSpringBind` — a long comment about an early-return that silently
> broke *every sheet in the app*, why it was invisible, and how it was found.

If you are a model reading this: the comments carry the design reasoning.
Read them, not just the code.

---

## Layout

```
source/
  system/
    motion/        spring.ts, ticker.ts, useSpring.ts   ← the engine
    theme/         palettes.ts (8 themes), ThemeProvider.tsx
    i18n/          digits.ts, jalali.ts, normalize.ts
    tokens.ts      radii, shadows, easings, spring presets, gesture thresholds
    frame.ts       the phone-frame geometry everything measures against
    dir.ts         RTL helpers
    haptics.ts     tap feedback
  ui/
    primitives/    Motion.tsx, Pressable.tsx
    chrome/        Header, PillNav, PhoneFrame, ScreenScroll, Backdrop, …
    overlays/      Sheet (draggable), ScanSheet, JalaliRange, overlayStack
    list/          VirtualList, HStrip, SearchFilters
    text/          Text.tsx — Persian/Latin digit handling
    icons/         hand-drawn SVG icon set
    kit.tsx        Button, Field, Card, Row, Switch, Chip, …
  screens/         real screens, as composition examples
  router/          push/pop with interactive swipe-back
  domain/types.ts  so the screens are readable
  index.html       the shell, CSS variables, first paint
```

`store/`, `api/` and the backend are deliberately **not** here. They are
business logic and would only be noise for a UI reference.

Because of that, the screen files import from `@/store/...` and will not
compile as given. That is expected — they are here to be *read*, as worked
examples of how the components compose into a real screen. The `system/`
and `ui/` layers are the parts meant to be lifted.

---

## The one-paragraph version of the motion system

A `Spring` class holds position, velocity and a target, and integrates with
semi-implicit Euler. It has **no connection to React**: subscribers write
straight to `element.style`, so a 60fps animation causes zero re-renders. All
live springs share one `requestAnimationFrame` loop that sleeps when nothing
is moving. `set()` hard-sets position and kills velocity — that is what makes
a gesture feel *grabbable* mid-flight. `springTo(target, v0)` hands the
spring the finger's exit velocity so a flick continues naturally. It honours
`prefers-reduced-motion` by jumping to the target and still firing `onRest`.

Everything that moves in the app goes through this: screen push/pop, sheets,
the nav pill, scroll overscroll, row swipe, shared-element flight.

See [`docs/01-motion.md`](docs/01-motion.md) for the full account.

---

## Honest limitations

- **Phone-shaped only.** Layout is built around a fixed design frame
  (390×844) scaled to the viewport. There is no desktop or tablet layout.
- **Inline styles everywhere.** Fast and typed, but no CSS cascade, no
  pseudo-classes without workarounds, and a larger JS bundle than a
  stylesheet would be.
- **Persian-first.** RTL is assumed, not a mode. An LTR app would need the
  `dir.ts` helpers reworked rather than configured.
- **Screens are not standalone.** As noted above, they reference a store
  that is not included.
- **No tests in this folder.** The original has 19 Playwright suites; they
  were left out because they test business flows, not the design system.

---

## Licence & provenance

Extracted from a private commercial project, included here by its author as
a design reference. See [`NOTICE.md`](NOTICE.md).

The screenshots show real pharmacy product names and stock figures. They are
ordinary retail pharmacy items, but if that matters to you, replace them.
